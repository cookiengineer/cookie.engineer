
if (typeof Number.prototype.toJSON !== 'function') {

	Number.prototype.toJSON = function() {
		return this.valueOf();
	};

}

