
describe('Object.values', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3 };
	let obj2 = { '0': 1, '1': 2, '2': 3 };


	assert(Object.values(obj1));
	assert(Object.values(obj2));

	assert(obj1);
	assert(obj2);

	let tmp1 = Object.values(obj1);
	let tmp2 = Object.values(obj2);

	expect(tmp1[0], 1);
	expect(tmp1[1], 2);
	expect(tmp1[2], 3);

	expect(tmp2[0], 1);
	expect(tmp2[1], 2);
	expect(tmp2[2], 3);

});

