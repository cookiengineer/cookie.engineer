$('#app_config').ready(function(){
 $('.submit').each(function(){
  $(this).click(function(){
   $('#wallpaper').remove();
   if($('#config-bgcolor').val()!=""){
    $('body').css({'background-color':$('#config-bgcolor').val()});
    $().notification('Background changed.');
   }
   if($('#config-wallpaper').val()!=""){
    $('#wallpaper').remove();
    $('body').prepend('<img id="wallpaper" class="abs" src="'+$('#config-wallpaper').val()+'"/>');
    var x = $('#config-position').val();
    if(x.match('fit_width')){  $('#wallpaper').css({'width':'100%'}); }
    if(x.match('fit_height')){ $('#wallpaper').css({'height':'100%'}); }
    if(x.match('top')){        $('#wallpaper').css({'top':'0px'}); }
    if(x.match('bottom')){     $('#wallpaper').css({'bottom':'0px'}); }
    if(x.match('left')){       $('#wallpaper').css({'left':'0px'}); }
    if(x.match('right')){      $('#wallpaper').css({'right':'0px'}); }
    $().notification('Wallpaper changed.');
   }
  });
  jQueryDesktop.setenv('wallpaper',$('#config-wallpaper').val());
  jQueryDesktop.setenv('bgcolor',  $('#config-bgcolor').val());
 });

 $('#config-bgcolor').find('option').each(function(){
  $(this).css({'background':$(this).val()});
 });
});