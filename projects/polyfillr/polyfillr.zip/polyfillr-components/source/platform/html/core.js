
if (typeof Polyfillr === 'undefined') {
	Polyfillr = {};
}

(function(global) {

	const _document    = global.document;
	const _COMPONENTS  = {};
	const _STYLESHEETS = {};



	/*
	 * HELPERS
	 */

	const _initialize = function() {

		let identifier = this.identifier;
		let template   = this.template;
		let code       = ((template || {}).innerHTML || '');


		let check = _STYLESHEETS[identifier] || null;
		if (check !== null) {
			return false;
		}


		if (code.length > 0) {

			let c1 = code.indexOf('<content>');
			let c2 = code.indexOf('</content>', c1);
			if (c1 !== -1 && c2 !== -1) {
				template.innerHTML = code.substr(c1 + 9, c2 - c1 - 9).trim();
			} else {
				template.innerHTML = '';
			}


			let s1 = code.indexOf('<style>');
			let s2 = code.indexOf('</style>', s1);
			if (s1 !== -1 && s2 !== -1) {

				let sheet = (code.substr(s1 + 7, s2 - s1 - 7)).trim();
				if (sheet.length > 0) {

					sheet = sheet.split('\n').map(function(line) {

						let tmp = line.trim();
						if (tmp.substr(0, 6) === ':host(') {

							let i1 = tmp.indexOf(')', 6);
							let i2 = tmp.indexOf(' ', 6);
							if (i1 !== -1 && i1 < i2) {
								return identifier + tmp.substr(6, i1 - 6) + tmp.substr(i1 + 1);
							}

						} else if (tmp.substr(0, 5) === ':host') {
							return identifier + tmp.substr(5);
						} else if (tmp.indexOf(':host') !== -1) {
							return tmp.split(':host').join(identifier);
						}

						return tmp;

					}).map(function(line) {

						let tmp = line.trim();
						if (tmp.substr(0, 9) === '::content') {
							return identifier + tmp.substr(9);
						} else if (tmp.indexOf(' ::content') !== -1) {
							return tmp.split(' ::content').join('');
						}

						return tmp;

					}).join('\n');


					let wrapper = _document.createElement('style');
					if (wrapper !== null) {
						wrapper.innerHTML = sheet;
						_document.head.appendChild(wrapper);
						_STYLESHEETS[identifier] = wrapper;
					}

				}

			}

		}


		let elements = [].slice.call(_document.querySelectorAll(identifier));
		if (elements.length > 0) {

			elements.forEach(function(element) {
				this.create(element);
			}.bind(this));

		}

	};



	/*
	 * IMPLEMENTATION
	 */

	Polyfillr.create = function(identifier) {

		let component = _COMPONENTS[identifier] || null;
		if (component !== null) {
			return component.create();
		}


		return null;

	};

	Polyfillr.define = function(identifier, template) {

		let component = _COMPONENTS[identifier] || null;
		if (component !== null) {

			return null;

		} else {

			component = new Polyfillr.Component(identifier, template);

			_COMPONENTS[identifier] = component;
			setTimeout(_initialize.bind(component), 0);


			return component;

		}

	};

	Polyfillr.destroy = function(element) {

		let identifier = element.tagName.toLowerCase();
		let component  = _COMPONENTS[identifier] || null;
		if (component !== null) {
			return component.destroy(element);
		}


		return true;

	};

	Polyfillr.get = function(identifier) {

		let component = _COMPONENTS[identifier] || null;
		if (component !== null) {
			return component;
		}


		return null;

	};

	Polyfillr.render = function(element, data) {

		data = data instanceof Object ? data : null;


		if (typeof element.fireEventListener === 'function') {

			element.fireEventListener('render', data);

			return true;

		}


		return false;

	};

})(typeof window !== 'undefined' ? window : this);


