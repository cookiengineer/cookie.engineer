<?php

function getFiles($path,$hash=false){
	if(substr($path,-1)=="/"){
		$path=substr($path,0,strlen($path)-1);
	}

	if(is_dir($path)){
		if(!empty($hash)){
			$dh = opendir($path);
			while(($file=readdir($dh)) !== false){
				if(is_file($path."/".$file) && $_GET['hash']==md5($file)){
					// if hash is known, return the content
					$cache = file_get_contents($path."/".$file);
				}
			}
			closedir($dh);
		}elseif($hash===false){
			$dh = opendir($path);
			while(($file=readdir($dh)) !== false){
				if(is_file($path."/".$file)){
					// if no hash is known, return an array with a list of files
					$cache[$file] = array(
						'hash'=>md5($file),
						'title'=>strftime("%d.%m.%Y %H:%M Uhr",filemtime($path."/".$file))
					);
				}
			}
			closedir($dh);
		}
	}
	return (!empty($cache)?$cache:false);
}

?>