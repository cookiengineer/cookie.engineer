
# Polyfillr console

A modern plug-and-play standard console.

This project implements the [Console](https://developer.mozilla.org/en-US/docs/Web/API/console)
API and has no further dependencies.

The website [polyfillr.github.io](https://polyfillr.github.io)
allows to select the feature set of a custom build.

brought to you as libre software with joy and pride by [Artificial Engineering](http://artificial.engineering).

Support our libre Bot Cloud via BTC [1CamMuvrFU1QAMebPoDsL3JrioVDoxezY2](bitcoin:1CamMuvrFU1QAMebPoDsL3JrioVDoxezY2?amount=0.5&label=lychee.js%20Support).



## Overview

[Online Demo](https://polyfillr.github.io/demo/console.html)


**Usage (Browser)**

Include the build script into the `<head>` so that
every following script can use the `console` API:

```html
<!DOCTYPE html>
<html>
<head>
	<!-- OLD BROWSER? Use console.es5.js instead -->
	<script src="./bower_components/polyfillr/build/html/console.es6.js"></script>

	<!-- CUSTOMIZATION -->
	<style>aside#console.active { width: 100% !important; }</style>
</head>
<body>
	<script>
	console.log('Hello world');
	console.warn({
		message: "This is fun!"
	});
	</script>
</body>
```

**Usage (node.js)**

Require the build script before other scripts, so that
every following script can use the `console` API:

```javascript
// OLD NODE? Use console.es5.js instead
console = require('./bower_components/polyfillr/build/console.es6.js');
```


This library is a project made with [lychee.js](https://lychee.js.org).

It is automatically built and deployed to GitHub using the following
`lycheejs-fertilizer` integration scripts:

- `bin/build.sh` builds the `console.js` and inlines necessary CSS
- `bin/publish.sh` pushes the `master` branch to GitHub


**Multi-Context Debugging**

It is possible to create custom `console` instances, so that it is
easier to debug asynchronously in parallel:

```javascript
let instance = new Console('awesome');

instance.log('All your logs are belong to us.');
```


**User Interface**

You can open the Console in two ways:

- Click or Touch on the fixed Icon on the Top Right (e.g. on mobile).
- Use the keyboard and press `[Shift] + [C]` to toggle the Console.


## Implemented Standard API

- `console.assert(condition, ...arguments)`
- `console.clear()`
- `console.debug(...arguments)` is a symlink to `console.log(...arguments)`
- `console.group(label)`
- `console.groupEnd()`
- `console.info(...arguments)`
- `console.log(...arguments)`
- `console.table(data [,labels])`
- `console.warn(...arguments)`
- `console.error(...arguments)`
- `console.time(label)`
- `console.timeEnd(label)`


## Impossible To Implement

These Console API methods were declared to be too
high in complexity to be implemented.

Reason is most likely that the feature needs a
full-blown parser or a low-level VM API that will
bloat the implementation too much to stay performant.

- `console.count()`
- `console.dir()`
- `console.dirxml()`
- `console.groupCollapsed()`
- `console.markTimelime()`
- `console.profile()`
- `console.profileEnd()`
- `console.timelime()`
- `console.timelimeEnd()`
- `console.timeStamp()`
- `console.trace()`


## License

This project is released under [GNU GPL 3](./LICENSE_GPL3.txt) license.

