
describe('Number.prototype.toSource', (assert, expect) => {

	let cmp1 = '(new Number(123))';
	let cmp2 = '(new Number(123.45))';
	let num1 = 123;
	let num2 = 123.45;


	assert(num1.toSource());
	assert(num2.toSource());

	assert(num1);
	assert(num2);

	expect(num1.toSource(), cmp1);
	expect(num2.toSource(), cmp2);

});

