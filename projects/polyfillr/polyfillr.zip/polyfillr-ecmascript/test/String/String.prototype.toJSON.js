
describe('String.prototype.toJSON', (assert, expect) => {

	let cmp1 = 'This is a simple sentence';
	let str1 = 'This is a simple sentence';

	assert(str1.toJSON());

	assert(str1);

	expect(str1.toJSON(), cmp1);

});

