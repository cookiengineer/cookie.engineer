
if (typeof Array.prototype.unique !== 'function') {

	Array.prototype.unique = function() {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.unique called on null or undefined');
		}


		let clone  = [];
		let list   = Object(this);
		let length = this.length >>> 0;
		let value;

		for (let i = 0; i < length; i++) {

			value = list[i];

			if (clone.indexOf(value) === -1) {
				clone.push(value);
			}
		}

		return clone;

	};

}

