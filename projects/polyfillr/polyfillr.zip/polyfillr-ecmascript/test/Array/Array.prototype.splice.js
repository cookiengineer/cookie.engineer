
describe('Array.prototype.splice', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [1,2,3,4,5];
	let arr4 = [1,2,3,4,5];
	let arr5 = [1,2,3,4,5];

	assert(arr1.splice(2,3));
	assert(arr2.splice(3));
	assert(arr3.splice());
	assert(arr4.splice(2, 1, 'foo'));
	assert(arr5.splice(-2, 1));

	assert(arr1);
	assert(arr2);
	assert(arr3);
	assert(arr4);
	assert(arr5);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);
	assert(arr4.length);
	assert(arr5.length);

});

