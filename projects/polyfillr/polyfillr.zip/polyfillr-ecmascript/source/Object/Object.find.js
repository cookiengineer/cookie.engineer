
if (typeof Object.find !== 'function') {

	Object.find = function(object, predicate/*, thisArg */) {

		if (object !== Object(object)) {
			throw new TypeError('Object.find called on a non-object');
		}

		if (typeof predicate !== 'function') {
			throw new TypeError('predicate must be a function');
		}


		let thisArg = arguments.length >= 3 ? arguments[2] : void 0;

		for (let prop in object) {

			let value = object[prop];

			if (Object.prototype.hasOwnProperty.call(object, prop)) {

				if (predicate.call(thisArg, value, prop, object)) {
					return value;
				}

			}

		}

		return undefined;

	};

}

