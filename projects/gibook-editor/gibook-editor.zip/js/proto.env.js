// initialize console

if(typeof(console)=='undefined'){
	var console = (function($) {
		return {
			log: function(x) {
				// do nothing, just skip the errors if a non-developer uses this web app =D

				//netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
				//Components.utils.reportError(x);
			},
			warn: function(x) { alert(x); },
			group: function(x) {},
			groupEnd: function() {}
		};
	})(jQuery);
}

// initialize session
var __={
	element:'ads',
	type:'',
	cache:'',
	ready_xml:''
};

// initialize globals
var globals={
	heuristics:{
		'lists':{
			'unordered':{
				'-':true,
				'#':true,
				'*':true,
				'•':true
			},
			'ordered':{
				'1':true,'2':true,'3':true,'4':true,'5':true,'6':true,'7':true,'8':true,'9':true,
				'I':true,'II':true,'III':true,'IV':true,'V':true,'VI':true,'VII':true,'VIII':true,'IX':true,'X':true
			}
		}
	},
	translations:{
		'gi:title':					{'de':'Titel','en':'Title'},
		'l:paragraph':			{'de':'Absatz','en':'Paragraph'},
		'gi:entry':					{'de':'Verweis','en':'Reference'},
		'open':							{'de':'öffnen'},
		'delete':						{'de':'löschen'},

		'restored':					{'de':'wiederhergestellt'},
		'saved':						{'de':'gespeichert'},
		'deleted':					{'de':'gelöscht'},

		'no saved files':		{'de':'Keine gespeicherten Dateien.'}
	}
};
