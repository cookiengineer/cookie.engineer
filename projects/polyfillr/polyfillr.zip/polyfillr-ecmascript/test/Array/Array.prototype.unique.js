
describe('Array.prototype.unique', (assert, expect) => {

	let arr1 = [1,3,2,3,4,3,5];
	let arr2 = [1,3,2,3,4,3,5];
	let arr3 = [1,3,2,3,'foo','bar','foo'];

	assert(arr1.unique());
	assert(arr2.unique());
	assert(arr3.unique());

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

