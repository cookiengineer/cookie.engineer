var jQueryDesktop = (function($) {
 return {
  updateclock: function() {
   // Date variables.
   var date_obj = new Date();
   var hour = date_obj.getHours();
   var minute = date_obj.getMinutes();
   var second = date_obj.getSeconds();
   var day = date_obj.getDate();
   var year = date_obj.getFullYear();
   var suffix = 'AM';

   // Array for weekday.
   var weekday = [
    'Sunday','Monday','Tuesday','Wednesday',
    'Thursday','Friday','Saturday'
   ];

   // Array for month.
   var month = [
    'January','February','March','April',
    'May','June','July','August',
    'September','October','November','December'
   ];

   // Assign weekday, month, date, year.
   weekday = weekday[date_obj.getDay()];
   month = month[date_obj.getMonth()];

   // AM or PM?
   if (hour >= 12) {
    suffix = 'PM';
   }

   // Convert to 12-hour.
   if (hour > 12) {
    hour = hour - 12;
   }
   else if (hour === 0) {
    // Display 12:XX instead of 0:XX.
    hour = 12;
   }

   // Leading zero, if needed.
   if (minute < 10) {
    minute = '0' + minute;
   }
   if (second < 10) {
    second = '0' + second;
   }

   // Build two HTML strings.
   var clock_time = weekday + ' ' + hour + ':' + minute + ':' + second + ' ' + suffix;
   var clock_date = month + ' ' + day + ', ' + year;

   $('#clock').html(clock_time).attr('title', clock_date);

   // Update each second.
   setTimeout(jQueryDesktop.updateclock, 1000);
  },

  // The Comet update sharing system
  update: function(url) {
   $.get(url,function(data,status){
    $(data).find('push').find('do').each(function(){
     var x = $(this);
     var y = $($(this).find('obj').text());

     if(x.find('req').text()=="update"){
      if(x.find('typ').text()=="html"){
       y.html(y.html()+"\n<li>"+x.find('cnt').text()+"</li>");
      }
     }else if(x.find('req').text()=="create"){
      y.append(x.find('cnt').text());
     }else if(x.find('req').text()=="remove"){
      y.remove();
     }

    });
   });

   // Update each tenth second (=D)
   setTimeout(jQueryDesktop.update, 10000, url);
  },

  // Clear active states, hide menus.
  clear_active: function(el) {
   if(el){
    $(el).find('.active').removeClass('active');
    $(el).find('.shiny').removeClass('shiny');
   }else{
    $('.active').removeClass('active');
    $('ul.menu').hide();
   }
  },

  getenv: function(key) {
   if(document.cookie && document.cookie != '') {
    var cookies = document.cookie.split(';');
    for(var i = 0; i < cookies.length; i++){
     var cookie = $.trim(cookies[i]);
     // Does this cookie string begin with the name we want?
     if(cookie.substring(0, key.length + 1) == (key + '=')) {
      cookieVal = decodeURIComponent(cookie.substring(key.length + 1));
      break;
     }
    }
    // Replacing all + in the Cookie
    while(cookieVal.search(/\+/) != -1){
     cookieVal=cookieVal.replace(/\+/," ");
    }
   }
   return cookieVal;
  },

  setenv: function(key,val) {
   if(val===null){ var val=''; }
   var date = new Date();
   date.setTime(date.getTime() + (24 * 60 * 60 * 1000));
   var options = { path: '/', expires: date };

   var expires = '';
   if(typeof options.expires == "number" || typeof options.expires.toUTCString == "string") {
    var date;
    if (typeof options.expires == "number") {
     date = new Date();
     date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
    }else{
     date = options.expires;
    }
    expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
   }

   var path = options.path ? '; path=' + (options.path) : '';
   var domain = options.domain ? '; domain=' + (options.domain) : '';
   var secure = options.secure ? '; secure' : '';
   document.cookie = [key, '=', encodeURIComponent(val), expires, path, domain, secure].join('');
  },

  // Zero out window z-index.
  window_flat: function() {
   $('win').removeClass('stack');
   $('#dock').find('a').removeClass('shiny');
  },

  // Resize modal window.
  window_max: function(el) {
   // Nearest parent window.
   var win = $(el).closest('win');

   // Is it maximized already?
   if (win.hasClass('full')) {
    // Restore window position.
    win.removeClass('full').css({
     'top': win.attr('data-t'),
     'left': win.attr('data-l'),
     'right': win.attr('data-r'),
     'bottom': win.attr('data-b'),
     'width': win.attr('data-w'),
     'height': win.attr('data-h')
    });
   } else {
    win.attr({
     // Save window position.
     'data-t': win.css('top'),
     'data-l': win.css('left'),
     'data-r': win.css('right'),
     'data-b': win.css('bottom'),
     'data-w': win.css('width'),
     'data-h': win.css('height')
    }).addClass('full').css({
     // Maximize dimensions.
     'top': '0',
     'left': '0',
     'right': '0',
     'bottom': '0',
     'width': '100%',
     'height': '100%'
    });
   }

   // Bugfixing iframe on resize
   win.find('iframe').width(win.width() - 170).height(win.height() - 65);
   win.find('.iframe').width(win.width() - 4).height(win.height() - 65);
   win.find('.noaside').width(win.width());

   // Bring window to front.
   jQueryDesktop.window_flat();
   win.addClass('stack');
  },

  dispatch: function(obj) {
   // Add the possibility to start apps with links in windows.
   // x = window, y=task
   var x = $(obj.attr('href'));
   var y = $(x.find('a').attr('href'));
   obj.click(function(){
    if(obj.attr('rev')){
     y.find('.frame').load(obj.attr('rev')+" .data", function(){
      $(this).find('a.launch').each(function() {
       jQueryDesktop.dispatch($(this));
      });
      $(this).find('.ui-tabs').tabs();
      $(this).find('textarea').wysiwyg();
     })
     y.find('iframe').attr({'src': obj.attr('rev')});
    }

    // Bring window to front.
    jQueryDesktop.window_flat();
    y.show().addClass('stack').css({'opacity':1});

    // Show the taskbar button.
    if(x.is(':hidden')) {
     $().notification("Starting "+x.find('a').attr('href'));
     x.remove().appendTo('#dock').end().show('fast');
    }

    x.find('a').addClass('shiny');
   });
  },

  // Initialize the desktop.
  init: function() {
   jQueryDesktop.updateclock();

   // Make top menus active.
   $('a.menu_trigger').click(function() {
    if($(this).hasClass('active')){
     $(this).removeClass('active').next('ul.menu').hide('fast');
    }else{
     jQueryDesktop.clear_active();
     $(this).addClass('active').next('ul.menu').show('fast');
    }
   }).mouseenter(function() {
    // Transfer focus, if already open.
    if($('ul.menu').is(':visible')) {
     jQueryDesktop.clear_active();
     $(this).addClass('active').next('ul.menu').show();
    }
   });

   // Desktop and icons.
   $('#desktop').click(function() {
    jQueryDesktop.clear_active();
   });

   $('a.icon img').click(function() {
    $(this).parent()
    .animate({top:"+=10px"},80).animate({top:"-=5px"},80)
    .animate({top:"+=5px"},80).animate({top:"-=10px"},80);

    // Get the link's target.
    var x = $($(this).parent().attr('href'));
    var y = $(x.find('a').attr('href'));

    // Bring window to front.
    jQueryDesktop.window_flat();
    y.show().addClass('stack').css({'opacity':1});

    // Show the taskbar button.
    if(x.is(':hidden')) {
     $().notification("Starting "+x.find('a').attr('href'));
     x.remove().appendTo('#dock').end().show('fast').find('a').addClass('shiny');
    }else{
     // $().notification('Querying '+x.find('a').attr('href'));
    }
   });

   $('a.icon').draggable().bind('dragstop', function(event, ui){
    $(this).css({
     'left' : Math.round(ui.offset.left/80)*80,
     'top' : Math.round(ui.offset.top/70)*70+10
    });
    return false;
   });

   // Taskbar buttons.
   $('#dock a').live('click', function() {
    var x = $($(this).attr('href'));
    // Hide, if visible. If not, bring window to front
    if (x.is(':visible')) {
     $(this).removeClass('shiny');
     x.hide();
    } else {
     jQueryDesktop.window_flat();
     $(this).addClass('shiny');
     x.show().addClass('stack').css({'opacity': 1});
    }

    // Stop the live() click.
    this.blur();
    return true;
   });

   // Make windows movable.
   $('win').mousedown(function(){
    var x = '#'+$(this).attr('id');
    // Bring window to front.
    jQueryDesktop.window_flat();
    $(this).addClass('stack');
    $('#dock').find('a').each(function(){
     if($(this).attr('href')==x){
      $(this).addClass('shiny');
     }
    });
   }).draggable({
    containment: 'parent',
    handle: 'bar.top'
   }).resizable({
    containment: 'parent',
    minWidth: 400,
    minHeight: 200

   // Resize frames in windows (both ajax and iframe)
   }).bind('resize', function() {
    var x = $(this).find(".frame");
    if(x && x.hasClass('noaside')) {
     x.width($(this).width());
    }else if(x){
     x.width($(this).width() - 170);
    }

    var y = $(this).find("iframe");
    if(y) {
     if(y.hasClass('iframe')){
      y.width($(this).width() - 4);
     }
     y.height($(this).height() - 68);
    }

   // Double-click top bar to resize, ala Windows OS.
   }).find('bar.top').dblclick(function() {
    jQueryDesktop.window_max(this);

   // Scroll up and down to influence window opacity
   }).mousewheel(function(e,d) {
    var x = ($(this).closest('win').css('opacity')*100); // percentage
    if(d>0 && x <= 90){
     y = ((x + (10))/100);
    }else if(d<0 && x > 10){
     y = ((x - (10))/100);
    }
    if(typeof(y)!="undefined"){
     $(this).closest('win').css({'opacity': y.toString(10)});
    }
   });

   // Get action buttons for each window.
   $('a.min, a.max, a.close').mousedown(function() {
    jQueryDesktop.clear_active();
    // Stop propagation to window's top bar.
    return false;
   });

   // Minimize the window.
   $('a.min').click(function() {
    $(this).closest('win').hide();
   });

   // Maximize or restore the window.
   $('a.max').click(function() {
    jQueryDesktop.window_max(this);
   });

   // Close the window.
   $('a.close').click(function() {
    $(this).closest('win').hide();
    $($(this).attr('href')).hide('fast');
   });

   $('#show_desktop').click(function() {
    // If any windows are visible, hide all.
    if ($('win:visible').length) {
     $(this).addClass('shiny');
     $('win').hide();

    // Otherwise, reveal hidden windows that are open.
    } else {
     $(this).removeClass('shiny');
     $('#dock li:visible a').each(function() {
      $($(this).attr('href')).show();
     });
    }
   });

   $('.ui-tabs').each(function() {
    $(this).tabs();
   });

   $('#desklets').css({'opacity': '0.6'});

   $('#quicklaunch').each(function() {
    $.each($(this).find('li a'), function() {
     var x = parseInt($(this).width());
     var y = parseInt($(this).height());

     $(this).data("init_w", x);
     $(this).data("init_h", y);
     $(this).data("new_w", x * 2);
     $(this).data("new_h", y * 2);
    });
    $(this).find('a').bind("mouseenter",function(event) {
     $(this).animate({"width": $(this).data("new_w") + "px", "height": $(this).data("new_h") + "px"},"fast");
    }).bind("mouseleave",function(event) {
     if($(this).width()==$(this).data("new_w")){
      $(this).animate({"width": $(this).data("init_w") + "px", "height": $(this).data("init_h") + "px"},"fast");
     }else{
      $(this).stop().width($(this).data("init_w")).height($(this).data("init_h"));
     }
    });
   });

   $('a.launch,#desklets a').each(function() {
    jQueryDesktop.dispatch($(this));
   });
   // sidebar in apps
   $('.aside a').each(function() {
    $(this).click(function(){
     $(this).closest('.aside').find('a').removeClass('shiny');
     $(this).addClass('shiny');
    });
    jQueryDesktop.dispatch($(this));
   });

  }
 };
// Pass in jQuery.
})(jQuery);
