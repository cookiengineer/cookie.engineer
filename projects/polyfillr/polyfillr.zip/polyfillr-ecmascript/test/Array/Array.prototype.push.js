
describe('Array.prototype.push', (assert, expect) => {

	let arr1 = [1,2,3];
	let arr2 = [1,2,3];
	let arr3 = [1,2,3];

	assert(arr1.push(4));

	assert(arr2.push(5));
	assert(arr2.push(6));
	assert(arr3.push('foo'));

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

