
if (typeof Array.prototype.indexOf !== 'function') {

	Array.prototype.indexOf = function(search/*, from */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.indexOf called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let from   = arguments.length >= 2 ? (arguments[1] | 0) : 0;


		if (length === 0 || from >= length) {
			return -1;
		}


		let start = Math.max(from >= 0 ? from : (length - Math.abs(from)), 0);

		for (let i = start; i < length; i++) {

			if (i in list) {

				if (list[i] === search) {
					return i;
				}

			}

		}


		return -1;

	};

}

