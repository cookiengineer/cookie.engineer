<?php
/* the ajax push daemon - publishing updates! */

/*
 @req(uests):
  update,create,replace,remove

 @obj(ects) (caught via jQuery by the Client):
  #myid,.myclass

 @typ(es):
  html - modifies the content inside
  before - adds before
  after - adds after

 <req>update</req>
 <typ>html</typ>
 <obj>#desktop</obj>
 <cnt>This is an ad displayed via jQuery-Desktop's CometDaemon.</cnt>

 ||

 default type requests an html() update.
 <req>update</req>
 <obj>#desktop</obj>
 <cnt>This is an ad displayed via jQuery-Desktop's CometDaemon.</cnt>
*/
function setheaders(){
 header ("Content-Type: text/xml; charset=utf-8");
 header ("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
 header ("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
}

if($_COOKIE['ad_displayed']==="true"){
 setcookie("ad_displayed","false");
 setheaders();
 echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<push>
 <do>
  <req>update</req>
  <typ>html</typ>
  <obj>#debug</obj>
  <cnt>Ajax Push remove (".date('H:i:s').")</cnt>
 </do>
 <do>
  <req>remove</req>
  <obj>#adframe</obj>
 </do>
</push>";
}else{
 setcookie("ad_displayed","true");
 setheaders();
 echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<push>
 <do>
  <req>update</req>
  <typ>html</typ>
  <obj>#debug</obj>
  <cnt>Ajax Push create (".date('H:i:s').")</cnt>
 </do>
 <do>
  <req>create</req>
  <obj>#desktop</obj>
  <cnt><![CDATA[<div class=\"abs\" id=\"adframe\">This is a AJAX Push Service generated adframe, which is here about 10 seconds.</div>]]></cnt>
 </do>
</push>";
}
flush();

?>