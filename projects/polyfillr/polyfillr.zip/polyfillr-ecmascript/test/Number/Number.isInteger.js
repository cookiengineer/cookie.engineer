
describe('Number.isInteger', (assert, expect) => {

	assert(Number.isInteger(NaN));
	assert(Number.isInteger(-0));
	assert(Number.isInteger(+0));
	assert(Number.isInteger(1337));
	assert(Number.isInteger(1337.89));
	assert(Number.isInteger(Infinity));
	assert(Number.isInteger(-Infinity));
	assert(Number.isInteger("0"));

	expect(Number.isInteger(NaN),       false);
	expect(Number.isInteger(-0),        true);
	expect(Number.isInteger(+0),        true);
	expect(Number.isInteger(1337),      true);
	expect(Number.isInteger(1337.89),   false);
	expect(Number.isInteger(Infinity),  false);
	expect(Number.isInteger(-Infinity), false);
	expect(Number.isInteger("0"),       false);

});

