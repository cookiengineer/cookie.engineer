
if (typeof Array.prototype.some !== 'function') {

	Array.prototype.some = function(predicate/*, thisArg */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.some called on null or undefined');
		}

		if (typeof predicate !== 'function') {
			throw new TypeError('predicate must be a function');
		}


		let list    = Object(this);
		let length  = list.length >>> 0;
		let thisArg = arguments.length >= 2 ? arguments[1] : void 0;


		for (let i = 0; i < length; i++) {

			if (i in list) {

				if (!!predicate.call(thisArg, list[i], i, list) === true) {
					return true;
				}

			}

		}


		return false;

	};

}

