
describe('Number.prototype.toJSON', (assert, expect) => {

	let cmp1 = 123;
	let cmp2 = 123.45;
	let num1 = 123;
	let num2 = 123.45;

	assert(num1.toJSON());
	assert(num2.toJSON());

	assert(num1);
	assert(num2);

	expect(num1.toJSON(), cmp1);
	expect(num2.toJSON(), cmp2);

});

