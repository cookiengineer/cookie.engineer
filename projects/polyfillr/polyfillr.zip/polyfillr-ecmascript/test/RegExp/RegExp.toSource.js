
describe('RegExp.toSource', (assert, expect) => {

	let cmp = 'function RegExp() {\n\t[native code]\n}';

	assert(RegExp.toSource());
	expect(RegExp.toSource(), cmp);

});

