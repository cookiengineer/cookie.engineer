
if (typeof String.prototype.toJSON !== 'function') {

	String.prototype.toJSON = function() {
		return this.valueOf();
	};

}

