
describe('Object.entries', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3 };
	let obj2 = { '0': 1, '1': 2, '2': 3 };


	assert(Object.entries(obj1));
	assert(Object.entries(obj2));

	assert(obj1);
	assert(obj2);

	let tmp1 = Object.entries(obj1);
	let tmp2 = Object.entries(obj2);

	expect(tmp1[0][0], 'a');
	expect(tmp1[1][0], 'b');
	expect(tmp1[2][0], 'c');

	expect(tmp1[0][1], 1);
	expect(tmp1[1][1], 2);
	expect(tmp1[2][1], 3);

	expect(tmp2[0][0], '0');
	expect(tmp2[1][0], '1');
	expect(tmp2[2][0], '2');

	expect(tmp2[0][1], 1);
	expect(tmp2[1][1], 2);
	expect(tmp2[2][1], 3);

});

