
if (typeof Object.prototype.toLocaleString !== 'function') {

	// XXX: Yes, this is the correct implementation. WTF.
	Object.prototype.toLocaleString = function() {
		return Object.prototype.toString.call(this);
	};

}

