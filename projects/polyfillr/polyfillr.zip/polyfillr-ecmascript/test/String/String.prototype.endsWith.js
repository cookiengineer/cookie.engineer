
describe('String.prototype.endsWith', (assert, expect) => {

	let str1 = "This is a simple sentence";
	let str2 = "This is a simple sentence";

	assert(str1.endsWith('sentence'));
	assert(str1.endsWith('simple'));
	assert(str2.endsWith('simple', 16));
	assert(str2.endsWith('simple', 17));

	assert(str1);
	assert(str2);

	expect(str1.endsWith('sentence'),   true);
	expect(str1.endsWith('simple'),     false);
	expect(str2.endsWith('simple', 16), true);
	expect(str2.endsWith('simple', 17), false);

});

