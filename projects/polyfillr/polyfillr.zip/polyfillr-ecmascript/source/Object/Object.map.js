
if (typeof Object.map !== 'function') {

	Object.map = function(object, predicate/*, thisArg */) {

		if (object !== Object(object)) {
			throw new TypeError('Object.map called on a non-object');
		}

		if (typeof predicate !== 'function') {
			throw new TypeError('predicate must be a function');
		}


		let clone   = {};
		let keys    = Object.keys(object).sort();
		let length  = keys.length >>> 0;
		let thisArg = arguments.length >= 3 ? arguments[2] : void 0;
		let key;
		let value;
		let tmp;


		for (let k = 0; k < length; k++) {

			key   = keys[k];
			value = object[key];
			tmp   = predicate.call(thisArg, value, key, object);

			if (tmp !== undefined) {
				clone[key] = tmp;
			}

		}


		return clone;

	};

}

