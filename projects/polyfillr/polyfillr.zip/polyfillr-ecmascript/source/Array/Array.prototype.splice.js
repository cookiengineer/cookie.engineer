
if (typeof Array.prototype.splice !== 'function') {

	Array.prototype.splice = function(/* start, count, ... elements */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.splice called on null or undefined');
		}


		let list     = Object(this);
		let length   = list.length >>> 0;
		let elements = [];
		let result   = [];


		if (arguments.length === 0) {
			return result;
		}


		let start = 0;
		let count = 0;

		if (arguments.length >= 1) {
			start = (arguments[0] | 0);
		}

		if (arguments.length >= 2) {
			count = (arguments[1] | 0);
		} else {
			count = length - start;
		}


		for (let a = 2; a < arguments.length; a++) {
			elements.push(arguments[a]);
		}


		let diff = count;

		for (let i = 0; i < diff; i++) {

			let k = start + i;
			if (k in list) {

				result.push(list[k]);
				delete list[k];

			}

		}


		for (let e = 0, el = elements.length; e < el; e++) {

			let k = start + e;

			if (k in list) {

				list[k + 1] = list[k];
				list[k] = elements[e];

			} else {

				list[k] = elements[e];

			}

		}


		for (let i = length - 1; i > 0; i--) {

			if (!((i - 1) in list)) {

				if (i in list) {
					list[i - 1] = list[i];
					delete list[i];
				}

			}

		}


		return result;

	};

}

