
if (typeof Array.prototype.toSource !== 'function') {

	Array.prototype.toSource = function() {

		let list   = Object(this);
		let length = list.length >>> 0;
		let value  = '';
		let entry;


		for (let i = 0; i < length; i++) {

			if (i in list) {

				entry = list[i];

				if (entry === undefined) {
					value += 'undefined';
				} else if (entry === null) {
					value += 'null';
				} else if (typeof entry === 'number') {
					value += (entry).valueOf();
				} else if (typeof entry === 'string') {
					value += '"' + entry + '"';
				} else if (entry instanceof RegExp) {
					value += (entry).toString();
				} else if (typeof (entry).toSource === 'function') {
					value += (entry).toSource();
				} else {
					value += (entry).toString();
				}

			}

			if (i !== length - 1) {
				value += ', ';
			}

		}


		return '[' + value + ']';

	};

}

