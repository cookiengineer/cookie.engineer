
if (typeof Array.prototype.reduce !== 'function') {

	Array.prototype.reduce = function(predicate/*, initialValue */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.reduce called on null or undefined');
		}

		if (typeof predicate !== 'function') {
			throw new TypeError('predicate must be a function');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let start  = 0;
		let value  = undefined;


		if (arguments.length >= 2) {

			value = arguments[1];

		} else {

			while (start < length && !(start in list)) {
				start++;
			}

			if (start >= length) {
				throw new TypeError('Reduce of empty array with no initial value');
			}

			value = list[start++];

		}


		for (let i = start; i < length; i++) {

			if (i in list) {
				value = predicate(value, list[i], i, list);
			}

		}


		return value;

	};

}

