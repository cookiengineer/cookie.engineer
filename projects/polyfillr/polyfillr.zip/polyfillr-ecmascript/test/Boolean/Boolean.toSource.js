
describe('Boolean.toSource', (assert, expect) => {

	let cmp = 'function Boolean() {\n\t[native code]\n}';

	assert(Boolean.toSource());
	expect(Boolean.toSource(), cmp);

});

