
describe('String.toSource', (assert, expect) => {

	let cmp = 'function String() {\n\t[native code]\n}';

	assert(String.toSource());
	expect(String.toSource(), cmp);

});

