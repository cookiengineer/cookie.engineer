
if (typeof Object.prototype.toSource !== 'function' && typeof Object.defineProperty === 'function') {

	let _array_to_source  = Array.prototype.toSource || null;
	let _string_to_source = String.prototype.toSource || null;


	Object.defineProperty(Object.prototype, 'toSource', {

		enumerable: false,
		value:      function() {

			let prototype   = Object.getPrototypeOf(this);
			let konstruktor = this.constructor;


			if (this === Array || this === String || this === RegExp) {

				let name = this.toString().split(' ')[1];

				return 'function ' + name + ' {\n\t[native code]\n}';

			} else if (this === Object && prototype === Object.__proto__) {

				return 'function Object() {\n\t[native code]\n}';

			} else if (konstruktor === Array) {

				if (_array_to_source !== null) {
					return _array_to_source.call(this);
				} else {
					return "" + this;
				}

			} else if (konstruktor === Boolean) {

				return '(new Boolean(' + (this).valueOf() + '))';

			} else if (konstruktor === Number) {

				return '(new Number(' + (this).valueOf() + '))';

			} else if (konstruktor === String) {

				if (_string_to_source !== null) {
					return _string_to_source.call(this);
				} else {
					return "" + this;
				}

			} else if (konstruktor === RegExp) {

				return "" + this;

			} else if (konstruktor === Object && prototype !== null && Object.getPrototypeOf(prototype) === null) {

				let list  = Object(this);
				let last  = Object.keys(list).pop();
				let value = '';
				let entry;


				for (let i in list) {

					if (Object.prototype.hasOwnProperty.call(list, i)) {

						entry = list[i];

						value += i + ':';

						if (entry === undefined) {

							value += 'undefined';

						} else if (entry === null) {

							value += 'null';

						} else if (typeof entry === 'number') {

							value += (entry).valueOf();

						} else if (typeof entry === 'string') {

							value += '"' + entry + '"';

						} else if (typeof entry === 'function') {

							if (typeof entry.toSource === 'function') {
								value += entry.toSource();
							} else {
								value += entry.toString();
							}

						} else if (entry instanceof Array || entry instanceof RegExp || entry instanceof String) {

							if (typeof entry.toSource === 'function') {
								value += entry.toSource();
							} else {
								value += entry.toString();
							}

						} else if (entry instanceof Object) {

							// XXX: Surrounding expression brackets
							let tmp = entry.toSource();
							value += tmp.substr(1, tmp.length - 2);

						} else {

							value += (entry).toString();

						}


						if (i !== last) {
							value += ', ';
						}

					}

				}


				return '({' + value + '})';

			}

		}

	});

}

