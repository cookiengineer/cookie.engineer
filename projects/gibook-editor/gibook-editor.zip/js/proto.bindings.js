$('.close').live('click',editor.hide);

$('#wysiwyg .editable').live('click',function(){
	// remove the following line if user has to close the edited frame first!
	editor.hide();
	editor.show($(this),false);
});

$('#wysiwyg .new').live('click',function(){
	editor.hide();
	editor.show($(this),true);
});

$('#jq-edit .append').each(function(){
	$(this).click(function(){
		if(!$(__.element).hasClass('changeable')){
			var mom = $(__.element).parent();
	 	}else{
			var mom = $(__.element);
	 	}

		var ds=' data-rel="'+__.type+'"';
		$('#jq-edit .attributes input').each(function(){
			if($(this).val().length){
				ds+=' data-'+$(this).attr('title')+'="'+$(this).val()+'"';
			}
		});

		var child = '<div'+ds+' class="editable">'+trim($('#jq-edit textarea').val())+'</div>';
		$(mom).append(child);
		$('#jq-edit').find('.save,.del').hide();
	});
});

$('#jq-edit .prepend').each(function(){
	$(this).click(function(){
		if(!$(__.element).hasClass('changeable')){
			var mom = $(__.element).parent();
	 	}else{
			var mom = $(__.element);
	 	}

		var ds=' data-rel="'+__.type+'"';
		$('#jq-edit .attributes input').each(function(){
			if($(this).val().length){
				ds+=' data-'+$(this).attr('title')+'="'+$(this).val()+'"';
			}
		});

		var child = '<div'+ds+' class="editable">'+trim($('#jq-edit textarea').val())+'</div>';
		$(mom).find("div[data-rel='gi:title']:first").after(child);
		$('#jq-edit').find('.save,.del').hide();
	});
});

$('#jq-edit .del').click(function(){
	var x = $(__.element);
	if($(x).data('rel')=='gi:title'){
		var y = $(x).parent();
		if($(y).hasClass('changeable')){
			if($(y).attr('title')){
				var z = $(y).attr('title');
			}else{
				var z = $(y).data('rel');
			}
			var x = confirm('Kategorie '+z+' wird gelöscht.');
			if(x==true){
				$(y).remove();
			}
		}
	}else{
		$(x).remove();
	}

	editor.hide();
});

$('#jq-edit .save').click(function(){
	var x=trim($('#jq-edit textarea').val());

	$('#jq-edit .attributes').find('select,input').each(function(){
		if($(this).val().length){
			$(__.element).attr('data-'+$(this).attr('title'),$(this).val());
		}
	});

	$(__.element).attr('data-rel',__.type).html(x).removeClass('lorem');
	editor.hide();
});

$('#jq-edit .tags').click(function(){
	var x = "<"+$(this).data('rel')+">";
	var y = "</"+$(this).data('rel')+">";
	editor.apply.tags('preview',x,y);
});

$('#jq-edit .heuristics').click(function(){
	editor.apply.heuristics($('#jq-edit textarea'));
});

$('#jq-table-creator').find('button').each(function(){
	$(this).click(function(){
		var tmp=$(this).text().split('x');
		var x=tmp[0]; var y=tmp[1];
	
		$('#jq-table-creator button').each(function(){
			var tmp=$(this).text().split('x');
			var _=$(this).context.parentNode;
			if(tmp[0]<=x && tmp[1]<=y){
				_.style.backgroundColor="rgba(255,200,200,0.5)";
			}else{
				//_.removeAttribute('style');
				_.style.backgroundColor='';
			}
		});

		$('#jq-table-creator-size').html($(this).text());

	});
});

$('#jq-table .append').click(function(){
	var parent = $(__.element).parent('.changeable');
	var tmp=$('#jq-table-creator-size').text().split('x');

	console.log(parent);

	var child='<table data-rel="l:table"><tbody data-rel="l:tbody">';
	for(y=0;y<tmp[0];y++){
		child+='<tr data-rel="l:tr">';
		for(x=0;x<tmp[1];x++){
			child+='<td data-rel="l:td" class="editable">...</td>';
		}
		child+='</tr>';
	}
	child+='</tbody></table>';

	// var ds=' data-rel="'+__.type+'"';

	//var child = '<div'+ds+' class="editable">'+trim($('#jq-edit textarea').val())+'</div>';
	$(parent).append(child);
	$('#jq-table').hide();
	editor.hide();
});

// TODO: $('#jq-table .append').each(function(){ ... });

$('#jq-file-local button').live('click',function(){
	if($(this).hasClass('del')){
			session.unset($(this).closest('li').data('name'));
	}else if($(this).hasClass('load')){
		session.open($(this).closest('li').data('name'));
		$('#jq-file-server button').attr('disabled','disabled');
	}
});

// TODO TODO TODO
$('#jq-file-server button').live('click',function(){
	$('body').append('<div id="jq-clone"></div>');
	var li=$(this).closest('li');

 	$('#jq-clone').load('php/backend.php?gen=file&hash='+$(li).data('hash'),function(){

 		// walk html in #jq-clone and move it to #wysiwyg
 		parser.build_html($('#jq-clone'),$('#wysiwyg'));

		$('#jq-file-server button').attr('disabled','disabled');
		editor.notify(_('restored')+': '+$(li).html().replace(/<\/?[^<]+/g, ""));

		$('#jq-clone').remove();
	});
});

$('#jq-toolkit .search').live('click',function(){
	$('#jq-toolkit ul').html('<li>Suche...</li>');
	$.get('php/backend.php',{'gen':'metalist','keyword':$('#jq-toolkit input').val()},function(data){
		alert('HELLO');
		$('#jq-toolkit-list').html(data);
	});
});

$('#jq-toolkit .remove-meta').click(function(){
	$('#wysiwyg').find("div[data-rel='gi:meta-daten']").remove();
	editor.hide();
});

// TODO: $('#jq-toolkit button.open')

$('#jq-upload form').submit(function(){
	$('#jq-file-server').load('php/backend.php?gen=list list');
});



$('#jq-menu .new').click(function(){
	editor.hide();
	var x = confirm("Alle Änderungen werden verworfen und ein neues GIBook wird angelegt.");
	if(x==true){
		editor.reload();
	}
	return false;
});


$('#jq-menu .save').click(function(){
	session.save($('#ready_name').val(),$('#wysiwyg').html());
	return false;
});

$('#jq-menu .build').click(function(){
	editor.hide();

	var x=$('#wysiwyg');
	$(x).find('span').remove();

	console.log('- - - BEGIN PARSING - - -');
	var y=parser.build_xml($(x));
	console.log('- - - END PARSING - - -');

	$('#ready_xml').val(y).slideDown('fast').dblclick(function(){
		$(this).slideUp('fast');
	});
	$('#ready_html').val($(x).html());

	$('#jq-menu .download').html('Herunterladen ('+Math.round(y.length/1000)+' kB)').show();
	return false;
});

$('#jq-menu .download').click(function(){
	$(this).closest('form').submit();
});

$('button.jq-show').click(function(){
	var x=$(this).data('jq-clear');
	if(x){
		editor.hide(x);
	}else{
		editor.hide();
	}

	$($(this).context.getAttribute('data-jq-show')).show('fast');
	return false;
});

$('a.jq-show').click(function(){
	editor.hide();
	$($(this).attr('href')).show('fast');
	return false;
});

