
describe('Object.filter', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3 };
	let obj2 = { '0': 1, '1': 2, '2': 3 };

	assert(Object.filter(obj1, (value, prop) => prop !== 'b'));
	assert(Object.filter(obj1, (value, prop) => value !== 2));
	assert(Object.filter(obj2, (value, prop) => prop !== '1'));
	assert(Object.filter(obj2, (value, prop) => value !== 2));


	let tmp1 = Object.filter(obj1, (value, prop) => prop !== 'b');
	let tmp2 = Object.filter(obj1, (value, prop) => value !== 2);
	let tmp3 = Object.filter(obj2, (value, prop) => prop !== '1');
	let tmp4 = Object.filter(obj2, (value, prop) => value !== 2);

	expect(tmp1['a'], 1);
	expect(tmp1['b'], undefined);
	expect(tmp1['c'], 3);

	expect(tmp2['a'], 1);
	expect(tmp2['b'], undefined);
	expect(tmp2['c'], 3);

	expect(tmp3['0'], 1);
	expect(tmp3['1'], undefined);
	expect(tmp3['2'], 3);

	expect(tmp4['0'], 1);
	expect(tmp4['1'], undefined);
	expect(tmp4['2'], 3);

});

