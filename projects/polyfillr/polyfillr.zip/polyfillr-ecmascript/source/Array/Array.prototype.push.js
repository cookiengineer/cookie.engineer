
if (typeof Array.prototype.push !== 'function') {

	Array.prototype.push = function(/* [element1 [, ...[, elementN]]]*/) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.push called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;


		for (let a = 0, al = arguments.length; a < al; a++) {
			list[length++] = arguments[a];
		}


		return length;

	};

}

