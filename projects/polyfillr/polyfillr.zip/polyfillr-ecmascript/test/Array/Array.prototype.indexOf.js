
describe('Array.prototype.indexOf', (assert, expect) => {

	let arr1 = [1,3,2,3,4,3,5];
	let arr2 = [1,3,2,3,4,3,5];
	let arr3 = [1,3,2,3,4,3,5];

	assert(arr1.indexOf(3));
	assert(arr2.indexOf(3, 1));
	assert(arr3.indexOf(3, 4));

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

