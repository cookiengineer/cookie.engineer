
describe('String.prototype.toSource', (assert, expect) => {

	let cmp1 = '(new String("whatever"))';
	let cmp2 = '(new String("awesome\\n123.45"))';
	let str1 = "whatever";
	let str2 = "awesome\n123.45";

	assert(str1.toSource());
	assert(str2.toSource());

	assert(str1);
	assert(str2);

	expect(str1.toSource(), cmp1);
	expect(str2.toSource(), cmp2);

});

