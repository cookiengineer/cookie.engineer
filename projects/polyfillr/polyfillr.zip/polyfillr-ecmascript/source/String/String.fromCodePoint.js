
if (typeof String.fromCodePoint !== 'function') {

	String.fromCodePoint = function(/* ... nums */) {

		let units = [];
		let code;
		let hi;
		let lo;

		let length = arguments.length >>> 0;
		if (length === 0) {
			return '';
		}


		for (let i = 0; i < length; i++) {

			code = Number(arguments[i]);

			if (!isFinite(code) || code < 0 || code > 0x10ffff || ((code | 0) !== code)) {

				throw new RangeError('Invalid code point: ' + code);

			} else {

				if (code <= 0xffff) {

					units.push(code);

				} else {

					code -= 0x10000;
					hi    = (code >> 10)   + 0xD800;
					lo    = (code % 0x400) + 0xDC00;
					units.push(hi, lo);

				}


				if (i + 1 === length || units.length > 0x4000) {
					break;
				}

			}

		}


		return String.fromCharCode.apply(null, units);

	};

}

