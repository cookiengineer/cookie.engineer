
describe('String.prototype.includes', (assert, expect) => {

	let str1 = "This is a simple sentence";
	let str2 = "This is a simple sentence";

	assert(str1.includes('simple'));
	assert(str2.includes('simple',  8));
	assert(str2.includes('simple', 16));

	assert(str1);
	assert(str2);

	expect(str1.includes('simple'),     true);
	expect(str2.includes('simple',  8), true);
	expect(str2.includes('simple', 16), false);

});

