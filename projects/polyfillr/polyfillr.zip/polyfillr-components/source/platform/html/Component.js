
if (typeof Polyfillr === 'undefined') {
	Polyfillr = {};
}

Component = Polyfillr.Component = (function(global) {

	const _document = global.document;



	/*
	 * HELPERS
	 */

	const _fire_event_listener = (function(supports_custom_event) {

		if (supports_custom_event === true) {

			return function(name, data) {

				let element = this;
				let event   = new CustomEvent(name, {
					detail:  data,
					bubbles: false
				});

				if (typeof element.dispatchEvent === 'function') {
					element.dispatchEvent(event);
				}

			};

		} else {

			return function(name, data) {

				let element = this;
				let event   = _document.createEvent('Event');

				event.initEvent(name, false, false);
				event.detail = data;

				if (typeof element.dispatchEvent === 'function') {
					element.dispatchEvent(event);
				}

			};

		}

	})(typeof CustomEvent !== 'undefined');



	/*
	 * IMPLEMENTATION
	 */

	let Component = function(identifier, template) {

		// This API is called via HTML Imports
		Polyfillr.HTML_IMPORT = true;


		this.elements   = [];
		this.events     = {};
		this.identifier = identifier;
		this.observer   = null;
		this.template   = template;



		/*
		 * INITIALIZATION
		 */

		this.addEventListener('create', function(e) {

			let that   = e.target;
			let code   = (that.innerHTML || '').trim();
			let prefix = (template.innerHTML || '').trim();


			// TODO: Iterate over template.querySelectorAll('*')
			// TODO: Iterate over that.querySelectorAll('*')
			//
			// if tagName is the same, replace template's element
			// with the element's one

			if (code !== '') {

				that.innerHTML = prefix + code;

			} else {

				that.innerHTML = prefix;

			}

		}, true);


		if (typeof MutationObserver !== 'undefined') {

			this.observer = new MutationObserver(function(mutations) {

				let changes = [].slice.call(mutations).map(function(mutation) {

					return {
						element: mutation.target,
						name:    'change',
						data:    {
							attribute: mutation.attributeName,
							oldvalue:  mutation.oldValue,
							newvalue:  mutation.target.getAttribute(mutation.attributeName)
						}
					};

				});

				if (changes.length > 0) {

					changes.forEach(function(change) {

						let element = change.element;
						if (typeof element.fireEventListener === 'function') {
							element.fireEventListener(change.name, change.data);
						}

					});

				}

			});

		}

	};


	Component.prototype = {

		create: function(element) {

			if (element === null || element === undefined) {
				element = _document.createElement(this.identifier);
			} else {
				element.tagName = this.identifier;
			}


			let elements = this.elements;
			let events   = this.events;
			let observer = this.observer;


			if (elements.indexOf(element) === -1) {

				for (let eid in events) {

					if (events.hasOwnProperty(eid)) {

						events[eid].forEach(function(map) {

							element.addEventListener(
								map.name,
								map.callback.bind(element),
								map.bubble
							);

							element.fireEventListener = _fire_event_listener.bind(element);

						});

					}

				}


				element.fireEventListener('create', null);
				elements.push(element);


				if (observer !== null) {

					observer.observe(element, {
						attributes:        true,
						attributeOldValue: true
					});

				}

			}


			return element;

		},

		destroy: function(element) {

			let elements = this.elements;
			let observer = this.observer;

			let e = elements.indexOf(element);
			if (e !== -1) {

				if (observer !== null) {
					// XXX: WTF is this shit? disconnect()
					// stops the MutationObserver. FUCK YOU, WHATWG.
					// observer.disconnect(element);
				}


				if (typeof element.fireEventListener === 'function') {
					element.fireEventListener('destroy', null);
					delete element.fireEventListener;
				}

				elements.splice(e, 1);


				return true;

			}


			return false;

		},

		addEventListener: function(name, callback, bubble) {

			name     = typeof name === 'string'     ? name     : null;
			callback = callback instanceof Function ? callback : null;
			bubble   = bubble === true;


			if (name !== null && callback !== null) {

				let events = this.events;
				if (events[name] === undefined) {
					events[name] = [];
				}

				events[name].push({
					name:     name,
					callback: callback,
					bubble:   bubble
				});


				return true;

			}


			return false;

		},

		removeEventListener: function(name, callback) {

			name     = typeof name === 'string'     ? name     : null;
			callback = callback instanceof Function ? callback : null;


			if (name !== null && callback !== null) {

				let events = this.events[name] || null;
				if (events !== null) {

					for (let e = 0; e < events.length; e++) {

						if (events[e].callback === callback) {
							events.splice(e, 1);
							e--;
						}

					}

				}


				return true;

			} else if (name !== null) {

				let events = this.events[name] || null;
				if (events !== null) {
					delete this.events[name];
				}


				return true;

			}


			return false;

		}

	};


	return Component;

})(typeof window !== 'undefined' ? window : this);

