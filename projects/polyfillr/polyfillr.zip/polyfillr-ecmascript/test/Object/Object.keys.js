
describe('Object.keys', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3 };
	let obj2 = { '0': 1, '1': 2, '2': 3 };


	assert(Object.keys(obj1));
	assert(Object.keys(obj2));

	assert(obj1);
	assert(obj2);

	let tmp1 = Object.keys(obj1);
	let tmp2 = Object.keys(obj2);

	expect(tmp1[0], 'a');
	expect(tmp1[1], 'b');
	expect(tmp1[2], 'c');

	expect(tmp2[0], '0');
	expect(tmp2[1], '1');
	expect(tmp2[2], '2');

});

