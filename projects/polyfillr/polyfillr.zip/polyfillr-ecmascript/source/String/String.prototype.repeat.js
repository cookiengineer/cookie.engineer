
if (typeof String.prototype.repeat !== 'function') {

	String.prototype.repeat = function(/* count */) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.repeat called on null or undefined');
		}


		let value  = String(this);
		let count  = arguments.length >= 1 ? (arguments[0] | 0) : 0;
		let length = value.length >>> 0;
		let result = '';


		if (count === 0) {
			return result;
		} else if (!isFinite(count)) {
			throw new RangeError('Invalid count value');
		}


		if ((length * count) <= (1 << 28)) {

			for (let c = 0; c < count; c++) {
				result += value;
			}

		}


		return result;

	};

}

