
# Polyfillr Components

A modern plug-and-play Web Components library.

This project implements a Web Components API to
create, modify, and compose Web Components. It
has no further dependencies.

The website [polyfillr.github.io](https://polyfillr.github.io)
allows to select the feature set of a custom build.

brought to you as libre software with joy and pride by [Artificial Engineering](http://artificial.engineering).

Support our libre Bot Cloud via BTC [1CamMuvrFU1QAMebPoDsL3JrioVDoxezY2](bitcoin:1CamMuvrFU1QAMebPoDsL3JrioVDoxezY2?amount=0.5&label=lychee.js%20Support).



## Overview

[Online Demo](https://polyfillr.github.io/demo/components.html)


## Implemented Custom API

Polyfillr Components offer a jQuery-compatible syntax, as they
allow using `$(component).on('create', (e) => {})` syntax to
bind events.

All Components use Standard Syntax and the Template element.
Some examples can be found in the [./test](./test/) folder.


- `(Component || null) Polyfillr.get(identifier)`
- `(Component || null) Polyfillr.define(identifier, template)`


**create event**

The `create` event is fired on each created Element, no matter
if they are inside or outside the DOM:

```javascript
let template  = document.querySelector('#template');
let component = Polyfillr.define('my-component', template);

component.addEventListener('create', function(e) {
	let element = e.target;
	console.log(element);
}, true);
```

**change event**

The `change` event is fired on each changed attribute of each
Element, no matter if they are inside or outside the DOM:

```javascript
let template  = document.querySelector('#template');
let component = Polyfillr.define('my-component', template);

component.addEventListener('change', function(e) {

	let element = e.target;
	let attribute = e.detail.attribute;
	let oldvalue  = e.detail.oldvalue;
	let newvalue  = e.detail.newvalue;

	console.log(element, attribute, oldvalue, newvalue);

}, true);
```


## License

This project is released under [GNU GPL 3](./LICENSE_GPL3.txt) license.

