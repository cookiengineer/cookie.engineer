
# AdBlock Proxy

## This project is not maintained anymore. The resulting new project is the stealth-browser.


A Web Proxy alone is very limited in what kind of requests it can see,
filter and process (or send back to the browser or client).

As most Web Browsers have moved on to TLS/HTTPS requests by default,
it doesn't make sense to use a Web Proxy that cannot block anything.

So this project is dead, and I learned from it.

The logical evolution of both my experimental Web Browser "Research"
and this "AdBlock Proxy" is the [stealth-browser](https://github.com/cookiengineer/stealth-browser).

So support-wise, I recommend heavily to use the Stealth Browser instead,
as it is a Browser that is written from scratch; and it is actually
not a Browser, but a Scraper, Web Proxy and Spider, too - and comes
with many mindblowing features that try to automate the Semantic Web.

Feature-wise, the Stealth Service is a superset of what AdBlock Proxy
ever was, and it can be used as an ad-blocking Web Proxy, too.

Kind Regards from probably somewhere around Europe,
~Cookie (@cookiengineer)

