
describe('Array.prototype.join', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [1,2,3,4,5];

	assert(arr1.join());
	assert(arr2.join(1337));
	assert(arr3.join('\n'));

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

