
if (typeof Array.prototype.lastIndexOf !== 'function') {

	Array.prototype.lastIndexOf = function(search/*, from */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.lastIndexOf called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let from   = arguments.length >= 2 ? (arguments[1] | 0) : 0;


		if (length === 0 || from >= length) {
			return -1;
		}


		let start = length - 1;
		if (from !== 0) {
			start = (from > 0 ? from : -1) * Math.abs(from);
		}


		for (let i = (start >= 0 ? Math.min(start, length - 1) : (length - Math.abs(start))); i >= 0; i--) {

			if (i in list) {

				if (list[i] === search) {
					return i;
				}

			}

		}


		return -1;

	};

}

