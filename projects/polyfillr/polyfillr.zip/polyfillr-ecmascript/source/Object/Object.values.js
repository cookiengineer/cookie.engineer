
if (typeof Object.values !== 'function') {

	Object.values = function(object) {

		if (object !== Object(object)) {
			throw new TypeError('Object.values called on a non-object');
		}


		let values = [];

		for (let prop in object) {

			if (Object.prototype.hasOwnProperty.call(object, prop)) {
				values.push(object[prop]);
			}

		}

		return values;

	};

}

