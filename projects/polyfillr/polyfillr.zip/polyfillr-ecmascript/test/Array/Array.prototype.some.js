
describe('Array.prototype.some', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [1,2,3,4,5];

	let cmp1 = function(element, index, self) {
		return element >= 3;
	};

	let cmp2 = function(element, index, self) {
		return undefined;
	};


	assert(arr1.some(cmp1));
	assert(arr2.some(cmp2));

	try {
		assert(arr3.some());
	} catch(err) {
		assert((err).toString());
	}

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

