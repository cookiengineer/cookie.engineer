
describe('Object.sort', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3, d: 4 };
	let obj2 = { b: 1, a: 2, d: 3, c: 4 };
	let obj3 = { '0': 1, '1': 2, '2': 3, '3': 4 };
	let obj4 = { '1': 1, '0': 2, '3': 3, '2': 4 };


	assert(Object.sort(obj1));
	assert(Object.sort(obj2));
	assert(Object.sort(obj3));
	assert(Object.sort(obj4));


	let cmp1 = 'a-b-c-d';
	let cmp2 = '0-1-2-3';
	let tmp1 = Object.keys(Object.sort(obj1));
	let tmp2 = Object.keys(Object.sort(obj2));
	let tmp3 = Object.keys(Object.sort(obj3));
	let tmp4 = Object.keys(Object.sort(obj4));


	expect(tmp1.join('-'), cmp1);
	expect(tmp2.join('-'), cmp1);
	expect(tmp3.join('-'), cmp2);
	expect(tmp4.join('-'), cmp2);

});

