function calc_check(input){
 var allowed = "0123456789[]()-+*%/.";
 for(var i = 0; i < input.length; i++){
  if(allowed.indexOf(input.charAt(i)) < 0){
   return false;
  }
 }
 return true;
}

function calc_result(){
 var x = 0;
 var display = document.getElementById('calc_display');
 if(calc_check(display.value)){
  x = eval(display.value);
 }
 display.value = x;
}

function calc_add(string){
 var display = document.getElementById('calc_display');
 display.value = display.value + string;
}

function calc_do(what){
 var display=document.getElementById('calc_display');
 if(calc_check(display.value)){
  if(what == "sqrt") {
   var x = 0;
   x = eval(display.value);
   display.value = Math.sqrt(x);
  }
  if(what == "pow"){
   var x = 0;
   x = eval(display.value);
   display.value = x * x;
  }
  if (what == "ln"){
   var x = 0;
   x = eval(display.value);
   display.value = Math.log(x);
  }
 }else{
  display.value = 0;
 }
}