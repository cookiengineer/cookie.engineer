
if (typeof Object.toSource !== 'function') {

	Object.toSource = function() {
		return 'function Object() {\n\t[native code]\n}';
	};

}

