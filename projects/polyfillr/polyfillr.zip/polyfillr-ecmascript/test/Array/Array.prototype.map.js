
describe('Array.prototype.map', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [1,2,3,4,5];

	let cmp1 = function(element, index, self) {
		return element >= 3;
	};

	let cmp2 = function(element, index, self) {
		return element + '-' + index;
	};


	assert(arr1.map(cmp1));
	assert(arr2.map(cmp2));

	try {
		assert(arr3.map());
	} catch(err) {
		assert((err).toString());
	}

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);


	let tmp1 = arr1.map(cmp1);
	let tmp2 = arr2.map(cmp2);

	expect(tmp1[0], false);
	expect(tmp1[1], false);
	expect(tmp1[2], true);
	expect(tmp1[3], true);
	expect(tmp1[4], true);

	expect(tmp2[0], '1-0');
	expect(tmp2[1], '2-1');
	expect(tmp2[2], '3-2');
	expect(tmp2[3], '4-3');
	expect(tmp2[4], '5-4');

});

