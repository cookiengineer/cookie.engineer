<?php

class libMail{

 public function __construct($email,&$config){
  if(is_array($config)){
   $this->config=$config;
  }

  $db=$this->config['db'];
  if($db['host'] && $db['user'] && $db['pass'] && $db['name']){
   $this->link=mysql_connect($db['host'],$db['user'],$db['pass']);
   if(mysql_select_db($db['name'],$this->link)){
    if($this->userid=$this->getId($email)){
     return true;
    }
   }
  }
  return false;
 }

 public function getBox($folder){
  switch($folder){
   default:
   case "inbox":
    $sql="
     SELECT messages.*
     FROM messages, users
     WHERE
      users.id='".$this->userid."'
      AND users.id=messages.to;";
   break;
   case "sent":
    $sql="
     SELECT messages.*
     FROM messages, users
     WHERE
      users.id='".$this->userid."'
      AND users.id=messages.from;";
   break;
  }
  $result=mysql_query($sql,$this->link);
  if($result){
   while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $return[]=$row;
   }
   return $return;
  }
 }

 public function getName($id){
  $sql="
   SELECT contacts.name
   FROM contacts
   WHERE
    contacts.id='".$id."'
   LIMIT 1;";

  $result=mysql_query($sql,$this->link);
  if($result){
   $arr = mysql_fetch_array($result, MYSQL_ASSOC);
   if(is_array($arr)){
    return $arr['name'];
   }else{
    return "Unknown (#".$id.")";
   }
  }
  return false;
 }

 public function getId($email){
  $sql="
   SELECT users.*
   FROM users
   WHERE
    users.email='".$email."'
   LIMIT 1;";
  $result=mysql_query($sql,$this->link);

  if($result){
   $arr = mysql_fetch_array($result, MYSQL_ASSOC);
   if(is_array($arr)){
    return $arr['id'];
   }else{
    return false;
   }
  }
  return false;
 }

 public function getDetails($id){
 $sql="
  SELECT contacts.*
  FROM contacts, users
  WHERE
   contacts.owner='".$this->userid."'
  AND contacts.id='".$id."'
  LIMIT 1;";

  $result=mysql_query($sql,$this->link);
  if($result){
   while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $return=$row; // only one contact
   }
   return $return;
  }
  return false;
 }


 public function getContacts($limiter){
  if($limiter=="sidebar"){
   $sql="
    SELECT contacts.*
    FROM contacts
    WHERE contacts.owner='".$this->userid."'
    AND contacts.im_sidebar='1';";
  }else{
   $sql="
    SELECT contacts.*
    FROM contacts
    WHERE contacts.owner='".$this->userid."';";
  }
  $result=mysql_query($sql,$this->link);
  if($result){
   while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    $return[]=$row;
   }
   return $return;
  }
  return false;
 }

}
?>