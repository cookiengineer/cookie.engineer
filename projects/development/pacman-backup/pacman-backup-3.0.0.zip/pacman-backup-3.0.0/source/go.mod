module pacman-backup

go 1.26.0

require golang.org/x/term v0.45.0

require golang.org/x/sys v0.47.0 // indirect
