
#ifndef _STEGIT_H
#define _STEGIT_H

#include "arc.h"

#define BITSHIFT      0
#define MAX_DEPTH     3    /* Max. Bytes per pixel */
#define MAX_SEEK      1024 /* Max. Number of pixels for foil stats */
#define STEG_EMBED    0x01
#define STEG_MARK     0x02
#define STEG_ERROR    0x08
#define STEG_RETRIEVE 0x10
#define STEG_STATS    0x20

extern int steg_stat;

/*
 * The generic bitmap structure.  An object is passed in and an object
 * dependant function extracts all bits that can be modified to embed
 * data into a bitmap structure.  This allows the embedding be independant
 * of the carrier data.
 */

typedef struct _bitmap {
	u_char *bitmap;   /* the bitmap */
	u_char *locked;   /* bits that may not be modified */
	u_char *metalock; /* bits that have been used for foil */
	char *detect;     /* relative detectability of changes */
	char *data;       /* data associated with the bit */
	int bytes;        /* allocated bytes */
	int bits;         /* number of bits in here */

	/* function to call for preserve stats */
	int (*preserve)(struct _bitmap *, int);
	size_t maxcorrect;
} bitmap;

#define STEG_ERR_HEADER 1
#define STEG_ERR_BODY   2
#define STEG_ERR_PERM   3

typedef struct _stegres {
	int error;   /* Errors during steg embed */
	int changed; /* Number of changed bits in data */
	int bias;    /* Accumulated bias of changed bits */
} stegres;

typedef struct _config {
	int flags;
	int siter;
	int siterstart;
} config;

#define TEST_BIT(x,y)       ((x)[(y) / 8] & (1 << ((y) & 7)))
#define WRITE_BIT(x,y,what) ((x)[(y) / 8] = ((x)[(y) / 8] & ~(1 << ((y) & 7))) | ((what) << ((y) & 7)))

#define SWAP(x,y) do {int n = x; x = y; y = n;} while(0);

void *checkedmalloc(size_t n);

u_char *encode_data(u_char *, int *, struct arc4_stream *, int);
u_char *decode_data(u_char *, int *, struct arc4_stream *, int);

struct _iterator;

stegres steg_embed(bitmap *bitmap, struct _iterator *iter, struct arc4_stream *as, u_char *data, u_int datalen, u_int16_t seed, int embed);
u_int32_t steg_retrbyte(bitmap *bitmap, int bits, struct _iterator *iter);

char *steg_retrieve(int *len, bitmap *bitmap, struct _iterator *iter, struct arc4_stream *as, int);

void mmap_file(char *name, u_char **data, int *size);
void munmap_file(u_char *data, int len);

#endif /* _STEGIT_H */

