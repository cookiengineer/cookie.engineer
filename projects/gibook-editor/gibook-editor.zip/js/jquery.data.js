// extending jQuery for data-attributes
(function($){
	$.fn.extend({
		'_data': $.fn.data,
		'data' : function(key,value){
			if(typeof key === "undefined" && this.length){
				return jQuery.data(this[0]);
			}else if(typeof key === "object"){
				return this.each(function(){
					jQuery.data(this,key);
				});
			}

			var retValue;
			retValue = $.fn._data(key, value);
			if('undefined' == (typeof retValue) || retValue.length == 0){
				var nakedElem = this.get(0);
				//if(nakedElem.hasOwnProperty('dataset')){
				//if('undefined' != (typeof nakedElem.dataset)){
				//	retValue = nakedElem.dataset[key];
				//}else{
					retValue = nakedElem.getAttribute('data-'+key);
				//}

				//console.log('data-'+key+'='+retValue);
				//console.log('--->'+nakedElem.dataset[key]);
				//console.log(nakedElem.getAttribute('data-'+key));
				//	retValue = this.attr('data-'+key);
			}
			return retValue;
		},
	});

})(jQuery);