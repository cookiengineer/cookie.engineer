
import { console } from '../extern/base.mjs';



// Debuggable constants
window.console = console;

console.log('FUCK');

