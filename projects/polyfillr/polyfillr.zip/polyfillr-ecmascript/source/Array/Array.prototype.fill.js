
if (typeof Array.prototype.fill !== 'function') {

	Array.prototype.fill = function(value/*, start = 0, end = this.length */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.fill called on null or undefined');
		}


		let list      = Object(this);
		let length    = list.length >>> 0;
		let start     = arguments[1];
		let end       = arguments[2];
		let rel_start = start === undefined ?      0 : start >> 0;
		let rel_end   = end === undefined   ? length : end >> 0;


		let i_start = rel_start < 0 ? Math.max(length + rel_start, 0) : Math.min(rel_start, length);
		let i_end   = rel_end < 0   ? Math.max(length + rel_end, 0)   : Math.min(rel_end, length);

		for (let i = i_start; i < i_end; i++) {
			list[i] = value;
		}


		return list;

	};

}

