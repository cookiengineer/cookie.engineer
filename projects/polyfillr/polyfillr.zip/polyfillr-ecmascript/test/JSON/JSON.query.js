
describe('JSON.query', (assert, expect) => {

	let data = {
		foo: {
			bar: {
				qux: [ 'doo' ]
			}
		},
		bar: {
			qux: {
				foo: 13.37
			},
			doo: [ 1, 3, 3, 7 ]
		},
		qux: {
			doo: ''
		}
	};


	expect(JSON.query(data, ''),                   data);
	expect(JSON.query(data, '>'),                  data);
	expect(JSON.query(data, 'does > not > exist'), null);

	expect(JSON.query(data, 'foo > bar'),           data['foo']['bar']);
	expect(JSON.query(data, 'foo > bar > qux'),     [ 'doo' ]);
	expect(JSON.query(data, 'foo > bar > qux > 0'), 'doo');

	expect(JSON.query(data, 'bar > qux > foo'), 13.37);
	expect(JSON.query(data, 'bar > doo'),       [ 1, 3, 3, 7 ]);
	expect(JSON.query(data, 'bar > doo > 0'),   1);
	expect(JSON.query(data, 'bar > doo > 1'),   3);
	expect(JSON.query(data, 'bar > doo > 2'),   3);
	expect(JSON.query(data, 'bar > doo > 3'),   7);

	expect(JSON.query(data, 'qux > doo'), '');

});

