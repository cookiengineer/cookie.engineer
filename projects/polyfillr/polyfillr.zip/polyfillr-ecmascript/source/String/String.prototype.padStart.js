
if (typeof String.prototype.padStart !== 'function') {

	String.prototype.padStart = function(length/*, chunk */) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.padStart called on null or undefined');
		}


		length = length >> 0;


		let chunk = arguments.length >= 2 ? String(arguments[1] || '') : '';
		let value = (this).toString();

		if (this.length > length) {
			return value;
		}


		let tmp = length - this.length;
		if (tmp > chunk.length) {
			chunk += chunk.repeat(tmp / chunk.length);
		}

		return chunk.slice(0, tmp) + value;

	};

}

