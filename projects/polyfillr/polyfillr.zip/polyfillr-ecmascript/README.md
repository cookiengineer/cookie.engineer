
# Polyfillr ECMAScript

A modern plug-and-play standard library.

This project implements the [ECMAScript 2016](http://www.ecma-international.org/ecma-262/7.0/)
API and has no further dependencies.

The website [polyfillr.github.io](https://polyfillr.github.io)
allows to select the feature set of a custom build.

brought to you as libre software with joy and pride by [Artificial Engineering](http://artificial.engineering).

Support our libre Bot Cloud via BTC [1CamMuvrFU1QAMebPoDsL3JrioVDoxezY2](bitcoin:1CamMuvrFU1QAMebPoDsL3JrioVDoxezY2?amount=0.5&label=lychee.js%20Support).



## Overview

[Online Demo](https://polyfillr.github.io/demo/ecmascript.html)


**Usage (Browser)**

Include the build script into the `<head>` so that
every following script can use the ECMAScript APIs:

```html
<!DOCTYPE html>
<html>
<head>
	<!-- OLD BROWSER? Use ecmascript.es5.js instead -->
	<script src="./bower_components/polyfillr/build/html/ecmascript.es6.js"></script>
</head>
<body>
	<script>
	console.log([
		'Hello',
		'Hello',
		'world',
		'world',
		'!',
		'!'
	].unique());
	</script>
</body>
```

**Usage (node.js)**

Require the build script before other scripts, so that
every following script can use the ECMAScript APIs:

```javascript
// OLD NODE? Use ecmascript.es5.js instead
require('./bower_components/polyfillr/build/ecmascript.es6.js');
```


## Requirements

- Bitshift operators in general have to work (`>>>`, `>>` and `<<`).
- Arithmetic operators in general have to work (`+`, `-`, `*`, `/` and `%`).
- Boolean operators in general have to work on expressions (`!` and `!!`).
- `null` and `undefined` have to exist as literals.
- `for (x in y)` has to work on enumerable properties.
- `Object(this)` has to return an Object reference.
- `Object(x) === x` has to be true if x was inheriting from Object.
- `Object.getPrototypeOf(Object(x)) === x.__proto__` has to be true if x was inheriting from Object.
- `Array` instances have to offer a `length` property.


## Limitations

- No `@@iterator` Support.
- No Iterables (`next()` usage) Support. Iterables might be implemented in future though.
- No binary literal (`0b110`) Support.
- No octal literal (`0o7`) Support.


## Implemented Standard API

These APIs are standardized in the
[ECMAScript 2016 specification](http://www.ecma-international.org/ecma-262/7.0/).

- `Array.prototype.copyWithin(target, start [, end ])`
- `Array.prototype.concat([value1 [, ...[, valueN ]]])`
- `Array.prototype.every(predicate [, thisArg ])`
- `Array.prototype.fill(value [, start, end ])`
- `Array.prototype.filter(predicate [, thisArg ])`
- `Array.prototype.find(predicate [, thisArg ])`
- `Array.prototype.findIndex(predicate [, thisArg ])`
- `Array.prototype.forEach(predicate [, thisArg ])`
- `Array.prototype.includes(search, [, fromIndex ])`
- `Array.prototype.indexOf(element [, fromIndex ])`
- `Array.prototype.join(separator)`
- `Array.prototype.lastIndexOf(element [, fromIndex ])`
- `Array.prototype.map(predicate [, thisArg ])`
- `Array.prototype.pop()`
- `Array.prototype.push([element1 [, ...[, elementN ]]])`
- `Array.prototype.reduce(predicate [, initialValue ])`
- `Array.prototype.reduceRight(predicate [, initialValue ])`
- `Array.prototype.some(predicate [, thisArg ])`
- `Array.prototype.slice([start, end ])`
- `Array.prototype.splice(start, count [, element1 [, ... [, elementN ]]])`
- `Array.prototype.toLocaleString()`
- `Array.prototype.toString()`
- `Number.EPSILON`
- `Number.MAX_SAFE_INTEGER`
- `Number.MIN_SAFE_INTEGER`
- `Number.isFinite(value)`
- `Number.isInteger(value)`
- `Number.isNaN(value)`
- `Number.isSafeInteger(value)`
- `Number.prototype.toLocaleString()`
- `Object.assign(object [, ... sources ])`
- `Object.entries(object)`
- `Object.is(a, b)`
- `Object.keys(object)`
- `Object.prototype.toLocaleString()`
- `String.fromCodePoint(num1 [, ... [, numN ]])`
- `String.prototype.codePointAt(index)`
- `String.prototype.endsWith(search [, toIndex ])`
- `String.prototype.includes(search [, fromIndex ])`
- `String.prototype.padEnd(targetLength [, padString ])`
- `String.prototype.padStart(targetLength [, padString ])`
- `String.prototype.repeat(count)`
- `String.prototype.startsWith(search [, fromIndex ])`
- `String.prototype.trim()`
- `String.prototype.trimEnd()`
- `String.prototype.trimLeft()`
- `String.prototype.trimRight()`
- `String.prototype.trimStart()`


## Implemented Proposal API

These APIs are **not** standardized in the
[ECMAScript 2016 specification](http://www.ecma-international.org/ecma-262/7.0/).

- `Array.toSource()`
- `Array.prototype.unique()`
- `Array.prototype.toSource()`
- `Boolean.toSource()`
- `Boolean.prototype.toJSON()`
- `Boolean.prototype.toSource()`
- `Date.prototype.toJSON()`
- `JSON.query(object [, query ])`
- `Number.toSource()`
- `Number.prototype.toJSON()`
- `Number.prototype.toSource()`
- `Object.filter(object, predicate [, thisArg ])`
- `Object.find(object, predicate [, thisArg ])`
- `Object.map(object, predicate [, thisArg ])`
- `Object.sort(object)`
- `Object.values(object)`
- `Object.toSource()`
- `Object.prototype.toSource()`
- `RegExp.toSource()`
- `RegExp.prototype.toSource()`
- `String.toSource()`
- `String.prototype.toJSON()`
- `String.prototype.toSource()`


# Work-in-Progress

- `ArrayIterator`
- `Array.prototype.reverse()`
- `Array.prototype.shift()`
- `Array.prototype.sort()`
- `Array.prototype.unshift()`
- `Number.parseFloat()`
- `Number.parseInt()`
- `Object.setPrototypeOf()`


# Impossible To Implement

These ECMAScript specifications are impossible to implement
without a transpiler workflow. We don't do transpiler stuff
here, we do only polyfills, so sadly those can't be properly
supported.

- `Array.prototype.entries()` returns an `Array Iterator` and requires `for/of` loops.
- `Array.prototype.values()` returns an `Array Iterator` and requires `for/of` loops.
- `Array.prototype.keys()` returns an `Array Iterator` and requires `for/of` loops.
- `Date.prototype.toLocaleString([ locales [, options]])` is too high in complexity.


## License

This project is released under [GNU GPL 3](./LICENSE_GPL3.txt) license.

