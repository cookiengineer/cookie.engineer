
if (typeof Number.prototype.toSource !== 'function') {

	Number.prototype.toSource = function() {
		return '(new Number(' + (this).valueOf() + '))';
	};

}

