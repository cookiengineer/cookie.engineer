
StegIt v0.1 by Cookie Engineer (@cookiengineer)
Copyright 2008. All rights reserved.


# Installation

```bash
./configure;
make;
```

Note: There is an optimization bug in `gcc`, you might have to compile with `-O0`.


# Usage

stegit -k mysecurekey123 -d hidden.txt input.jpg encrypted.jpg
stegit -k mysecurekey123 -r encrypted.jpg restored-message.txt

# Included Third-Party Libraries

- Markus Kuhn's Stirmark software
- Independent JPEG Group's JPEG software
- Arc4 random number generator for OpenBSD, (c) 1996 by David Mazieres
- MD5 code by Colin Plumb.

