#!/usr/bin/env node

const _fs = require('fs');


Polyfillr = {};
require('../build/node/console.es5.js');


let code  = _fs.readFileSync('./test/index.js').toString('utf8');
let scope = {
	console: new Polyfillr.Console('default')
};



with (scope) {
	eval(code);
}

