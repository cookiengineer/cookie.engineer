
# Developer Notes

Personal notes from `@cookiengineer` for unautomated
tasks that might get forgotten in future.



## Font Generation

Custom Font needs to be installed first, it
is stored in `asset/KenVectorFuture.ttf`.

Both `state/Game.fnt` and `source/ui/entity/Timeout.fnt`
are generated with:

- `family` set to `KenVector Future`
- `size` set to `40 (px)`
- `style` set to `normal`
- `spacing` set to `4 (px)`
- `outline` set to `1 (px)`

