
if (typeof Array.prototype.toLocaleString !== 'function') {

	Array.prototype.toLocaleString = function() {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.toLocaleString called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let value  = '';
		let tmp;


		for (let i = 0; i < length; i++) {

			if (i in list) {

				tmp = list[i];

				if (tmp !== undefined && tmp !== null) {

					if (typeof tmp.toLocaleString === 'function') {
						value += tmp.toLocaleString();
					} else {
						value += tmp.toString();
					}

				}

			}

			if (i !== length - 1) {
				value += ',';
			}

		}


		return value;

	};

}

