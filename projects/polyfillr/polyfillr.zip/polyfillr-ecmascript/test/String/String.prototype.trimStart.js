
describe('String.prototype.trimStart', (assert, expect) => {

	let cmp1 = "This is a simple sentence";
	let cmp2 = "This is a simple sentence \t\n ";
	let str1 = " \n\t This is a simple sentence";
	let str2 = "This is a simple sentence \t\n ";

	assert(str1.trimStart());
	assert(str2.trimStart());

	assert(str1);
	assert(str2);

	expect(str1.trimStart(), cmp1);
	expect(str2.trimStart(), cmp2);

});

