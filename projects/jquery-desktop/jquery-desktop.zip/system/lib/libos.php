<?php

class libOS{
 var $loaded;
 var $tasks;
 var $windows;
 var $icons;
 var $quickies;
 var $desklets = array();

 public function __construct($file,&$config){
  if(is_file($file)){
   $xml = simplexml_load_file($file);
   $this->config=$this->xmlToArray($xml);
  }
  if(is_array($this->config) && is_array($config)){
   $config=$this->config=array_merge($config,$this->config);
   return true;
  }elseif(is_array($this->config)){
   $config=$this->config;
  }
  return false;
 }

 function xmlToArray($xml){
  if($xml instanceof SimpleXMLElement){
   $children = $xml->children();
   $return = null;
  }

  foreach($children as $element => $value){
   if($value instanceof SimpleXMLElement){
    $values = (array)$value->children();
    if(count($values) > 0){
     $return[$element] = $this->xmlToArray($value);
    }else{
     if(!isset($return[$element])){
      $return[$element] = (string)$value;
     }else{
      if(!is_array($return[$element])){
       $return[$element] = array($return[$element],(string)$value);
      }else{
       $return[$element][] = (string)$value;
      }
     }
    }
   }
  }

  if(is_array($return)){
   return $return;
  }else{
   return $false;
  }
 }

 private function includeToCache($app,$file){
  ob_start();
  include($file);
  $cache=ob_get_contents();
  ob_end_clean();
  return $cache;
 }

 public function init(){
  $config=$this->config;

  foreach($config['app'] as $id => $app){
   if(is_file($config['env']['apps_dir']."/".$app."/config.xml")){
    $config['env']['app_dir']=$config['env']['apps_dir']."/".$app;
    $string = file_get_contents($config['env']['apps_dir']."/".$app."/config.xml");

    foreach($config['env'] as $key => $val){
     $string = preg_replace("~{".$key."}~Uis",$val,$string);
    }

    $xml = simplexml_load_string($string);
    $this->loaded['apps'][$app]=$this->xmlToArray($xml);

    if(!empty($this->loaded['apps'][$app]['require']) && is_file($this->loaded['apps'][$app]['require'])){
     require_once($this->loaded['apps'][$app]['require']);
    }elseif(!empty($this->loaded['apps'][$app]['require']) && !is_file($this->loaded['apps'][$app]['require'])){
     $this->errors[]="404: #app_".$app." requires ".$this->loaded['apps'][$app]['require'];
    }

    if(!empty($this->loaded['apps'][$app]['window'])){
     $this->buildApp($app,$this->loaded['apps'][$app]);
     $this->buildTask($app,$this->loaded['apps'][$app]);
    }
    if($this->loaded['apps'][$app]['show']['desktop']==="true"){
     $this->buildIcon($app,$this->loaded['apps'][$app]);
    }
    if($this->loaded['apps'][$app]['show']['quicklaunch']==="true"){
     $this->buildQuickie($app,$this->loaded['apps'][$app]);
    }

    unset($app);
   }
  }
 }

 private function buildApp($id,$app){
  $cnt['app_id']  = "app_".$id;
  $cnt['task_id'] = "tasks_".$id;
  $cnt['icon']    = $app['icon'];
  $cnt['short']   = $app['short'];
  $cnt['desc']    = $app['desc'];

  $config['env']=$this->config['env'];
  $config['env']['app_dir']=$config['env']['apps_dir']."/".$id;

  if($app['window']['ajax']==="true"){
   $tpl=$this->config['tpl']['window_ajax'];

   if($app['window']['aside']==="true"){
    $cnt['window_aside']="    <div class=\"aside\">".$app['desc']."</div>";
   }elseif(!$app['window']['aside'] || $app['window']['aside']==="false"){
    $cnt['window_aside']="";
   }else{
    if(preg_match("~\.htm~Uis",$app['window']['aside'])){
     $cnt['window_aside']=@file_get_contents($app['window']['aside']);
    }elseif(preg_match("~\.php~Uis",$app['window']['aside'])){
     $cnt['window_aside']=$this->includeToCache($app,$app['window']['aside']);
    }
   }
   if(preg_match("~\.htm~Uis",$app['window']['main'])){
    $cnt['window_main']=@file_get_contents($app['window']['main']);
   }elseif(preg_match("~\.php~Uis",$app['window']['main'])){
    $cnt['window_main']=$this->includeToCache($app,$app['window']['main']);
   }

  }else{
   $tpl=$this->config['tpl']['window_iframe'];
   $cnt['window_main']=$app['window']['main'];
  }

  if(!$app['window']['bottom'] || $app['window']['bottom']==="false"){
   $cnt['window_bottom']="    ".$app['desc'];
  }else{
   if(preg_match("~\.htm~Uis",$app['window']['bottom'])){
    $cnt['window_bottom']=@file_get_contents($app['window']['bottom']);
   }elseif(preg_match("~\.php~Uis",$app['window']['bottom'])){
    $cnt['window_bottom']=$this->includeToCache($app['window']['bottom']);
   }
  }

  $window=file_get_contents($tpl);
  foreach($cnt as $key=>$val){
   $window=preg_replace("~{".$key."}~Uis",$val,$window);
  }

  foreach($config['env'] as $key => $val){
   $key=eregi_replace("_dir","",$key);
   $window=preg_replace("~{".$key."}~Uis",$val,$window);
  }

  if($app['window']['aside']==="false"){
   $window=preg_replace("~frame~Uis","frame noaside",$window);
  }

  $this->windows[]=$window;
 }


 private function buildIcon($id,$app){
  $cnt['app_id']  = "app_".$id;
  $cnt['task_id'] = "tasks_".$id;
  $cnt['icon']    = $app['icon'];
  $cnt['short']   = $app['short'];
  $cnt['desc']    = $app['desc'];

  $tpl=$this->config['tpl']['icon'];
  $icon=file_get_contents($tpl);
  foreach($cnt as $key=>$val){
   $icon=preg_replace("~{".$key."}~Uis",$val,$icon);
  }
  $this->icons[]=$icon;
 }

 private function buildTask($id,$app){
  $cnt['app_id']  = "app_".$id;
  $cnt['task_id'] = "tasks_".$id;
  $cnt['icon']    = $app['icon'];
  $cnt['short']   = $app['short'];
  $cnt['desc']    = $app['desc'];

  $tpl=$this->config['tpl']['task'];
  $task=file_get_contents($tpl);
  foreach($cnt as $key=>$val){
   $task=preg_replace("~{".$key."}~Uis",$val,$task);
  }
  $this->tasks[]=$task;
 }

 private function buildQuickie($id,$app){
  $cnt['app_id']  = "app_".$id;
  $cnt['task_id'] = "tasks_".$id;
  $cnt['icon']    = $app['icon'];
  $cnt['short']   = $app['short'];
  $cnt['desc']    = $app['desc'];

  $tpl=$this->config['tpl']['quickie'];
  $quickie="  ".file_get_contents($tpl);
  foreach($cnt as $key=>$val){
   $quickie=preg_replace("~{".$key."}~Uis",$val,$quickie);
  }
  $this->quickies[]=$quickie;
 }

}

?>