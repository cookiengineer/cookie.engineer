
/*
 * Handling functions for the PNM image format.
 */

#ifndef _PNM_H
#define _PNM_H

#define PNM_THRES_MAX 0xf0
#define PNM_THRES_MIN 0x10

/*
 * This is our raw data object, also used to create JPG or other
 * encoded output.
 */

typedef struct _image {
	int x, y, depth, max;
	u_char *img;
	bitmap *bitmap;
	int flags;
} image;

typedef struct _handler {
	char *extension;
	void (*init)(char *);
	image *(*read)(FILE *);
	void (*write)(FILE *, image *);
	void (*get_bitmap)(bitmap *, image *, int);
	void (*put_bitmap)(image *, bitmap *, int);
	int (*preserve)(bitmap *, int);
} handler;
	
extern handler pnm_handler;

void skip_white(FILE *f);
void init_pnm(char *);
int preserve_pnm(bitmap *, int);
void bitmap_to_pnm(image *img, bitmap *bitmap, int flags);
void bitmap_from_pnm(bitmap *bitmap, image *image, int flags);

image *read_pnm(FILE *fin);
void write_pnm(FILE *fout, image *image);
void free_pnm(image *image);

#endif /* _PNM_H */

