
describe('RegExp.prototype.toSource', (assert, expect) => {

	let cmp1 = '/test|whatever/g';
	let cmp2 = '/test\\/whatever/g';
	let reg1 = /test|whatever/g;
	let reg2 = new RegExp("test/whatever", "g");

	assert(reg1.toSource());
	assert(reg2.toSource());

	expect(reg1.toSource(), cmp1);
	expect(reg2.toSource(), cmp2);

	assert(reg1);
	assert(reg2);

});

