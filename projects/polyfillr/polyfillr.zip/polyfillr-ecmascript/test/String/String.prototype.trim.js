
describe('String.prototype.trim', (assert, expect) => {

	let cmp1 = "This is a simple sentence";
	let str1 = " \n\t This is a simple sentence";
	let str2 = "This is a simple sentence \t\n ";

	assert(str1.trim());
	assert(str2.trim());

	assert(str1);
	assert(str2);

	expect(str1.trim(), cmp1);
	expect(str2.trim(), cmp1);

});

