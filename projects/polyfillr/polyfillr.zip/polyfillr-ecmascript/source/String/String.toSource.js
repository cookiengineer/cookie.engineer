
if (typeof String.toSource !== 'function') {

	String.toSource = function() {
		return 'function String() {\n\t[native code]\n}';
	};

}

