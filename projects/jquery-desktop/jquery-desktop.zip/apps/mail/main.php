<?php
$config['db']=array(
 'host'=>"localhost",
 'name'=>"usr_web138_2",
 'user'=>"web138",
 'pass'=>"f91ehTAE"
);

if(basename($_SERVER['PHP_SELF'])!="main.php"){
 $query[0]="inbox";
}else{
 $query = explode(":",$_SERVER['QUERY_STRING']);
 require_once("../../system/lib/libmail.php");
}

if($query[0]=="compose"){
 $cache="
<div class=\"data\">
 <textarea class=\"abs\">
 Just an example, not ready yet.
 </textarea>
</div>";
}elseif($query[0]=="contacts"){

 if(!empty($query[2]) && $query[1]=="view"){
  $mail = new libMail($_COOKIE['email'],&$config);
  $contact = $mail->getDetails(urldecode($query[2]));
  foreach($contact as $key=>$val){
   $contact[$key]=utf8_encode($val);
  }
  #print_r($details); exit;

  $cache="
<div class=\"data\" id=\"mail_contacts\">
 <img class=\"abs\" src=\"./home/avatars/face\"/>
 <div class=\"abs details\">
  <div>
   <em title=\"Name\">".$contact['name']."</em>
   <p title=\"Birthday\">".date('d.m.Y',$contact['birthday'])."</p>
   <hr/>
   <p title=\"E-Mail\">".$contact['home_email']."</p>
   <p title=\"Web Page\"><a class=\"launch\" href=\"#tasks_web\" rev=\"".$contact['home_webpage']."\">".$contact['home_webpage']."</a></p>
   <p title=\"Phone\">".$contact['home_phone']."</p>
   <p title=\"Fax\">".$contact['home_fax']."</p>
   <p title=\"Voice\">".$contact['home_voice']."</p>
   <address title=\"Address\">
    ".$contact['home_address']."<br/>
    ".$contact['home_zip']." ".$contact['home_city']."<br/>
    ".$contact['home_state']." / ".$contact['home_country']."
   </address>
  </div>

  <div class=\"additional\">
   <em title=\"Company Name\">".$contact['company_name']."</em>
   <p title=\"Company Unit\">".$contact['company_unit']."</p>
   <hr/>
   <p title=\"E-Mail\">".$contact['work_email']."</p>
   <p title=\"Web Page\"><a class=\"launch\" href=\"#tasks_web\" rev=\"".$contact['work_webpage']."\">".$contact['home_webpage']."</a></p>
   <p title=\"Phone\">".$contact['work_phone']."</p>
   <p title=\"Fax\">".$contact['work_fax']."</p>
   <p title=\"Voice\">".$contact['work_voice']."</p>
   <address title=\"Address\">
    ".$contact['work_address']."<br/>
    ".$contact['work_zip']." ".$contact['work_city']."<br/>
    ".$contact['work_state']." / ".$contact['work_country']."
   </address>
  </div>
  <div class=\"additional\">
   <em>Instant Messaging</em>
   <p title=\"ICQ\">".$contact['im_icq']."</p>
   <p title=\"Jabber\">".$contact['im_jabber']."</p>

   <p title=\"Sidebar\">".$contact['im_sidebar']."</p>
   <p title=\"Contact is displayed as\">".$contact['im_displayas']."</p>
  </div>
 </div>
</div>";
 }elseif($query[1]=="add" || $query[1]=="edit"){
  $mail = new libMail($_COOKIE['email'],&$config);
  $contact = $mail->getDetails(urldecode($query[2]));

  $cache="
<div class=\"data\" id=\"mail_contacts\">
 <img class=\"abs\" src=\"./home/avatars/face\"/>
 <div class=\"abs details\">
  <div>
   <em title=\"Name\"><input type=\"text\" name=\"in[name]\" value=\"".$contact['name']."\"/></em>
   <p title=\"Birthday\"><input type=\"text\" name=\"in[birthday]\" value=\"".date('d.m.Y',$contact['birthday'])."\"/></p>
   <hr/>
   <fieldset>
    <legend>Home Details</legend>
     <p title=\"E-Mail\"><input type=\"text\" name=\"in[home_email]\" value=\"".$contact['home_email']."\"/></p>
     <p title=\"Web Page\"><input type=\"text\" name=\"in[home_webpage]\" value=\"".$contact['home_webpage']."\"/></p>
     <p title=\"Phone\"><input type=\"text\" name=\"in[home_phone]\" value=\"".$contact['home_phone']."\"/></p>
     <p title=\"Fax\"><input type=\"text\" name=\"in[home_fax]\" value=\"".$contact['home_fax']."\"/></p>
     <p title=\"Voice\"><input type=\"text\" name=\"in[home_voice]\" value=\"".$contact['home_voice']."\"/></p>
    </fieldset>
   <fieldset>
    <legend>Home Address</legend>
    <input type=\"text\" name=\"in[home_address]\" value=\"".$contact['home_address']."\"/><br/>
    <input type=\"text\" name=\"in[home_zip]\" value=\"".$contact['home_zip']."\"/> <input type=\"text\" name=\"in[home_city]\" value=\"".$contact['home_city']."\"/><br/>
    <input type=\"text\" name=\"in[home_state]\" value=\"".$contact['home_state']."\"/> / <input type=\"text\" name=\"in[home_country]\" value=\"".$contact['home_country']."\"/>
   </fieldset>
  </div>

  <div class=\"additional\">
   <em title=\"Company Name\">".$contact['company_name']."</em>
   <p title=\"Company Unit\">".$contact['company_unit']."</p>
   <hr/>
   <p title=\"E-Mail\">".$contact['work_email']."</p>
   <p title=\"Web Page\"><a class=\"launch\" href=\"#tasks_web\" rev=\"".$contact['work_webpage']."\">".$contact['home_webpage']."</a></p>
   <p title=\"Phone\">".$contact['work_phone']."</p>
   <p title=\"Fax\">".$contact['work_fax']."</p>
   <p title=\"Voice\">".$contact['work_voice']."</p>
   <address title=\"Address\">
    ".$contact['work_address']."<br/>
    ".$contact['work_zip']." ".$contact['work_city']."<br/>
    ".$contact['work_state']." / ".$contact['work_country']."
   </address>
  </div>
  <div class=\"additional\">
   <em>Instant Messaging</em>
   <p title=\"ICQ\">".$contact['im_icq']."</p>
   <p title=\"Jabber\">".$contact['im_jabber']."</p>

   <p title=\"Sidebar\">".$contact['im_sidebar']."</p>
   <p title=\"Contact is displayed as\">".$contact['im_displayas']."</p>
  </div>
 </div>
</div>";
 }
}else{
 switch($query[0]){
  default:
  case "inbox":
   $mail = new libMail($_COOKIE['email'],&$config);
   if($mail){
    $msgs = $mail->getBox("inbox");
    if(is_array($msgs)){
     $tbody="      <tbody>";
     foreach($msgs as $id=>$msg){
      $tbody.="
       <tr>
        <td>".$msg['priority']."</td>
        <td>".($mail->getName($msg['from']))."</td>
        <td>".$msg['subject']."</td>
        <td>".$msg['date']."</td>
       </tr>";
     }
     $tbody.="\n      </tbody>";
    }
   }
  break;
  case "sent":
   $mail = new libMail($_COOKIE['email'],&$config);
   if($mail){
    $msgs = $mail->getBox("sent");
    if(is_array($msgs)){
     $tbody="      <tbody>";
     foreach($msgs as $id=>$msg){
      $tbody.="
       <tr>
        <td>".$msg['priority']."</td>
        <td>".($mail->getName($msg['to']))."</td>
        <td>".$msg['subject']."</td>
        <td>".$msg['date']."</td>
       </tr>";
     }
     $tbody.="\n      </tbody>";
    }
   }
  break;
  case "trash":
  break;
 }

 if(!$tbody){
  $tbody="
 <tbody>
  <tr>
   <td class=\"center\" colspan=\"5\">This folder is empty. (concept)</td>
  </tr>
 </tbody>";
 }
 $cache="     <table class=\"data\">
      <thead>
       <tr>
        <th class=\"shrink\">Priority</th>
        <th class=\"shrink\">Person</th>
        <th>Subject</th>
        <th class=\"shrink\">Date</th>
       </tr>
      </thead>
".$tbody."
     </table>";
}

echo $cache;

if(basename($_SERVER['PHP_SELF'])!="main.php"){
 if(is_array($this->desklets) && $app['show']['desklets']==="true"){
  #print_r($app);
  $this->desklets[]='  <li title="Send and Receive Messages"><del>Send / Receive</del></li>';
  $this->desklets[]='  <li title="Compose a New Message"><a href="#tasks_mail" rev="apps/mail/main.php?compose">Compose</a></li>';
  $this->desklets[]="  <li class=\"first\"><a href=\"#tasks_mail\" rev=\"apps/mail/main.php?inbox\"><img src=\"apps/mail/inbox.png\" alt=\"\"/> Inbox (<em>".count($mail->getBox("inbox"))."</em>)</a></li>";
  $this->desklets[]="  <li><a href=\"#tasks_mail\" rev=\"apps/mail/main.php?sent\"><img src=\"apps/mail/sent.png\" alt=\"\"/> Sent (<em>".count($mail->getBox("sent"))."</em>)</a></li>";
  $first=true;
  foreach($mail->getContacts("sidebar") as $id=>$contact){
   if($first){ $cls=" class=\"first\""; }
   $this->desklets[]="  <li".$cls."><a href=\"#tasks_mail\" rev=\"apps/mail/main.php?contacts:view:".urlencode($contact['id'])."\"><em class=\"on\">&nbsp;</em> ".(!empty($contact['im_displayas'])?$contact['im_displayas']:$mail->getName($contact['id']))."</a></li>";
   unset($first,$cls);
  }
 }
}
?>