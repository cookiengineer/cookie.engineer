
describe('String.prototype.trimLeft', (assert, expect) => {

	let cmp1 = "This is a simple sentence";
	let cmp2 = "This is a simple sentence \t\n ";
	let str1 = " \n\t This is a simple sentence";
	let str2 = "This is a simple sentence \t\n ";

	assert(str1.trimLeft());
	assert(str2.trimLeft());

	assert(str1);
	assert(str2);

	expect(str1.trimLeft(), cmp1);
	expect(str2.trimLeft(), cmp2);

});

