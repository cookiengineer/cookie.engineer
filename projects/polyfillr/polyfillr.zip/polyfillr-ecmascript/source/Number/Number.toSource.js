
if (typeof Number.toSource !== 'function') {

	Number.toSource = function() {
		return 'function Number() {\n\t[native code]\n}';
	};

}

