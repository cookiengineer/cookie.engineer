
if (typeof RegExp.prototype.toSource !== 'function') {

	RegExp.prototype.toSource = function() {

		if (this.constructor === RegExp) {
			return this.toString();
		} else {
			return "function RegExp() {\n\t[native code]\n}";
		}

	};

}

