
if (typeof String.prototype.endsWith !== 'function') {

	String.prototype.endsWith = function(search/*, from */) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.endsWith called on null or undefined');
		}


		let value  = (this).toString();
		let from   = arguments.length >= 2 ? (arguments[1] | 0) : value.length;
		let tmp    = String(search);
		let length = tmp.length >>> 0;


		let chunk = value.substr(from - length);
		if (chunk === tmp) {
			return true;
		}


		return false;

	};

}

