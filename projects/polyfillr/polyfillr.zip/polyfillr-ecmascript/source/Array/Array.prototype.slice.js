
if (typeof Array.prototype.slice !== 'function') {

	Array.prototype.slice = function(/* start, end */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.slice called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let start  = arguments.length >= 1 ? arguments[0] : 0;
		let end    = arguments.length >= 2 ? arguments[1] : length;
		let result = [];


		if (end < 0) {
			end = length - Math.abs(end);
		}


		for (let i = start; i < end; i++) {

			if (i in list) {
				result.push(list[i]);
			}

		}


		return result;

	};

}

