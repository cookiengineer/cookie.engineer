
describe('Object.prototype.toSource', (assert, expect) => {

	let cmp1 = '({foo:"bar", qux:123.45})';
	let cmp2 = '({foo:"bar", qux:{doo:123.45}})';
	let obj1 = {foo:'bar',qux:123.45};
	let obj2 = {foo:'bar',qux:{doo:123.45}};

	assert(obj1.toSource());
	assert(obj2.toSource());

	expect(obj1.toSource(), cmp1);
	expect(obj2.toSource(), cmp2);

	assert(obj1);
	assert(obj2);

});

