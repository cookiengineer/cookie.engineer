
if (typeof Object.is !== 'function') {

	Object.is = function(a, b) {

		if (a === 0 && b === 0) {

			return (1 / a) === (1 / b);

		} else if (a === b) {

			return true;

		} else if (Number.isNaN(a) && Number.isNaN(b)) {

			return true;

		}


		return false;

	};

}

