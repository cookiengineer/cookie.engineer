<?php
class libTPL extends libOS{
 var $out=array();

 public function __construct($file,&$jQueryOS=false){
  if(is_file($file)){
   $xml = simplexml_load_file($file);
   $this->config=$this->xmlToArray($xml);
  }
  if(is_array(get_object_vars($jQueryOS))){
   foreach(get_object_vars($jQueryOS) as $key=>$arr){
    $this->$key=$arr;
   }
  }
  return true;
 }

 public function getCSS($link){
  if(is_dir($link)){
   $dh=opendir($link);
   while(($file=readdir($dh))!==false){
    if(is_file($link."/".$file) && preg_match("~\.css~Uis",$file)){
     $array[]=$link."/".$file;
    }
   }
   closedir($dh);
   natsort($array);
  }elseif(is_file($link)){
   $array[]=$link;
  }
  if(is_array($array)){
   foreach($array as $key=>$val){
    $this->css[count($this->css)+1]=$val;
   }
  }
 }

 public function getJS($link){
  if(is_dir($link)){
   $dh=opendir($link);
   while(($file=readdir($dh))!==false){
    if(is_file($link."/".$file) && preg_match("~\.js~Uis",$file)){
     $array[]=$link."/".$file;
    }
   }
   closedir($dh);
   natsort($array);
  }elseif(is_file($link)){
   $array[]=$link;
  }
  if(is_array($array)){
   foreach($array as $key=>$val){
    $this->js[count($this->js)+1]=$val;
   }
  }
 }


 public function buildHead(){
  $css = $this->css;
  $js  = $this->js;
  $tpl['js']  = " <script type=\"text/javascript\" src=\"{file}\"></script>\n"; 
  $tpl['css'] = " <link rel=\"stylesheet\" type=\"text/css\" href=\"{file}\"/>\n";

  if(is_array($css)){
   foreach($css as $id=>$file){
    if(is_file($file)){
     $this->out['head'].= preg_replace("~{file}~Uis",$file,$tpl['css']);
    }
   }
  }
 
  if(is_array($js)){
   foreach($js as $id=>$file){
    if(is_file($file)){
     $this->out['head'].= preg_replace("~{file}~Uis",$file,$tpl['js']);
    }
   }
  }
 }

 public function buildIcons($c){
  $arr=$this->icons;
  if(is_array($arr)){
   $x=0; $y=0;
   foreach($arr as $id=>$icon){
    $icon = preg_replace("~{position}~Uis","left:".($x*80)."px;top:".($y*70+10)."px",$icon);
    $this->out['icons'].= $icon."\n";
    $y++;
    if($y==$c){
     $x++; $y=0;
    }
   }
  }
 }

 public function buildWindows(){
  if(is_array($this->windows)){
   $arr = $this->windows;
   foreach($arr as $id=>$window){
    $this->out['windows'].= $window."\n\n";
   }
  }
 }

 public function buildTasks(){
  if(is_array($this->tasks)){
   $arr = $this->tasks;
   foreach($arr as $id=>$task){
    $this->out['tasks'].= $task."\n";
   }
  }
 }

 public function buildQuickies(){
  if(is_array($this->quickies)){
   $arr = $this->quickies;
   foreach($arr as $id=>$quickie){
    $this->out['quickies'].= $quickie."\n";
   }
  }
 }

 public function buildDesklets(){
  if(is_array($this->desklets)){
   $arr = $this->desklets;
   foreach($arr as $id=>$desklet){
    $this->out['desklets'].= $desklet."\n";
   }
  }
 }

}
?>