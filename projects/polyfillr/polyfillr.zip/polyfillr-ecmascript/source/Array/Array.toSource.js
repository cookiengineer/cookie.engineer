
if (typeof Array.toSource !== 'function') {

	Array.toSource = function() {
		return 'function Array() {\n\t[native code]\n}';
	};

}

