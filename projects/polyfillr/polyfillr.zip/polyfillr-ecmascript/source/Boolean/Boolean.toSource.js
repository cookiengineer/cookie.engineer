
if (typeof Boolean.toSource !== 'function') {

	Boolean.toSource = function() {
		return 'function Boolean() {\n\t[native code]\n}';
	};

}

