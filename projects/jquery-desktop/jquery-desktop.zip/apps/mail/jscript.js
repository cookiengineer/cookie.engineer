$('#mail_contacts .details').find('p,address,em').live('click',function(){
 if(!$(this).find('a').length && $(this).attr('title').length){
  var x = ($(this).html()!="&nbsp;")?$(this).html():"";
  x = x.replace(/\s+/g,'').replace(/(&nbsp;)/g,' ').replace(/<br>+/g,'|');
  //x = x.replace(/\s+/g,'');
  var y = prompt($(this).attr('title'),x);
  if(!y.length){ y='&nbsp;'; }
  if(y){
   y = y.replace(/\|/g,'<br/>').replace(/\s+/g,'&nbsp;');
   $(this).html(y);
  }
 }
});