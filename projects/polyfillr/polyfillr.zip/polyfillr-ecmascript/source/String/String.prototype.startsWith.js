
if (typeof String.prototype.startsWith !== 'function') {

	String.prototype.startsWith = function(search/*, from */) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.startsWith called on null or undefined');
		}


		let value  = (this).toString();
		let from   = arguments.length >= 2 ? (arguments[1] | 0) : 0;
		let tmp    = String(search);
		let length = tmp.length >>> 0;


		let chunk = value.substr(from, length);
		if (chunk === tmp) {
			return true;
		}


		return false;

	};

}

