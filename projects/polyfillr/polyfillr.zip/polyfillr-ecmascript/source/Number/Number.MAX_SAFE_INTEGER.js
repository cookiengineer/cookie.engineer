
if (typeof Number.MAX_SAFE_INTEGER !== 'number') {

	Number.MAX_SAFE_INTEGER = 9007199254740991;

}

