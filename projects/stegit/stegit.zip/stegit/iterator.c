
#include <sys/types.h>

#include "config.h"
#include "stegit.h"
#include "arc.h"
#include "iterator.h"

void iterator_init(iterator *iter, bitmap *bitmap, u_char *key, u_int klen) {
	iter->skipmod = INIT_SKIPMOD;
	arc4_initkey(&iter->as, "Seeding", key, klen);
	iter->off = arc4_getword(&iter->as) % iter->skipmod;
}

int iterator_next(iterator *iter, bitmap *bitmap) {
	iter->off += (arc4_getword(&iter->as) % iter->skipmod) + 1;
	return iter->off;
}

void iterator_seed(iterator *iter, bitmap *bitmap, u_int16_t seed) {

	u_int8_t reseed[2];

	reseed[0] = seed;
	reseed[1] = seed >> 8;

	arc4_addrandom(&iter->as, reseed, 2);

}

void iterator_adapt(iterator *iter, bitmap *bitmap, int datalen) {
	iter->skipmod = SKIPADJ(bitmap->bits, bitmap->bits - iter->off) * (bitmap->bits - iter->off)/(8 * datalen);
}
