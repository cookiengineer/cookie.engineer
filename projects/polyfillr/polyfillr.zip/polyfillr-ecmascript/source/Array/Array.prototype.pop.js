
if (typeof Array.prototype.pop !== 'function') {

	Array.prototype.pop = function() {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.pop called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let value  = undefined;

		let i = length - 1;
		if (i in list) {

			value = list[i];
			delete list[i];

			this.length = i;

		}


		return value;

	};

}

