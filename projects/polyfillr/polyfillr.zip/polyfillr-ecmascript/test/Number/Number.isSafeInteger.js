
describe('Number.isSafeInteger', (assert, expect) => {

	assert(Number.isSafeInteger(NaN));
	assert(Number.isSafeInteger(-0));
	assert(Number.isSafeInteger(+0));
	assert(Number.isSafeInteger(1337));
	assert(Number.isSafeInteger(1337.89));
	assert(Number.isSafeInteger(Infinity));
	assert(Number.isSafeInteger(-Infinity));
	assert(Number.isSafeInteger("0"));
	assert(Number.isSafeInteger(Number.MAX_SAFE_INTEGER));

	expect(Number.isSafeInteger(NaN),       false);
	expect(Number.isSafeInteger(-0),        true);
	expect(Number.isSafeInteger(+0),        true);
	expect(Number.isSafeInteger(1337),      true);
	expect(Number.isSafeInteger(1337.89),   false);
	expect(Number.isSafeInteger(Infinity),  false);
	expect(Number.isSafeInteger(-Infinity), false);
	expect(Number.isSafeInteger("0"),       false);
	expect(Number.isSafeInteger(Number.MAX_SAFE_INTEGER), true);

});

