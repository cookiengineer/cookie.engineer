
if (typeof Boolean.prototype.toSource !== 'function') {

	Boolean.prototype.toSource = function() {
		return '(new Boolean(' + (this).valueOf() + '))';
	};

}

