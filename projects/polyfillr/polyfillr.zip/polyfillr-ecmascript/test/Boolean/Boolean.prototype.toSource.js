
describe('Boolean.prototype.toSource', (assert, expect) => {

	let cmp1 = '(new Boolean(true))';
	let cmp2 = '(new Boolean(false))';
	let boo1 = true;
	let boo2 = false;

	assert(boo1.toSource());
	assert(boo2.toSource());

	assert(boo1);
	assert(boo2);

	expect(boo1.toSource(), cmp1);
	expect(boo2.toSource(), cmp2);

});

