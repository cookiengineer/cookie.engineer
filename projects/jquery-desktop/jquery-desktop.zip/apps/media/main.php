<?php

if(basename($_SERVER['PHP_SELF'])!="main.php"){
 return;
}else{
 require_once("../../system/lib/libfunctions.php");
}

$img = $_SERVER['QUERY_STRING'];
$path = "../../".eregi_replace("/".basename($img),"",$img);
$href = eregi_replace("/".basename($img),"",$img);
$supported = "~\.(gif|jpeg|jpg|bmp|png)~Uis";

if(is_dir($path)){
 $dh=opendir($path);
 while(($file=readdir($dh))!==false){
  if(preg_match($supported,$file)){
   $ul[]=$file;
  }
 }
}
natsort($ul);

echo "
<div class=\"abs data\">
".$path."
 <img src=\"".$img."\" alt=\"".basename($img)."\"/>
 <ul class=\"abs\">";

foreach($ul as $id=>$file){
 $d = getimagesize($path."/".$file);
 $d['size'] = readable_size(filesize($path."/".$file));
 echo "
  <li title=\"".$file."\">
   <a class=\"launch";
 if($img==$href."/".$file){
  echo " shiny";
 }
 echo "\" href=\"#tasks_media\" rev=\"apps/media/main.php?".$href."/".$file."\">".shorten($file,10)."
    <div>
     ".$d[0]." x ".$d[1]." Pixels<br/>
     ".$d['size']." (".$d['mime'].")
    </div>
   </a>
  </li>";
}

echo "

  <!-- <li><a class=\"launch\" href=\"#tasks_media\" rev=\"apps/media/main.php?test.jpg\">test.jpg</a></li>
  <li><a class=\"launch\" href=\"#tasks_media\" rev=\"apps/media/main.php?test.jpg\">test.jpg</a></li> -->
 </ul>
</div>";
?>