
if (typeof RegExp.toSource !== 'function') {

	RegExp.toSource = function() {
		return 'function RegExp() {\n\t[native code]\n}';
	};

}

