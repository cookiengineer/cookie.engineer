
describe('Boolean.prototype.toJSON', (assert, expect) => {

	let cmp1 = true;
	let cmp2 = false;
	let boo1 = true;
	let boo2 = false;

	assert(boo1.toJSON());
	assert(boo2.toJSON());

	assert(boo1);
	assert(boo2);

	expect(boo1.toJSON(), cmp1);
	expect(boo2.toJSON(), cmp2);

});

