
console.time('test');

console.log('Hello world');
console.clear(); // Removes first Hello world

console.log('Hello world (after clear)');
console.info('Please enjoy responsibly');

console.assert(true,  'A truey assertion');
console.assert(false, 'A falsy assertion');


console.log({
	foo: 'bar',
	bar: 13.37
});

console.log(function(a,b,c,d) {

	if (whatever) {
		this.shall('be', 'indented');
	}

	return 'something' + true;

});

console.log([0,1,'foo','bar', true]);

console.warn('All your logs are belong to us');

console.error('Warp core breach eminent.');
console.error(new Error('Resistance is futile.'));

console.timeEnd('test');


myother = new Polyfillr.Console('other context');
myother.info('Things are only impossible until they\'re not');

myother.table({
	first: { foo: 1, bar: 2 },
	last:  { foo: 2, bar: 3 }
});

myother.table([
	{ foo: 1, bar: 2, qux: 'this'    },
	{ foo: 2, bar: 3, qux: 'is'      },
	{ foo: 3, bar: 4, qux: 'an'      },
	{ foo: 4, bar: 5, qux: 'example' }
], [ 'foo', 'qux', 'bar' ]);

myotherother = new Polyfillr.Console('empty other');

