
if (typeof JSON.query !== 'function') {

	JSON.query = function(object, query) {

		query = typeof query === 'string' ? query : '';


		let pointer = null;

		if (object instanceof Object) {

			let references = query.split('>');
			let check      = references[0] || '';

			if (check !== '' && references.length > 0) {

				pointer = object;

				for (let r = 0, rl = references.length; r < rl; r++) {

					let ref = references[r].trim();
					if (ref !== '') {

						if (pointer[ref] !== undefined) {

							pointer = pointer[ref];

						} else {

							let num = parseInt(ref, 10);
							if (!isNaN(num) && pointer[num] !== undefined) {

								pointer = pointer[num];

							} else {

								pointer = null;
								break;

							}

						}

					} else {

						pointer = null;
						break;

					}

				}


			} else {

				pointer = object;

			}

		}

		return pointer;

	};

}

