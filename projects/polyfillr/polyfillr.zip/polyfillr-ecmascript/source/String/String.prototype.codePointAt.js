
if (typeof String.prototype.codePointAt !== 'function') {

	String.prototype.codePointAt = function(index) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.codePointAt called on null or undefined');
		}


		let string = String(this);
		let length = string.length >>> 0;
		let i      = typeof index === 'number' ? (index | 0) : 0;

		if (i < 0 || i >= length) {
			return undefined;
		}


		let char_01 = string.charCodeAt(i);
		let char_02;

		if (char_01 >= 0xD800 && char_01 <= 0xDBFF && length > i + 1) {

			char_02 = string.charCodeAt(i + 1);

			if (char_02 >= 0xDC00 && char_02 <= 0xDFFF) {
				return (char_01 - 0xD800) * 0x400 + (char_02 - 0xDC00) + 0x10000;
			}

		}


		return char_01;

	};

}

