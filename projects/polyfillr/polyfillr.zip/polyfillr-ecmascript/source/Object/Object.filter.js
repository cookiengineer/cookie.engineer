
if (typeof Object.filter !== 'function') {

	Object.filter = function(object, predicate/*, thisArg */) {

		if (object !== Object(object)) {
			throw new TypeError('Object.filter called on a non-object');
		}

		if (typeof predicate !== 'function') {
			throw new TypeError('predicate must be a function');
		}


		let props   = [];
		let values  = [];
		let thisArg = arguments.length >= 3 ? arguments[2] : void 0;

		for (let prop in object) {

			let value = object[prop];

			if (Object.prototype.hasOwnProperty.call(object, prop)) {

				if (predicate.call(thisArg, value, prop, object)) {
					props.push(prop);
					values.push(value);
				}

			}

		}


		let filtered = {};

		for (let i = 0; i < props.length; i++) {
			filtered[props[i]] = values[i];
		}

		return filtered;

	};

}

