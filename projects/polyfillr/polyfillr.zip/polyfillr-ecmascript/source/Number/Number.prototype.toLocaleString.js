
if (typeof Number.prototype.toLocaleString !== 'function') {

	Number.prototype.toLocaleString = function() {

		let lang = 'en-US';
		let tmp1 = (this | 0).toString();
		let tmp2 = (this - (this | 0)).toString().substr(2);

		if (typeof navigator === 'object') {

			if (typeof navigator.language === 'string') {
				lang = navigator.language;
			}

		}


		let sep_1 = ',';
		let sep_2 = '.';

		if (/^de|it|es/.test(lang)) {
			sep_1 = '.';
			sep_2 = ',';
		} else if (/^fr/.test(lang)) {
			sep_1 = ' ';
			sep_2 = ',';
		}

		for (let t = 0; t < tmp1.length; t++) {

			if (t % 3 === 0 && tmp1[tmp1.length - t] !== sep_1) {
				tmp1 = tmp1.substr(0, tmp1.length - t) + sep_1 + tmp1.substr(tmp1.length - t + 1);
			}

		}


		return tmp1 + sep_2 + tmp2;

	};

}

