
if (typeof Number.isNaN !== 'function') {

	Number.isNaN = function(value) {

		if (typeof value === 'number') {
			return value !== value;
		}


		return false;

	};

}

