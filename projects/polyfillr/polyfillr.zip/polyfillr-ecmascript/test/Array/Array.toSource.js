
describe('Array.toSource', (assert, expect) => {

	let cmp = 'function Array() {\n\t[native code]\n}';

	assert(Array.toSource());
	assert(Array.toSource() === cmp);

});

