
if (typeof Array.prototype.toString !== 'function') {

	Array.prototype.toString = function() {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.toString called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let value  = '';
		let tmp;


		for (let i = 0; i < length; i++) {

			if (i in list) {

				tmp = list[i];

				if (tmp !== undefined && tmp !== null) {
					value += tmp.toString();
				}

			}

			if (i !== length - 1) {
				value += ',';
			}

		}


		return value;

	};

}

