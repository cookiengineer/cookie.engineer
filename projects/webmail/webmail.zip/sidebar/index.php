<?php
@error_reporting(0);
$flush=microtime();
$query=explode(":",$_SERVER['QUERY_STRING']);

require_once('../obj/ec_profiles.inc');
require_once('../obj/uw_functions.inc');
require_once('../obj/uw_config.inc');
require_once('../obj/uw_imap.inc');
require_once('../obj/uw_smtp.inc');
require_once('../obj/uw_message_show.inc');

$cfg['tpl']['url']            = ".";
$cfg['tpl']['css']['name']    = "Sidebar";
$cfg['tpl']['css']['url']     = "../tpl/stylish"; # light_blue || stylish
$cfg['tpl']['cnt']['toolbar'] = ""; # prevent viewing a toolbar if nothing works.
$cfg['tpl']['cnt']['css']    .= "@import url('".$cfg['tpl']['css']['url']."/style.css');";
$cfg['tpl']['cnt']['css']     = "@import url('./sidebar.css');";

# - needs $cfg['tpl']['css']['url']."/mime"! - #
#require_once('../obj/uw_mime.inc');
#print_r($cfg['mime']);

if(!empty($_COOKIE['username']) || $query[0]=="check"){
 if(is_array($cfg['usermap'])){
  foreach($cfg['usermap'] as $acc => $user){
   if($_COOKIE['username']==$acc || $_COOKIE['username']==$user){
    $login=$acc;
   }
  }
 }
 if(!$login){
  $login=$_COOKIE['username'];
 }
 if($login){
  $obj['imap']=@new uw_imap($login,$_COOKIE['password'],$cfg);
 }
 unset($login);
}
# - - - used variables - - - #
 $input = $_POST['input'];
# / #

switch($query[0]){
 default:
 case "check":
 case "login":
 case "logout":
  $cfg['tpl']['var']['title'] = "Sidebar";
  $cfg['tpl']['file']        = "sidebar.xhtml";
  include "./sidebar.php";
 break;
}

if($query[0]!="message_iframe" && !preg_match("~iframe~Uis",$query[2])){
 if(preg_match("~ssl|tls~Uis",$cfg['imap_flags']) && !preg_match("~notls~Uis",$cfg['imap_flags'])){
  $cfg['tpl']['cnt']['toolbar'] = "<div class=\"beta\">SSL/TLS encrypted.</div>". $cfg['tpl']['cnt']['toolbar'];  
 }
 $flush = round((microtime()-$flush),4);
 $flush = ($flush<0)?($flush * -1):$flush;
 $cfg['tpl']['cnt']['trace']  .= "\n<div class=\"error\">";
 $cfg['tpl']['cnt']['trace']  .= "Created in ".$flush."sec";
 if($_COOKIE['login']){
  $cfg['tpl']['cnt']['trace']  .= "<br />Login expires in ".(time() - $_COOKIE['login'])* -1 ."sec";
 }
 $cfg['tpl']['cnt']['trace']  .= "</div>";
}else{
 $cfg['tpl']['cnt']['trace'] = "";
}
#print_r($cfg['tpl']['cnt']);

$tpl=implode('',file($cfg['tpl']['url']."/".$cfg['tpl']['file']));
$tpl=preg_replace("~{VAR:CSS_TITLE}~Uis", $cfg['tpl']['css']['name'], $tpl);

if(is_array($cfg['tpl']['cnt'])){
 foreach($cfg['tpl']['cnt'] as $name=>$value){ $tpl=preg_replace("~{CNT:".$name."}~Uis", $value, $tpl); }
}
foreach($cfg['tpl']['var'] as $name=>$value){ $tpl=preg_replace("~{VAR:".$name."}~Uis", $value, $tpl); }
$tpl=preg_replace("~{CFG:username}~Uis", isset($_COOKIE['username'])?$_COOKIE['username']:"", $tpl);
foreach($cfg as $name=>$value){
 if(!is_array($value)){ $tpl=preg_replace("~{CFG:$name}~Uis", $value, $tpl); }
}
$tpl=preg_replace("~{VAR:ERROR}~Uis", (isset($_COOKIE['error'])?$_COOKIE['error']:"No errors occured."), $tpl);

echo $tpl;
?>