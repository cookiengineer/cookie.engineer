
if (typeof Boolean.prototype.toJSON !== 'function') {

	Boolean.prototype.toJSON = function() {
		return this.valueOf();
	};

}

