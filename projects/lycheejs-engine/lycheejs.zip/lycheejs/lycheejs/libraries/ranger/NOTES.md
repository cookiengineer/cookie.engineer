
# Developer Notes

Personal notes from `@cookiengineer` for unautomated
tasks that might get forgotten in future.



## Font Generation

The `ui/entity/Console.fnt` is generated with:

- `family` set to `DejaVu Sans Mono`
- `size` set to `20 (px)`
- `style` set to `normal`
- `spacing` set to `4 (px)`

