
if (typeof Array.prototype.reduceRight !== 'function') {

	Array.prototype.reduceRight = function(predicate/*, initialValue */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.reduceRight called on null or undefined');
		}

		if (typeof predicate !== 'function') {
			throw new TypeError('predicate must be a function');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let start  = length - 1;
		let value  = undefined;


		if (arguments.length >= 2) {

			value = arguments[1];

		} else {

			while (start >= 0 && !(start in list)) {
				start--;
			}

			if (start < 0) {
				throw new TypeError('Reduce of empty array with no initial value');
			}

			value = list[start--];

		}


		for (let i = start; i >= 0; i--) {

			if (i in list) {
				value = predicate(value, list[i], i, list);
			}

		}


		return value;

	};

}

