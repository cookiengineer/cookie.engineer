
if (typeof Polyfillr === 'undefined') {
	Polyfillr = {};
}

(function(global) {

	const _document    = global.document;
	const _location    = global.location || null;
	let   _ES6_SUPPORT = false;



	/*
	 * FEATURE DETECTION
	 */

	(function(implementation) {

		if (implementation === null) {
			implementation = _document.implementation = {};
		}

		if (typeof implementation.createHTMLDocument !== 'function') {

			implementation.createHTMLDocument = function() {

				if (typeof ActiveXObject !== 'undefined') {
					return new ActiveXObject('htmlfile');
				}

				return _document;

			};

		}

	})(_document.implementation || null);

	(function() {

		try {

			eval('let foo = \'foo\'');
			eval('let bar = _ => false');

			_ES6_SUPPORT = true;

		} catch (err) {
			_ES6_SUPPORT = false;
		}

	})();



	/*
	 * HELPERS
	 */

	const _import_html = function(url, html) {

		let data = {};
		let doc  = _document.implementation.createHTMLDocument(url);
		let meta = doc.createElement('meta');

		meta.setAttribute('charset', 'utf-8');
		doc.baseURI = url;
		doc.head.appendChild(meta);

		if (typeof doc.open === 'function') {
			doc.open();
		}

		if (doc.body !== null) {
			doc.body.innerHTML = html;
		} else {
			doc.write('<body>' + html + '</body>');
		}


		let scripts = [].slice.call(doc.querySelectorAll('script'));
		if (scripts.length > 0) {

			scripts.filter(function(script) {

				let type = script.getAttribute('type');
				if (type === null || type === 'text/javascript') {
					return true;
				}

				return false;

			}).forEach(function(script) {

				let code  = script.innerHTML;
				let scope = {
					Polyfillr: Object.assign({}, Polyfillr),
					document:  {
						querySelector: function(selectors) {
							return _document.querySelector(selectors);
						},
						querySelectorAll: function(selectors) {
							return _document.querySelectorAll(selectors);
						},
						currentScript: {
							ownerDocument: doc
						}
					}
				};

				scope.Polyfillr.define = function(identifier, template) {
					let value = Polyfillr.define(identifier, template);
					data[identifier] = value;
					return value;
				};


				if (_ES6_SUPPORT === false) {
					code = code.split('let ').join('var ');
					code = code.split('const ').join('var ');
				}


				try {

					with (scope) {
						eval(code);
					}

				} catch (err) {
					console.error(err);
				}

			});

		}


		return data;

	};

	const _polyfill_base_uri = function() {

		if (typeof _document.baseURI === 'undefined') {

			Object.defineProperty(_document, 'baseURI', {
				get: function() {

					let base = this.querySelector('base');
					if (base !== null) {
						return base.href;
					} else if (location !== null) {
						return location.href;
					}


					return null;

				},
				set: function(value) {

					let base = this.querySelector('base');
					if (base === null) {

						base = this.createElement('base');
						this.head.appendChild(base);

						if (location !== null) {
							base.setAttribute('href', location.href);
						}

					}


					base.setAttribute('href', value);

				},
				configurable: true
			});

			Polyfillr.BASE_URI = false;

		} else {

			Polyfillr.BASE_URI = true;

		}

	};

	const _polyfill_html_import = function() {

		let links = [].slice.call(_document.head.querySelectorAll('link[rel="import"]'));
		if (links.length > 0) {

			links.forEach(function(link) {

				let url = link.getAttribute('href');
				if (url !== null) {

					let request = new XMLHttpRequest();

					request.responseType = 'text';
					request.open('GET', url);

					request.onload = function() {

						if (request.status === 200 || request.status === 304) {

							let response = request.response || request.responseText;
							if (response.length > 0) {
								Polyfillr.import(url, response);
							}

						}

					};

					request.onerror = function() {
						// XXX: Do nothing
					};

					request.ontimeout = function() {
						// XXX: Do nothing
					};

					request.send(null);

				}

			});

		}

	};



	/*
	 * IMPLEMENTATION
	 */

	Polyfillr.HTML_IMPORT = false;
	Polyfillr.BASE_URI    = false;

	Polyfillr.import = function(url, html) {

		url  = typeof url === 'string'  ? url  : null;
		html = typeof html === 'string' ? html : null;


		if (url !== null && html !== null) {
			return _import_html(url, html);
		}


		return null;

	};



	/*
	 * DOM EVENTS
	 */

	_document.addEventListener('DOMContentLoaded', function(event) {

		setTimeout(function() {

			if (Polyfillr.BASE_URI === false) {
				_polyfill_base_uri();
			}

			if (Polyfillr.HTML_IMPORT === false) {
				_polyfill_html_import();
			}

		}, 300);

	}, true);

})(typeof window !== 'undefined' ? window : this);

