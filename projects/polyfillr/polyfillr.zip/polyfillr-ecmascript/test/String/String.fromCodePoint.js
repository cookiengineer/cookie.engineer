
describe('String.fromCodePoint', (assert, expect) => {

	let cmp1 = "*";
	let cmp2 = "AZ";
	let cmp3 = "\u0404";
	let cmp4 = "\uD87E\uDC04";
	let cmp5 = "\uD834\uDF06a\uD834\uDF07";

	assert(String.fromCodePoint(42));
	assert(String.fromCodePoint(65, 90));
	assert(String.fromCodePoint(0x404));
	assert(String.fromCodePoint(0x2F804));
	assert(String.fromCodePoint(0x1D306, 0x61, 0x1D307));

	expect(String.fromCodePoint(42),                     cmp1);
	expect(String.fromCodePoint(65, 90),                 cmp2);
	expect(String.fromCodePoint(0x404),                  cmp3);
	expect(String.fromCodePoint(0x2F804),                cmp4);
	expect(String.fromCodePoint(0x1D306, 0x61, 0x1D307), cmp5);

});

