
describe('String.prototype.startsWith', (assert, expect) => {

	let str1 = "This is a simple sentence";
	let str2 = "This is a simple sentence";

	assert(str1.startsWith('This'));
	assert(str1.startsWith('simple'));
	assert(str2.startsWith('simple', 10));
	assert(str2.startsWith('simple', 17));

	assert(str1);
	assert(str2);

	expect(str1.startsWith('This'),       true);
	expect(str1.startsWith('simple'),     false);
	expect(str2.startsWith('simple', 10), true);
	expect(str2.startsWith('simple', 17), false);

});

