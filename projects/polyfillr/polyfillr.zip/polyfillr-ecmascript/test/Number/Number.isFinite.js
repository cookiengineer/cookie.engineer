
describe('Number.isFinite', (assert, expect) => {

	assert(Number.isFinite(NaN));
	assert(Number.isFinite(-0));
	assert(Number.isFinite(+0));
	assert(Number.isFinite(Infinity));
	assert(Number.isFinite(-Infinity));
	assert(Number.isFinite("0"));

	expect(Number.isFinite(NaN),       false);
	expect(Number.isFinite(-0),        true);
	expect(Number.isFinite(+0),        true);
	expect(Number.isFinite(Infinity),  false);
	expect(Number.isFinite(-Infinity), false);
	expect(Number.isFinite("0"),       false);

});

