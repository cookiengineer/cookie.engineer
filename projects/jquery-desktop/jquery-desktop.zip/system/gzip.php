<?php
/*
RewriteEngine On
RewriteRule ^(kernel/css/.*)$ gzip.php?$1
RewriteRule ^(kernel/js/.*)$ gzip.php?$1
RewriteRule ^(gui/css/.*)$ gzip.php?$1
RewriteRule ^(gui/js/.*)$ gzip.php?$1
*/

if(
 strpos($_SERVER['HTTP_ACCEPT_ENCODING'],"gzip")!==false
 &&
 $_COOKIE['gzip']!=="false"
){
 $enc=true;
}

$file=eregi_replace("/system/","",$_SERVER['REQUEST_URI']);
if(is_file($file)){
 $cache=implode('',file($file));

 if(eregi(".css",$file)){
  header("Content-Type: text/css");
 }elseif(eregi(".js",$file)){
  header("Content-Type: text/javascript");
 }
 if($enc){
  header("Content-Encoding: gzip");
  echo gzencode($cache);
 }else{
  echo $cache;
 }
}else{
 header("HTTP/1.0 404 Not Found");
}

?>