
if (typeof Number.isInteger !== 'function') {

	Number.isInteger = function(value) {

		if (typeof value === 'number') {

			if (value === -Infinity || value === +Infinity) {
				return false;
			} else if (Math.floor(value) === value) {
				return true;
			}

		}


		return false;

	};

}

