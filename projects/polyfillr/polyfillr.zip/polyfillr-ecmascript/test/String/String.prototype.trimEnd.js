
describe('String.prototype.trimEnd', (assert, expect) => {

	let cmp1 = " \n\t This is a simple sentence";
	let cmp2 = "This is a simple sentence";
	let str1 = " \n\t This is a simple sentence";
	let str2 = "This is a simple sentence \t\n ";

	assert(str1.trimEnd());
	assert(str2.trimEnd());

	assert(str1);
	assert(str2);

	expect(str1.trimEnd(), cmp1);
	expect(str2.trimEnd(), cmp2);

});

