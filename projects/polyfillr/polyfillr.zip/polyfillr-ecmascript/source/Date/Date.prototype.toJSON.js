
if (typeof Date.prototype.toJSON !== 'function') {

	let _format_date = function(n) {
		return n < 10 ? '0' + n : '' + n;
	};

	Date.prototype.toJSON = function() {

		if (isFinite(this.valueOf()) === true) {

			return this.getUTCFullYear()             + '-' +
				_format_date(this.getUTCMonth() + 1) + '-' +
				_format_date(this.getUTCDate())      + 'T' +
				_format_date(this.getUTCHours())     + ':' +
				_format_date(this.getUTCMinutes())   + ':' +
				_format_date(this.getUTCSeconds())   + 'Z';

		}


		return null;

	};

}

