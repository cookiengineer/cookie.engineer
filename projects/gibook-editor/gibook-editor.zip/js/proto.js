
// global functions
function array_key_exists(x,y){
	if (!y || (y.constructor !== Array && y.constructor !== Object)){
		return false;
	}
	return x in y;
}

function is_array(x){
	return typeof(x) == "object";
	// return typeof(x) == "object" && (x instanceof Array);
}

function trim(x){
	return x.replace(/^\s+/, '').replace(/\s+$/, '');
}

var _=function(x){
	var y=globals.language;
	if(typeof globals.translations[x][y]!=='undefined'){
		return globals.translations[x][y];
	}else{
		return x;
	}
};


/* - - - - - - - - - - - - - - - - - - - - - */

var session={
	open:function(key){
		var val=localStorage.getItem(key);
		$('#wysiwyg').html(val);
		editor.notify(_('restored')+': '+key+' ('+val.length+' Bytes)');
	},
	get:function(key){
		return localStorage.getItem(key);
	},
	save:function(key,val){
		localStorage.setItem(key,val);
		var x=$.strftime('%d.%m.%Y %H:%M Uhr');
		var y=key+' <button class="load">'+_('open')+'</button> <button class="del">'+_('delete')+'</button>';

		if(!$('#jq-file').find("li[data-name='"+key+"']").length){
			$('#jq-file-local .lorem').remove();
			$('#jq-file-local').append('<li data-name="'+key+'" title="'+x+'">'+y+'</li>');
		}else{
			$('#jq-file-local').find("li[data-name='"+key+"']").html(y);
		}
		localStorage.setItem('jq-file-local',$('#jq-file-local').html());
		editor.notify(_('saved')+': '+key+' ('+val.length+' Bytes)');
		return true;
	},
	unset:function(key){
		localStorage.removeItem(key);
		$('#jq-file-local').find("li[data-name='"+key+"']").remove();
		if(!$('#jq-file-local li').length){
			$('#jq-file-local').prepend('<li class="lorem">'+_('no saved files')+'</li>');
		}
		localStorage.setItem('jq-file-local',$('#jq-file #jq-file-local').html());
		editor.notify(_('deleted')+': '+key);
		return true;
	}
};

var gi={
	xml:{
		header:'<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n',
		prefix:'<gi:gi\n xmlns:gi="http://rote-liste.de/gibook/1/"\n xmlns:i="http://rote-liste.de/inline/1/"\n xmlns:l="http://rote-liste.de/layout/1/">\n',
		suffix:'</gi:gi>'
	},
	namespaces:{
		'gi':true,
		'l':true,
		'i':true,

		// deactivate demo
		'demo':false
	},
	schema:{
		// namespace demo
		'demo':{
			'element':{
				'attribute1':'longint',
				'attribute2':{
					'value1':true,
					'value2':true
				}
			}
		},

		// namespace gi (structure)
		'gi':{
			// metadata
			'meta-daten':{
				'produkttyp':{
					'arzneimittel':true,
					'medizinprodukt':true
				},
				'status':{
					'betaeubungsmittel':true,
					'verschreibungspflichtig':true,
					'apothekenpflichtig':true,
					'nicht-apothekenpflichtig':true,
					'eingeschraenkt-apothekenpflichtig':true,
					'nicht-apothekenpflichtig-und-rezeptpflichtig':true,
					'eingeschraenkt-rezeptpflichtig':true,
					'eingeschraenkt-betaeubungsmittelpflichtig':true
				},
			},
			'pu-namen':true,
			'zulassungsinhaber':true,
			'mitvertrieb':true,
			'praeparat':{
				'name':'text'
			},
			'darreichungsformen':true,
			'darreichungsform':{
				'name':'text'
			},
			'zulassungsnummer':true,
			'wirkstoffe':true,
			'wirkstoff':{
				'name':'text'
			},
			'packungen':true,
			'packung':{
				'name':'text',
				'pzn':'longint'
			},
			'menge':true,
			'einheit':true,
			'gi-stand':{
				'sortid':'int'
			},
			'gueltigkeit':true,
			'von':true,
			'bis':true,

			// head data
			'kopf':true,
			'anwenderhinweis':true,
			'inhaltsangabe':true,

			// content data
			'inhalt':true,
			'indikationen':{
				'sortid':'int',
				'tocid':'int'
			},
			'vorsichtsmassnahmen-und-warnhinweise':{
				'sortid':'int',
				'tocid':'int'
			},
			'gegenanzeigen':true,
			'vorsichtsmassnahmen':true,
			'wechselwirkungen':true,
			'nahrungsmittelinteraktionen':true,
			'schwangerschaft-stillzeit':true,
			'verkehrstuechtigkeit':true,
			'substanzinformationen':true,
			'anwendung-dosierung':{
				'sortid':'int',
				'tocid':'int'
			},
			'nebenwirkungen':{
				'sortid':'int',
				'tocid':'int'
			},
			'aufbewahrung':{
				'sortid':'int',
				'tocid':'int'
			},
			'zusatzinformationen':{
				'sortid':'int',
				'tocid':'int'
			},
			'zusammensetzung':true,
			'verpackung':true,
			'pharmazeutischer-unternehmer':true,

			// accentuations
			'ueberschrift':true,
			'title':true,
			'entry':{
				'tocid':'int'
			}
		},

		// namespace l (layout)
		'l':{
			// structure
			'section':true,

			// content
			'paragraph':true,
			'bold':true,
			'italic':true,
			'underline':true,
			'subscript':true,
			'superscript':true,
			'capitals':true,
			'list':{
				'type':{
					'ordered':true,
					'unordered':true
				}
			},
			'listitem':true,

			// TODO
			'table':true,
			'colgroup':true,
			'tbody':true,
			'tr':true,
			'td':true
		},

		// namespace i (inline)
		'i':{
			// content
			'adresse':true,
			'postadresse':true,
			'email':true,
			'telefon':true,
			'fax':true,
			'internet':true
		}
	}
};

var parser={
	cache:'',
	build_xml:function(obj){
		var x = '';

		$(obj).children().each(function(){
			x+=parser.walk_xml($(this));
		});

		x = gi.xml.prefix+x+gi.xml.suffix;
		x = this.pretty(x);
		return gi.xml.header+'\n<!-- built with '+navigator.userAgent+' -->\n\n'+x;
	},
	build_html:function(clone,target){

		$(clone).find('gi\\:inhalt').find('l\\:paragraph').each(function(){

		// These two methods won't work in DOM2 browsers...only with those fucking IE based ones
		//$(clone).find('[nodeName=inhalt]').find('[nodeName=paragraph]').each(function(){
			parser.walk_html($(this),$(target));
		});

		$(clone).find('gi\\:kopf').find('l\\:paragraph').each(function(){
			parser.walk_html($(this),$(target));
		});

		$(target).find("div[data-rel='gi:inhaltsangabe']").find("div[data-rel='gi:entry']").remove();
		$(clone).find('gi\\:inhaltsangabe').find('gi\\:entry').each(function(){
			parser.walk_html($(this),$(target));
		});
		return true;
	},
	walk_xml:function(obj){
		for(ns in gi.namespaces){
			for(el in gi.schema[ns]){
				var cache='';
				var tmp='';
				var dataset='';

				// matched namespace and element
				if($(obj).data('rel')==ns+':'+el && gi.namespaces[ns]==true){
					if(console.group){
						console.group('<'+$(obj).data('rel')+'>');
					}else{
						console.log('<'+$(obj).data('rel')+'>');
					}

					// prepare allowed attributes
					for(at in gi.schema[ns][el]){
						if(is_array(gi.schema[ns][el][at]) && array_key_exists($(obj).data(at),gi.schema[ns][el][at])){
							// valid val
							dataset+=' '+at+'="'+$(obj).data(at)+'"';
						}else if(is_array(gi.schema[ns][el][at])){
							// invalid val, use the first key in at
							for(val in gi.schema[ns][el][at]){
								dataset+=' '+at+'="'+val+'"';
								console.warn('Element '+ns+':'+el+' had invalid value "'+$(obj).data(at)+'" for attribute "'+at+'" and was corrected to "'+val+'"');
								break;
							}
						}else if(typeof gi.schema[ns][el][at]=='string'){
							dataset+=' '+at+'="'+$(obj).data(at)+'"';
						}
					}

					if(dataset.length){
						console.log('-> DATASET'+dataset);
					}

					if($(obj).data('jq-node')=="single"){
						cache+='<'+$(obj).data('rel')+dataset+'/>\n';
						if(console.group){
							console.groupEnd();
						}else{
							console.log('</'+$(obj).data('rel')+'>');
						}
						return cache;
					}else{
						cache+='<'+$(obj).data('rel')+dataset+'>\n';
					}

					tmp = $(obj).html();
					tmp = tmp.replace(/<\/?[^<]+/g, "");

					// check if filtered content is not empty
					if(trim(tmp).length > 0){
						console.log('-> CONTENT '+tmp);
						cache+=tmp+"\n";
					}

					if($(obj).children("div").length){
						$(obj).children("div").each(function(){
							tmp=""+parser.walk_xml($(this));
							if(tmp!=='false'){
								cache+=tmp;
							}
						});
					}else if($(obj).children("b,u,sub,sup,ul,ol,li").length){
						tmp=$(obj).html();
						tmp=tmp.replace(/sub>/gi,"l:subscript>");
						tmp=tmp.replace(/sup>/gi,"l:superscript>");
						tmp=tmp.replace(/b>/gi,"l:bold>");
						tmp=tmp.replace(/u>/gi,"l:underline>");
						tmp=tmp.replace(/<ul>/gi,"<l:list type=\"unordered\">");
						tmp=tmp.replace(/<ol>/gi,"<l:list type=\"ordered\">");
						tmp=tmp.replace(/<li>/gi,"<l:listitem><l:paragraph>");
						tmp=tmp.replace(/<\/li>/gi,"</l:paragraph></l:listitem>");
						tmp=tmp.replace(/<\/ul>/gi,"</l:list>");
						tmp=tmp.replace(/<\/ol>/gi,"</l:list>");

						tmp=trim(tmp)+"\n";
						cache+=tmp;
					}

					cache+='</'+$(obj).data('rel')+'>\n';
					if(console.groupEnd){
						console.groupEnd();
					}else{
						console.log('</'+$(obj).data('rel')+'>');
					}
					return cache;
				}
			}
		}
		console.warn('INVALID <'+$(obj).data('rel')+'>');
		return '';
	},
	walk_html:function(node,target){
		var x = $(node).parent().get(0).tagName.toLowerCase();
		var y = $(target).find("div[data-rel='"+x+"']");
		var z = $(node).context.tagName.toLowerCase().split(':');
		var ds = ' data-rel="'+$(y).data('jq-structure')+'"';

		if(is_array(gi.schema[z[0]][z[1]])){
			for(at in gi.schema[z[0]][z[1]]){
				if(!$(node).attr(at)){
					console.warn('Element '+x+' has missing attribute '+at);
				}else{
					ds+= ' data-'+at+'="'+$(node).attr(at)+'"';
				}
			}
		}

		if($(y).length=="1"){
			$(y).find('.lorem').remove();
			console.log('- APPEND '+x+' > '+$(node).context.tagName.toLowerCase());
			$(y).append('<div'+ds+' class="editable">'+trim($(node).html())+'</div>');
			return true;
		}else{
			return false;
		}
	},
	pretty:function(str){
		if(typeof XML == 'function'){
			// YEAH - pretty geeky, hugh? =D
			var doc = new DOMParser().parseFromString(str, "text/xml");
			var doc = new XMLSerializer().serializeToString(doc);
			var str = XML(doc).toXMLString();
		}

		return str;
	}
};

var editor={
	show:function(x,y){
		$('#jq-edit .save').show();
		$('#jq-edit .del').show();

		// append a child
		if(y===true){
			console.log('WILL APPEND A CHILD');
			__.element = $(x).parent();
			__.type    = $(__.element).data('jq-structure');

			__.cache = '...';
			$('#jq-edit').find('.save,.del').hide();

		// save a child
		}else{
			console.log('WILL SAVE A CHILD');
			__.element = $(x);
			__.type    = $(__.element).data('rel');

			__.cache = $(__.element).html();
			$('#jq-edit').find('.save,.del').show();
		}

		$('#jq-edit textarea').val(trim(__.cache));

		// is it fully editable or has it only editable content?
		if($(__.element).data('jq-edit-all')==='false'){
			$('#jq-edit .advanced').hide();
		}else{
			$('#jq-edit .advanced').show();
		}

		if($(__.element).data('jq-edit-node')==='false'){
			$('#jq-edit .node').hide();
		}else{
			// TODO: hiding node possibilities
			$('#jq-edit .node').show();
		}
		if($(__.element).data('jq-edit-attr')==='false'){
			$('#jq-edit .attributes').hide();
		}else{
			$('#jq-edit .attributes').show();
		}

		if($(__.element).data('jq-edit')==='false'){
			$('#jq-edit textarea').hide();
			$('#jq-edit .styles').hide();
			$('#jq-edit .specials').hide();
		}else{
			$('#jq-edit textarea').show();
			$('#jq-edit .styles').show();
			$('#jq-edit .specials').show();
		}

		$("#jq-edit input[title='rel']").val(__.type);

		var rel = $(__.element).data('rel').split(':');

		for(key in gi.schema[rel[0]][rel[1]]){
			if(!$('#jq-edit .attributes em').length){
				$('#jq-edit .attributes').prepend('<em>Attribute</em>');
			}

			if(is_array(gi.schema[rel[0]][rel[1]][key])){
				$('#jq-edit .attributes').append('<select title="'+key+'"></select>');
				var temp='';
				for(val in gi.schema[rel[0]][rel[1]][key]){
					temp+='<option value="'+val+'"';
					if($(__.element).data(key)==val){
						temp+=' selected="selected"';
					}
					temp+='>'+val+'</option>';
				}
				$("#jq-edit select[title='"+key+"']").html(temp);
			}else{
				$('#jq-edit .attributes').append('<input type="text" title="'+key+'"/>');
				$("#jq-edit input[title='"+key+"']").val($(__.element).data(key));
			}
		}
		$('#jq-edit').show();

	},
	hide:function(){
		var _clear=((arguments[0])?arguments[0]:true);
		$('.jq-frame').hide();
		$('#jq-edit textarea').val('...');
		$('#jq-edit .attributes').children().remove();

		if(_clear===true){
			__.element   = '';
			__.type      = '';
			__.cache     = '';
			__.ready_xml = '';
		}

		return false;
	},
	reload:function(){
		this.hide();
		$('#ready_xml').val('');
		$('#ready_html').val('');
		window.location.reload();
	},
	notify:function(x){
		$('#jq-notify').html(x).show('fast',function(){
			$(this).fadeOut(3000,function(){
				$(this).html('');
			});
		});
	},
	apply:{
		heuristics:function(obj){
			var str = $(obj).val();
			var lines = str.split(/\n/);
			var foundul = false;
			var foundol = false;

			str = ''; // clear cache
			for (i in lines){
				var line = lines[i];
				for (j in globals.heuristics.lists.unordered){
					var x = line.indexOf(j);

					// TODO: check whether x is before other chars or not
					// e.g. "- test" is a li, but "test - test" not!
					if(x!=-1){
						foundul = true;
						console.log('- LIST ITEM "'+j+'" AT POS "'+x+'" IN "'+line+'"');
						line = "\t<li>"+trim(line.substr(x + 1,line.length))+"</li>";
					}
				}
				str+=line+"\n";
			}
			str = (foundul ? "<ul>\n"+str+"</ul>\n" : str);
			str = (foundol ? "<ol>\n"+str+"</ol>\n" : str);
			$(obj).val(str);
		},
		tags:function(id,sTag,eTag){
			var x = document.getElementById(id);
			x.focus();

			if(typeof x.selectionStart != 'undefined'){
				var ss = x.selectionStart;
				var ee = x.selectionEnd;
				if(x.value.substring(ee,ee - 1)==" "){
					ee = ee - 1;
				}

				var y  = x.value.substring(ss,ee);
				x.value = x.value.substr(0, ss) + sTag + y + eTag + x.value.substr(ee);

				var pos;
				if (y.length == 0) {
					pos = ss + sTag.length;
				}else{
					pos = ss + sTag.length + y.length + eTag.length;
				}
				x.selectionStart = pos; x.selectionEnd = pos;
			}
		}
	}
};
