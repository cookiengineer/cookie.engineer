
describe('Object.prototype.toLocaleString', (assert, expect) => {

	// XXX: The API is specified to _NOT_ return a proper locale string
	let cmp1 = '[object Object]';
	let obj1 = { foo: 1337, bar: 1337.89, qux: new Date('Nov 12 2012 12:13:14') };

	assert(obj1.toLocaleString());

	expect(obj1.toLocaleString(), cmp1);

	assert(obj1);

});

