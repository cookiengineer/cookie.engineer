<?php

function readable_size($number, $precision=2){
 $tags = array('B', 'KB', 'MB', 'GB', 'TB');
 $attag = 0;
 while($number>1024){
  $number = $number / 1024;
  $attag++;
 }
 return round($number, $precision).$tags[$attag];
}

function shorten($string,$limit=10){
 if(
  $limit < strlen($string."...")
  && !($limit >= strlen($string))
 ){
  $string=substr($string,0,$limit)."...";
 }
 return $string;
}

?>