
if (typeof Array.prototype.includes !== 'function') {

	Array.prototype.includes = function(search/*, from */) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.includes called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let from   = arguments.length >= 2 ? arguments[1] : 0;
		let value;


		if (length === 0 || from >= length) {
			return false;
		}


		let start = Math.max(from >= 0 ? from : (length - Math.abs(from)), 0);

		for (let i = start; i < length; i++) {

			if (i in list) {

				value = list[i];

				if (value === search || (isNaN(value) && isNaN(search))) {
					return true;
				}

			}

		}


		return false;

	};

}

