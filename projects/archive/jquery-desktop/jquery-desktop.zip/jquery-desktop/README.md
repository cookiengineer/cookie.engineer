
# jQuery Desktop v0.0.1


### Usage

```bash
cd /path/to/jquery-desktop;
podman build --name jquery-desktop .;
podman -p 8080:80 --name jquery-desktop jquery-desktop;
```
