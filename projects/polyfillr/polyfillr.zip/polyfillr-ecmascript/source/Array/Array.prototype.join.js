
if (typeof Array.prototype.join !== 'function') {

	Array.prototype.join = function() {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.join called on null or undefined');
		}


		let list      = Object(this);
		let length    = list.length >>> 0;
		let separator = arguments.length >= 1 ? (arguments[0]).toString() : ',';
		let value     = '';
		let tmp;


		for (let i = 0; i < length; i++) {

			if (i in list) {

				tmp = list[i];

				if (tmp !== undefined && tmp !== null) {
					value += (list[i]).toString();
				}

			}

			if (i !== length - 1) {
				value += separator;
			}

		}


		return value;

	};

}

