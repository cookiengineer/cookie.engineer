<?php
$tmp   = array();
$in    = array();

$paths=array(
	'upload'   => "../files/uploads/",
	'download' => "../files/downloads/",
	'database' => "../files/database/"
);
@require_once("./functions.php");

ini_set('display_errors',true);
error_reporting(E_ALL);


if(!empty($_POST) && is_array($_POST['i'])){
	foreach($_POST['i'] as $key => $val){
		$in[$key] = $val;
	}

	if($in['do']=="download"){
		$tmp['name']= substr($in['name'], 0, (strlen ($in['name'])) - (strlen (strrchr($in['name'],'.'))));
		$tmp['path'] = $paths['download'];

		$fh = fopen($tmp['path'].basename(trim($tmp['name'])).".xml",'w+');
		fwrite($fh,stripslashes($in['xml']));
		fclose($fh);

		$fh = fopen($tmp['path'].basename(trim($tmp['name'])).".tpl",'w+');
		fwrite($fh,stripslashes($in['html']));
		fclose($fh);

		header('Content-type: application/xml');
		header('Content-Disposition: attachment; filename="'.$in['name'].'"');
		echo stripslashes($in['xml']);

	}elseif($in['do']=="upload"){
		$tmp['name'] = $_FILES['file']['name'];
		$tmp['type'] = $_FILES['file']['type'];
		$tmp['path'] = $paths['upload'];


		// TODO: Upload Error Handling
		@move_uploaded_file($_FILES['file']['tmp_name'], $tmp['path'].$tmp['name']);
		header("Location: ../");
	}




}elseif(!empty($_GET['gen'])){
	if($_GET['gen']=="list"){
		$tmp['path']  = $paths['upload'];
		$tmp['files'] = getFiles($tmp['path']);
		@ksort($tmp['files']);

		/* $tmp['cache']="<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"; */
		$tmp['cache']="<ul>";
		if(is_array($tmp['files'])){
			foreach($tmp['files'] as $file => $data){
				$tmp['cache'].="\n\t<li data-hash=\"".$data['hash']."\" title=\"".$data['title']."\">".$file." <button class=\"open\">einfügen</button></li>";
			}
		}else{
			$tmp['cache'].="\n\t<li>Keine Dateien auf dem Server vorhanden.</li>";
		}
		$tmp['cache'].="\n</ul>";

		header('Content-type: text/html');
		#header('Content-type: application/xml');
		echo $tmp['cache'];

	}elseif($_GET['gen']=="file"){
 		$tmp['path'] = $paths['upload'];
		$tmp['cache'] = getFiles($tmp['path'],$_GET['hash']);

		if(is_string($tmp['cache'])){
			//$tmp['cache'] = eregi_replace("gi:","gi__",$tmp['cache']);
			//$tmp['cache'] = eregi_replace("l:","l__",$tmp['cache']);
			$tmp['cache'] = preg_replace("~(<gi.*)<gi:meta-daten~Uis","<gi:meta-daten",$tmp['cache']);
			$tmp['cache'] = eregi_replace("</gi:gi>","",$tmp['cache']);


			// inline elements (formatting and styling, e.g. <b> and <u>)
			$tmp['cache'] = eregi_replace("l:bold>","b>",$tmp['cache']);
			$tmp['cache'] = eregi_replace("l:underline>","u>",$tmp['cache']);
			$tmp['cache'] = eregi_replace("l:subscript>","sub>",$tmp['cache']);
			$tmp['cache'] = eregi_replace("l:superscript>","sup>",$tmp['cache']);

			$tmp['cache'] = eregi_replace("<l:list type=\"unordered\">","<ul>",$tmp['cache']);
			$tmp['cache'] = eregi_replace("</l:list>","</ul>",$tmp['cache']);
			$tmp['cache'] = eregi_replace("<l:listitem><l:paragraph>","<li>",$tmp['cache']);
			$tmp['cache'] = eregi_replace("</l:paragraph></l:listitem>","</li>",$tmp['cache']);

			header('Content-Type: text/html; charset=utf-8'); 
			echo $tmp['cache'];
			exit;
		}else{
			header("HTTP/1.0 404 Not Found");
		}

	}elseif($_GET['gen']=="metalist"){
		$tmp['path']  = $paths['database']."/meta/";
		$tmp['files'] = getFiles($tmp['path']);
		@ksort($tmp['files']);

		/* $tmp['cache']="<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"; */
		$tmp['cache']="<ul>";
		if(isset($_GET['keyword']) && is_string($_GET['keyword'])){
			foreach($tmp['files'] as $file => $data){
				$tmp['string']=file_get_contents($tmp['path'].$file);
				if(preg_match("~".$_GET['keyword']."~Uis",$tmp['string'])){
					preg_match('~<gi:praeparat name="(.*)">~Uis',$tmp['string'],$tmp['matches']);
					$tmp['cache'].="\n\t<li data-hash=\"".$data['hash']."\" title=\"".$file."\">".$tmp['matches'][1]." <button class=\"open\">übernehmen</button></li>";
				}
			}
		}

		if(!preg_match("~<\/li~Uis",$tmp['cache'])){
			$tmp['cache'].="\n\t<li>Keine Metadaten in der Datenbank gefunden.</li>";
		}

		$tmp['cache'].="\n</ul>";

		header('Content-Type: text/html');
		header('Cache: No-Cache');
		echo $tmp['cache'];
		exit;

	}elseif($_GET['gen']=="metafile"){
		$tmp['path']  = $paths['database']."/meta/";
		$tmp['cache'] = getFiles($tmp['path'],$_GET['hash']);

		if(is_string($tmp['cache'])){
			$tmp['cache'] = preg_replace("~(<gi.*)<gi:meta-daten~Uis","<gi:meta-daten",$tmp['cache']);
			$tmp['cache'] = eregi_replace("</gi:gi>","",$tmp['cache']);

			header('Content-Type: text/html; charset=utf-8'); 
			echo $tmp['cache'];
			exit;
		}else{
			header("HTTP/1.0 404 Not Found");
		}
	}
}

?>
