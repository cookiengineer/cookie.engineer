
describe('Date.prototype.toJSON', (assert, expect) => {

	let cmp1 = '2012-11-12T11:13:14.000Z';
	let dat1 = new Date('Nov 12 2012 12:13:14');

	assert(dat1.toJSON());

	expect(dat1.toJSON(), cmp1);

	assert(dat1.toString());
	assert(dat1.toString().length);

});

