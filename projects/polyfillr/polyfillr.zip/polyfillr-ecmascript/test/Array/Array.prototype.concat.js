
describe('Array.prototype.concat', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [[1],2,[3],4,[5]];


	assert(arr1.concat(arr2));
	assert(arr1.concat(arr3));
	assert(arr2.concat(arr1));
	assert(arr2.concat(arr3));
	assert(arr3.concat(arr1));
	assert(arr3.concat(arr2));

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

	assert(arr1.concat(arr2).length);
	assert(arr1.concat(arr3).length);
	assert(arr2.concat(arr1).length);
	assert(arr2.concat(arr3).length);
	assert(arr3.concat(arr1).length);
	assert(arr3.concat(arr2).length);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

