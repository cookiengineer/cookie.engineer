
describe('String.prototype.repeat', (assert, expect) => {

	let str1 = "abc";

	assert(str1.repeat(3));
	assert(str1.repeat(4.5));
	assert(str1.repeat());

	assert(str1);

	expect(str1.repeat(3).length,    9);
	expect(str1.repeat(4.5).length, 12);
	expect(str1.repeat().length,     0);

});

