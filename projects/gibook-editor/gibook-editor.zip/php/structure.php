<?php
$gi=array(
	// metadaten
	'meta-daten'=>array(
		'produkttyp'=>true,
		'status'=>true),
	'pu-namen'=>true,
	'zulassungsinhaber'=>true,
	'mitvertrieb'=>true,
	'praeparat'=>array(
		'name'=>true),
	'darreichungsformen'=>true,
	'darreichungsform'=>array(
		'name'=>true),
	'zulassungsnummer'=>true,
	'wirkstoffe'=>true,
	'wirkstoff'=>array(
		'name'=>true),
	'packungen'=>true,
	'packung'=>array(
		'name'=>true,
		'pzn'=>true),
	'menge'=>true,
	'einheit'=>true,
	'gi-stand'=>array(
		'sortid'=>true),
	'gueltigkeit'=>true,
	'von'=>true,
	'bis'=>true,

	// kopfdaten
	'kopf'=>true,
	'anwenderhinweis'=>true,
	'inhaltsangabe'=>true,

	// inhalt
	'inhalt'=>true,
	'indikationen'=>array(
		'sortid'=>true,
		'tocid'=>true),
	'vorsichtsmassnahmen-und-warnhinweise'=>array(
		'sortid'=>true,
		'tocid'=>true),
	'gegenanzeigen'=>true,
	'vorsichtsmassnahmen'=>true,
	'wechselwirkungen'=>true,
	'nahrungsmittelinteraktionen'=>true,
	'schwangerschaft-stillzeit'=>true,
	'verkehrstuechtigkeit'=>true,
	'substanzinformationen'=>true,
	'anwendung-dosierung'=>array(
		'sortid'=>true,
		'tocid'=>true),
	'nebenwirkungen'=>array(
		'sortid'=>true,
		'tocid'=>true),
	'aufbewahrung'=>array(
		'sortid'=>true,
		'tocid'=>true),
	'zusatzinformationen'=>array(
		'sortid'=>true,
		'tocid'=>true),
	'zusammensetzung'=>true,
	'verpackung'=>true,
	'pharmazeutischer-unternehmer'=>true,

	// content
	'ueberschrift'=>true,
	'title'=>true,
	'entry'=>array(
		'tocid'=>true)
);

$l=array(
	// structure
	'section'=>true,

	// content
	'paragraph'=>true,
	'bold'=>true,
	'italic'=>true,
	'underline'=>true,
	'subscript'=>true,
	'superscript'=>true,
	'capitals'=>true,
	'list'=>array(
		'type'=>true),
	'listitem'=>true,

);

?>