
describe('Object.find', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3 };
	let obj2 = { '0': 1, '1': 2, '2': 3 };


	assert(Object.find(obj1, (value, prop) => prop === 'b'));
	assert(Object.find(obj2, (value, prop) => prop === '1'));

	assert(obj1);
	assert(obj2);

	let tmp1 = Object.find(obj1, (value, prop) => prop === 'b');
	let tmp2 = Object.find(obj2, (value, prop) => prop === '1');

	expect(tmp1, 2);
	expect(tmp2, 2);

});

