
if (typeof Object.keys !== 'function') {

	Object.keys = function(object) {

		if (object !== Object(object)) {
			throw new TypeError('Object.keys called on a non-object');
		}


		let keys = [];

		for (let prop in object) {

			if (Object.prototype.hasOwnProperty.call(object, prop)) {
				keys.push(prop);
			}

		}

		return keys;

	};

}

