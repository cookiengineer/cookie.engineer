
describe('Object.map', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3, d: 4, e: 5 };
	let obj2 = { '0': 1, '1': 2, '2': 3, '3': 4, '4': 5 };

	let cmp1 = function(element, key, self) {
		return element >= 3;
	};

	let cmp2 = function(element, key, self) {
		return element + '-' + key;
	};


	assert(Object.map(obj1, cmp1));
	assert(Object.map(obj1, cmp2));
	assert(Object.map(obj2, cmp1));
	assert(Object.map(obj2, cmp2));

	try {
		assert(Object.map(obj1));
	} catch(err) {
		assert((err).toString());
	}

	assert(obj1);
	assert(obj2);


	let tmp1 = Object.map(obj1, cmp1);
	let tmp2 = Object.map(obj1, cmp2);
	let tmp3 = Object.map(obj2, cmp1);
	let tmp4 = Object.map(obj2, cmp2);

	expect(tmp1['a'], false);
	expect(tmp1['b'], false);
	expect(tmp1['c'], true);
	expect(tmp1['d'], true);
	expect(tmp1['e'], true);

	expect(tmp2['a'], '1-a');
	expect(tmp2['b'], '2-b');
	expect(tmp2['c'], '3-c');
	expect(tmp2['d'], '4-d');
	expect(tmp2['e'], '5-e');

	expect(tmp3['0'], false);
	expect(tmp3['1'], false);
	expect(tmp3['2'], true);
	expect(tmp3['3'], true);
	expect(tmp3['4'], true);

	expect(tmp4['0'], '1-0');
	expect(tmp4['1'], '2-1');
	expect(tmp4['2'], '3-2');
	expect(tmp4['3'], '4-3');
	expect(tmp4['4'], '5-4');

});

