SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Table structure for the jQuery-Desktop project.
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `uid` int(6) NULL,
  `owner` int(6) NOT NULL,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NULL,
  `birthday` int(10) NULL,
  `company_name` varchar(50) NULL,
  `company_unit` varchar(50) NULL,
  `home_address` varchar(50) NULL,
  `home_city` varchar(50) NULL,
  `home_zip` varchar(50) NULL,
  `home_state` varchar(50) NULL,
  `home_country` varchar(50) NULL,
  `home_phone` varchar(50) NULL,
  `home_fax` varchar(50) NULL,
  `home_voice` varchar(50) NULL,
  `home_email` varchar(50) NULL,
  `home_webpage` varchar(50) NULL,
  `work_address` varchar(50) NULL,
  `work_city` varchar(50) NULL,
  `work_zip` varchar(50) NULL,
  `work_state` varchar(50) NULL,
  `work_country` varchar(50) NULL,
  `work_phone` varchar(50) NULL,
  `work_fax` varchar(50) NULL,
  `work_voice` varchar(50) NULL,
  `work_email` varchar(50) NULL,
  `work_webpage` varchar(50) NULL,
  `im_avatar` blob NULL,
  `im_icq` int(12) NULL,
  `im_jabber` varchar(50) NULL,
  `im_sidebar` tinyint(1) NULL,
  `im_displayas` varchar(50) NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='contact details (vcards)' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `activated` tinyint(1) NOT NULL,
  `group` int(6) NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='users and their passwords' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `messages` (
`id` INT( 6 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`from` INT( 6 ) NOT NULL,
`to` INT( 6 ) NOT NULL ,
`subject` VARCHAR( 50 ) NOT NULL ,
`content` TEXT NOT NULL ,
`date` int(10) NULL ,
`priority` VARCHAR( 10 ) NOT NULL,
`deleted` BOOL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `profiles` (
`id` INT( 6 ) NOT NULL ,
`name` VARCHAR( 50 ) NOT NULL,
`config_wallpaper` TEXT NULL ,
`config_bgcolor` VARCHAR( 6 ) NULL ,
`config_position` VARCHAR( 50 ) NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
