
if (typeof Array.prototype.copyWithin !== 'function') {

	Array.prototype.copyWithin = function(target, start/*, end*/) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.copyWithin called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;

		let tmp1 = target >> 0;
		let tmp2 = start  >> 0;
		let tmp3 = arguments[2] === undefined ? length : arguments[2] >> 0;


		let to   = tmp1 < 0 ? Math.max(length + tmp1, 0) : Math.min(tmp1, length);
		let from = tmp2 < 0 ? Math.max(length + tmp2, 0) : Math.min(tmp2, length);
		let last = tmp3 < 0 ? Math.max(length + tmp3, 0) : Math.min(tmp3, length);


		let count     = Math.min(last - from, length - to);
		let direction = 1;

		if (from < to && to < (from + count)) {
			direction  = -1;
			from      += count - 1;
			to        += count - 1;
		}


		while (count > 0) {

			if (from in list) {
				list[to] = list[from];
			} else {
				delete list[to];
			}

			from += direction;
			to   += direction;
			count--;

		}


		return list;

	};

}
