
describe('Number.prototype.toLocaleString', (assert, expect) => {

	// XXX: This test only works in en_US because of i18n API
	let num1 = new Number(123123123);
	let num2 = new Number(1234);
	let num3 = new Number(1234.56);

	assert(num1.toLocaleString());
	assert(num2.toLocaleString());
	assert(num3.toLocaleString());

	expect(num1.toLocaleString(), '123,123,123');
	expect(num2.toLocaleString(), '1,234');
	expect(num3.toLocaleString(), '1,234.56');

});

