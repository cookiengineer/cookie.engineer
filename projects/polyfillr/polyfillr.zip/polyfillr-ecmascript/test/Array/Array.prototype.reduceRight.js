
describe('Array.prototype.reduceRight', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [1,2,3,4,5];

	let cmp1 = function(a, b) {

		assert(a);
		assert(b);

		return a + b;

	};

	let cmp2 = function(a, b) {

		assert(a);
		assert(b);

		return a * b;

	};


	assert(arr1.reduceRight(cmp1));
	assert(arr2.reduceRight(cmp2));

	try {
		assert(arr3.reduceRight());
	} catch(err) {
		assert((err).toString());
	}

	assert(arr1);
	assert(arr2);
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

