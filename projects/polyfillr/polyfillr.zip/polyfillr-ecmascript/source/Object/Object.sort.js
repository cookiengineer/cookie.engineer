
if (typeof Object.sort !== 'function') {

	Object.sort = function(object) {

		if (object !== Object(object)) {
			throw new TypeError('Object.sort called on a non-object');
		}


		let clone  = {};
		let keys   = Object.keys(object).sort();
		let length = keys.length >>> 0;
		let key;
		let value;

		for (let k = 0; k < length; k++) {

			key   = keys[k];
			value = object[key];

			if (value instanceof Array) {

				clone[key] = value.map(function(element) {

					if (element instanceof Array) {
						return element;
					} else if (element instanceof Object) {
						return Object.sort(element);
					} else {
						return element;
					}

				});

			} else if (value instanceof Object) {

				clone[key] = Object.sort(value);

			} else {

				clone[key] = value;

			}

		}

		return clone;

	};

}

