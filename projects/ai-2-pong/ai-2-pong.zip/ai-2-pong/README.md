
# Reinforcement Pong AI

This Game was a part of the AI Crash Course Workshop I held
on various events. It's an in-Browser Implementation of a
simple Reinforcement AI that also can be manually played
against.


## License

This project is licensed under [GNU GPL 3](./LICENSE_GPL3.txt)
and is `(c) 2017-2021 Cookie Engineer`.

