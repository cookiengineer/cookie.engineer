
if (typeof Number.isFinite !== 'function') {

	Number.isFinite = function(value) {

		if (typeof value === 'number') {

			if (value === -Infinity || value === +Infinity) {
				return false;
			} else if (value !== value) {
				return false;
			}


			return true;

		}


		return false;

	};

}

