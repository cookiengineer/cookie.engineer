
(function(global) {

	const _polyfills = {};
	const _polytests = [];

	const _load = function(url, callback) {

		let xhr = new XMLHttpRequest();

		xhr.open('GET', url);

		xhr.onload = function() {

			if (xhr.status === 200 || xhr.status === 302) {
				callback(xhr.responseText);
			} else {
				callback(null);
			}

		};

		xhr.onerror = xhr.ontimeout = function() {
			callback(null);
		};

		xhr.send(null);

	};

	const _pretty = function(value) {

		if (typeof value === 'string') {
			return '"' + value + '"';
		} else if (typeof value === 'object') {
			return JSON.stringify(value, null, '\t');
		} else {
			return value;
		}

	};



	const AssertError = function(a, b) {
		this.name    = 'AssertError';
		this.message = _pretty(a) + ' !== ' + _pretty(b);
	};

	AssertError.prototype = Error.prototype;


	const ExpectError = function(a, b) {
		this.name    = 'ExpectError';
		this.message = _pretty(a) + ' !== ' + _pretty(b);
	};

	ExpectError.prototype = Error.prototype;



	const _assert = function(result) {
		this.push(result);
	};

	const _expect = function(a, b) {

		let diff = _diff(a, b);
		if (diff === true) {

			this.push({
				a: a,
				b: b
			});

		} else {

			this.push(null);

		}

	};

	const _diff = function(a, b) {

		let diff  = true;
		let atype = typeof a;
		let btype = typeof b;

		if (atype === btype) {

			if (a === null && b === null) {

				diff = false;

			} else if (a === undefined && b === undefined) {

				diff = false;

			} else if (/^boolean|number|string/g.test(atype)) {

				diff = a !== b;

			} else if (atype === 'object') {

				if (a instanceof Array && b instanceof Array) {

					if (a.length === b.length) {

						diff = false;

						for (let i = 0; i < a.length; i++) {

							let result = _diff(a[i], b[i]);
							if (result === true) {
								diff = true;
								break;
							}

						}

					} else {

						diff = true;

					}

				} else if (a instanceof Object && b instanceof Object) {

					diff = false;

					for (let p in a) {

						if (a.hasOwnProperty(p) && b.hasOwnProperty(p)) {

							let result = _diff(a[p], b[p]);
							if (result === true) {
								diff = true;
								break;
							}

						} else if (a.hasOwnProperty(p) || b.hasOwnProperty(b)) {

							diff = true;
							break;

						}

					}

				}

			} else if (atype === 'function') {

				diff = (a).toString() !== (b).toString();

			} else {

				console.warn('diff: Unknown type "' + atype + '" for comparison');

			}

		}

		return diff;

	};

	const _compare_results = function(name, a, b) {

		let valid = true;


		if (a.assert.length === b.assert.length) {

			for (let i = 0, il = a.assert.length; i < il; i++) {

				let tmp_a = a.assert[i];
				let tmp_b = b.assert[i];


				let diff = _diff(tmp_a, tmp_b);
				if (diff === true) {

					console.error(new AssertError(tmp_a, tmp_b));
					valid = false;

				}

			}

		} else {

			valid = false;

		}


		if (a.expect.length > 0) {

			for (let i = 0, il = a.expect.length; i < il; i++) {

				let tmp = a.expect[i];
				if (tmp !== null) {
					console.error('expect(' + _pretty(tmp.a) + ', ' + _pretty(tmp.b) + ') // call #' + (i + 1));
					valid = false;
				}

			}

		}

		if (b.expect.length > 0) {

			for (let i = 0, il = b.expect.length; i < il; i++) {

				let tmp = b.expect[i];
				if (tmp !== null) {
					console.error('expect(' + _pretty(tmp.a) + ', ' + _pretty(tmp.b) + ') // call #' + (i + 1));
					valid = false;
				}

			}

		}


		if (valid === true) {
			console.info(name + ' succeeded.');
		} else if (valid === false) {
			console.error(name + ' failed.');
		}

	};

	const _create_global = function(name) {

		// XXX: We test in Chrome / nw.js
		return global;

	};

	const _create_sandbox = function(name) {

		let sandbox = {};
		let tmp     = name.split('.');
		let method  = tmp.pop();
		let pointer = sandbox;

		for (let t = 0; t < tmp.length; t++) {

			let k = tmp[t];

			pointer = pointer[k] || {};

		}

		pointer[method] = pointer[method];


		return sandbox;

	};

	const _resolve = function(name) {

		let pointer = this;
		let path    = name.split('.');

		for (let p = 0, pl = path.length; p < pl; p++) {

			let k = path[p];

			if (typeof pointer !== 'undefined' && typeof pointer[k] !== 'undefined') {

				pointer = pointer[k];

			} else {

				pointer = null;
				break;

			}

		}

		return pointer;

	};



	/*
	 * IMPLEMENTATION
	 */

	global.describe = function(name, callback) {

		name     = typeof name === 'string'     ? name     : null;
		callback = callback instanceof Function ? callback : null;


		if (name !== null && callback !== null) {

			_polytests.push({
				name:     name,
				callback: callback
			});

		}

	};


	global.load = function() {

		_load('./index.json', (data) => {

			let json = null;
			try {
				json = JSON.parse(data);
			} catch(err) {
				json = null;
			}


			if (json !== null) {
				global.init(json);
			}

		});

	};

	global.init = function(data) {

        let polyfills = [];

		for (let type in data) {

			data[type].forEach(function(polyfill) {

				polyfills.push({
					name: polyfill,
					fill: '../source/' + type + '/' + polyfill + '.js',
					test: './'         + type + '/' + polyfill + '.js'
				});

			});

		}


		polyfills.forEach(function(poly) {

			let name = poly.name;

			_load(poly.fill, (data) => {

				if (data === null) {
					console.warn('No polyfill for "' + poly.name + '"');
				}

				try {
					eval(data);
					_polyfills[name] = data;
				} catch(err) {
					console.info(name);
					console.error(err);
				}

			});

			_load(poly.test, (data) => {

				if (data === null) {
					console.warn('No polytest for "' + poly.name + '"');
				}

				try {
					eval(data);
				} catch(err) {
					console.info(name);
					console.error(err);
				}

			});

		});


		setTimeout(function() {

			console.info('STARTING ' + _polytests.length + ' ' + (_polytests.length === 1 ? 'TEST' : 'TESTS') + ' NAO.');

			_polytests.forEach(function(entry) {

				let callback = entry.callback;
				let name     = entry.name;

				let polyfill_01 = _polyfills[name] || null;
				let polyfill_02 = _polyfills[name] || null;
				let sandbox_01  = _create_global(name);
				let sandbox_02  = _create_sandbox(name);
				let results_01  = { assert: [], expect: [] };
				let results_02  = { assert: [], expect: [] };

				sandbox_01.UID = name + ' (native)';
				sandbox_02.UID = name + ' (polyfill)';


				if (_resolve.call(sandbox_01, name) !== null) {
					polyfill_01 = null;
				} else {
					console.warn(name + ' shim (non-native) necessary.');
				}


				with (sandbox_01) {

					try {

						if (polyfill_01 !== null) {
							new Function(polyfill_01).call(sandbox_01);
						}

						callback.call(
							sandbox_01,
							_assert.bind(results_01.assert),
							_expect.bind(results_01.expect)
						);

					} catch(err) {

						ERR = err;
						console.info(UID);
						console.error(err);

					}

				}

				with (sandbox_02) {

					try {

						if (polyfill_02 !== null) {
							new Function(polyfill_02).call(sandbox_02);
						}

						callback.call(
							sandbox_02,
							_assert.bind(results_02.assert),
							_expect.bind(results_02.expect)
						);

					} catch(err) {

						ERR = err;
						console.info(UID);
						console.error(err);

					}

				}


				if (sandbox_01.ERR === undefined && sandbox_02.ERR === undefined) {

					_compare_results(name, results_01, results_02);

				} else {

					console.error(name + ' failed.');

					delete sandbox_01.ERR;
					delete sandbox_02.ERR;

				}

			});

		}, polyfills.length * 50);

	};


	global._POLYFILLS = _polyfills;
	global._POLYTESTS = _polytests;

})(typeof window !== 'undefined' ? window : this);

