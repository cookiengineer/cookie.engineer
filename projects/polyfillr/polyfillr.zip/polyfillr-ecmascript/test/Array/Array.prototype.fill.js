
describe('Array.prototype.fill', (assert, expect) => {

	let arr1 = [1,2,3,4,5];
	let arr2 = [1,2,3,4,5];
	let arr3 = [];


	assert(arr1.fill(13));
	assert(arr1);

	assert(arr2.fill(13.37));
	assert(arr2);

	assert(arr3.fill('foo'));
	assert(arr3);

	assert(arr1.length);
	assert(arr2.length);
	assert(arr3.length);

});

