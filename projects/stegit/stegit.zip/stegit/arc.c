
#include <sys/types.h>

#include "config.h"
#include <md5.h>
#include "arc.h"


void arc4_init(struct arc4_stream *as) {
	int n;

	for (n = 0; n < 256; n++) {
		as->s[n] = n;
	}

	as->i = 0;
	as->j = 0;
}

u_int8_t arc4_getbyte(struct arc4_stream *as) {

	u_int8_t si;
	u_int8_t sj;

	as->i = (as->i + 1);
	si = as->s[as->i];

	as->j = (as->j + si);
	sj = as->s[as->j];

	as->s[as->i] = sj;
	as->s[as->j] = si;

	return (as->s[(si + sj) & 0xff]);

}

u_int32_t arc4_getword(as) struct arc4_stream *as; {

	u_int32_t val;

	val = arc4_getbyte(as) << 24;
	val |= arc4_getbyte(as) << 16;
	val |= arc4_getbyte(as) << 8;
	val |= arc4_getbyte(as);

	return val;

}

void arc4_addrandom(struct arc4_stream *as, u_char *dat, int datlen) {

	int      n;
	u_int8_t si;

	as->i--;

	for (n = 0; n < 256; n++) {
		as->i = (as->i + 1);
		si = as->s[as->i];
		as->j = (as->j + si + dat[n % datlen]);
		as->s[as->i] = as->s[as->j];
		as->s[as->j] = si;
	}

}

void arc4_initkey(struct arc4_stream *as, char *type, u_char *key, int keylen) {

	MD5_CTX ctx;
	u_char digest[16];

	MD5Init(&ctx);
	MD5Update(&ctx, type, strlen(type));
	MD5Update(&ctx, key, keylen);
	MD5Final(digest, &ctx);

	arc4_init(as);
	arc4_addrandom(as, digest, 16);

}

