
describe('Object.assign', (assert, expect) => {

	let tpl1 = { a: 1 };
	let tpl2 = { b: 2 };
	let tpl3 = { c: 3 };


	assert(Object.assign({}, tpl1, tpl2, tpl3));
	assert(Object.assign({}, tpl1, tpl2));
	assert(Object.assign({}));

	assert(tpl1);
	assert(tpl2);
	assert(tpl3);

	let tmp1 = Object.assign({}, tpl1, tpl2, tpl3);

	expect(tmp1['a'], 1);
	expect(tmp1['b'], 2);
	expect(tmp1['c'], 3);

});

