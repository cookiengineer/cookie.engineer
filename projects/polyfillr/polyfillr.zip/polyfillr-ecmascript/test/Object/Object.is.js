
describe('Object.is', (assert, expect) => {

	let obj1 = { a: 1, b: 2, c: 3 };


	assert(Object.is(obj1, obj1));
	assert(Object.is(obj1, {}));

	expect(Object.is(obj1, obj1), true);
	expect(Object.is(obj1, {}),   false);

	assert(Object.is(NaN, NaN));
	assert(Object.is(+0, +0));
	assert(Object.is(-0, -0));
	assert(Object.is(+0, -0));

	expect(Object.is(NaN, NaN), true);
	expect(Object.is(+0, +0), true);
	expect(Object.is(-0, -0), true);
	expect(Object.is(+0, -0), false);

	assert(Object.is(undefined, undefined));
	assert(Object.is(undefined, null));
	assert(Object.is(null, null));

	expect(Object.is(undefined, undefined), true);
	expect(Object.is(undefined, null),      false);
	expect(Object.is(null, null),           true);

});

