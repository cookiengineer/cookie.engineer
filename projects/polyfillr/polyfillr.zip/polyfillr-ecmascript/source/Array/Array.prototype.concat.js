
if (typeof Array.prototype.concat !== 'function') {

	Array.prototype.concat = function(/* [value1 [, ...[, valueN]]]*/) {

		if (this === null || this === undefined) {
			throw new TypeError('Array.prototype.concat called on null or undefined');
		}


		let list   = Object(this);
		let length = list.length >>> 0;
		let result = [];
		let value;


		for (let i = 0; i < length; i++) {

			if (i in list) {
				result.push(list[i]);
			}

		}

		for (let a = 0, al = arguments.length; a < al; a++) {

			value = arguments[a];

			if (value instanceof Array) {

				for (let v = 0, vl = value.length; v < vl; v++) {
					result.push(value[v]);
				}

			} else {

				result.push(arguments[a]);

			}

		}


		return result;

	};

}

