
describe('Array.prototype.toSource', (assert, expect) => {

	let cmp1 = '[1, 2.3, "foo", ["foo", "bar"]]';
	let cmp2 = '[1, 2.3, "foo", [1, 2, 3]]';
	let arr1 = [1, 2.3, 'foo', ['foo', 'bar']];
	let arr2 = [1, 2.3, 'foo', [1,2,3]];

	assert(arr1.toSource());
	assert(arr2.toSource());

	expect(arr1.toSource(), cmp1);
	expect(arr2.toSource(), cmp2);

	assert(arr1);
	assert(arr2);

	assert(arr1.length);
	assert(arr2.length);

});

