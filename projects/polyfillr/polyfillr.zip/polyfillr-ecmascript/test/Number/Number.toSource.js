
describe('Number.toSource', (assert, expect) => {

	let cmp = 'function Number() {\n\t[native code]\n}';

	assert(Number.toSource());
	expect(Number.toSource(), cmp);

});

