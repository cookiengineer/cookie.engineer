
describe('String.prototype.padStart', (assert, expect) => {

	let cmp1 = '       abc';
	let cmp2 = 'foofoofabc';
	let cmp3 = '123abc';
	let cmp4 = 'abc';

	let str1 = 'abc';
	let str2 = 'abc';
	let str3 = 'abc';
	let str4 = 'abc';


	assert(str1.padStart(10));
	expect(str1.padStart(10), cmp1);

	assert(str1.padStart(10, 'foo'));
	expect(str1.padStart(10, 'foo'), cmp2);

	assert(str1.padStart(6, '123456'));
	expect(str1.padStart(6, '123456'), cmp3);

	assert(str1.padStart(1));
	expect(str1.padStart(1), cmp4);

});

