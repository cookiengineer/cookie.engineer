
describe('Number.isNaN', (assert, expect) => {

	assert(Number.isNaN(NaN));
	assert(Number.isNaN(-0));
	assert(Number.isNaN(+0));
	assert(Number.isNaN(Infinity));
	assert(Number.isNaN(-Infinity));

	expect(Number.isNaN(NaN),       true);
	expect(Number.isNaN(-0),        false);
	expect(Number.isNaN(+0),        false);
	expect(Number.isNaN(Infinity),  false);
	expect(Number.isNaN(-Infinity), false);

});

