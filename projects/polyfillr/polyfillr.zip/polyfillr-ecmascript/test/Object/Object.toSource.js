
describe('Object.toSource', (assert, expect) => {

	let cmp = 'function Object() {\n\t[native code]\n}';

//	assert(Object.toSource());
	expect(Object.toSource(), cmp);

});

