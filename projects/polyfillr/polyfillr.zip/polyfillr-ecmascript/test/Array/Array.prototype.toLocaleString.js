
describe('Array.prototype.toLocaleString', (assert, expect) => {

	// XXX: This test only works in en_US because of i18n API
	let cmp1 = "1,337,1,337.89,11/12/2012, 12:13:14 PM";
	let arr1 = [1337, 1337.89, new Date('Nov 12 2012 12:13:14')];

	assert(arr1.toLocaleString());

	expect(arr1.toLocaleString(), cmp1);

	assert(arr1);

	assert(arr1.length);

});

