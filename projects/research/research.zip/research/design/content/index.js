
(function(global) {

})(typeof window !== 'undefined' ? window : global);

