
if (typeof String.prototype.toSource !== 'function') {

	String.prototype.toSource = function() {

		let value = (this).toString();

		value = value.replace('\n', '\\n');
		value = value.replace('\t', '\\t');

		return '(new String("' + value + '"))';

	};

}

