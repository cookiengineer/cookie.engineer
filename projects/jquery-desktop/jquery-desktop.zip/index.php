<?php
require_once("./system/lib/libos.php");
require_once("./system/lib/libtpl.php");
require_once("./system/lib/libfunctions.php");

if($_SERVER['QUERY_STRING']=="login"){
 $tplfile = "./system/gui/login/desktop.html";
 $config['machine'] = "Login | jQuery-Desktop.org";

 $config['email'] = isset($_POST['input'])?$_POST['input']['email']:"john@doe.com";
 $config['pass'] = isset($_POST['input'])?$_POST['input']['pass']:"demo";

 if($_POST['input'] && $_POST['input']['email']){
  setcookie("email",$_POST['input']['email'],time()+3600, "/");
  header("Location: /");
 }

 if(strpos($_SERVER['HTTP_ACCEPT_ENCODING'],"gzip")!==false){
  if(setcookie("gzip","true",time()+3600, "/")){
   $_COOKIE['gzip']="true";
  }
  $gzip = ($_COOKIE['gzip']==="true")
   ?"<a class=\"options\" rev=\"gzip\" title=\"true\">[X]</a> gzip compression"
   :"<a class=\"options\" rev=\"gzip\" title=\"true\">[&nbsp;]</a> gzip compression";
 }
 $config['env']['methods'].= $gzip;

 $libTPL=new libTPL("./system/registry.xml");
 $libTPL->getJS("./system/kernel/js");
 $libTPL->getJS("./system/gui/js");
 #$libTPL->getCSS("./system/kernel/css");
 #$libTPL->getCSS("./system/gui/css");
 $libTPL->buildHead();

}elseif($_SERVER['QUERY_STRING']=="logout"){
 setcookie("email","",time()-3600, "/");
 header("Location: /?login");
}elseif(empty($_COOKIE['email']) && $_SERVER['QUERY_STRING']!="skip"){
 header("HTTP/1.1 401 Unauthorized");
 header("Location: /?login");
}

if(!empty($_COOKIE['email']) || $_SERVER['QUERY_STRING']=="skip"){
 // Browser Switch - fucking IE!
 header("Content-Type: application/xhtml+xml");

 $libOS=new libOS("./system/registry.xml",&$config);
 $libOS->init();
 $tplfile = $config['tpl']['system'];

 $libTPL=new libTPL("./system/registry.xml",&$libOS);
 $libTPL->getJS("./system/kernel/js");
 $libTPL->getJS("./system/gui/js");
 $libTPL->getCSS("./system/kernel/css");
 $libTPL->getCSS("./system/gui/css");

 foreach($libOS->loaded['apps'] as $app => $array){
  if(isset($array['window']['style'])){
   $libTPL->getCSS($array['window']['style']);
  }
  if(isset($array['window']['jscript'])){
   $libTPL->getJS($array['window']['jscript']);
  }
 }
 $libTPL->buildHead();

 // Well, I WANT that help icon displayed in the right top corner
 // and NOT in the frame the others are displayed in!
/*
 foreach($libTPL->desktop['icons'] as $id => $icon){
  if(eregi("HELP?",$icon)){
   $myicon=preg_replace("~{position}~Uis","right:30px;top:30px;",$icon);
   $libTPL->icons.= $myicon."\n";
   unset($libTPL->desktop['icons'][$id]);
  }elseif(eregi("Config",$icon)){
   $myicon=preg_replace("~{position}~Uis","right:30px;top:100px;",$icon);
   $libTPL->icons.= $myicon."\n";
   unset($libTPL->desktop['icons'][$id]);
  }
 }
*/

 $libTPL->buildIcons(round(sqrt(count($libTPL->icons)),0));
 $libTPL->buildWindows();
 $libTPL->buildTasks();
 $libTPL->buildQuickies();
 $libTPL->buildDesklets();
}

$tpl = file_get_contents($tplfile);
$tpl = preg_replace("~{machine}~Uis",$config['machine'],$tpl);
$tpl = preg_replace("~{email}~Uis",  $config['email'],  $tpl);
$tpl = preg_replace("~{pass}~Uis",   $config['pass'],   $tpl);

if(is_array($libTPL->errors)){
 $debug="<ul class=\"abs\" id=\"debug\">";
 foreach($libTPL->errors as $c=>$msg){
  $debug.="<li>".$msg."</li>";
 }
 $debug.="</ul>";
}else{
 $debug="";
}

$tpl = preg_replace("~{jQueryTPL:head}~Uis",    $libTPL->out['head'],    $tpl);
$tpl = preg_replace("~{jQueryTPL:icons}~Uis",   $libTPL->out['icons'],   $tpl);
$tpl = preg_replace("~{jQueryTPL:windows}~Uis", $libTPL->out['windows'], $tpl);
$tpl = preg_replace("~{jQueryTPL:tasks}~Uis",   $libTPL->out['tasks'],   $tpl);
$tpl = preg_replace("~{jQueryTPL:quickies}~Uis",$libTPL->out['quickies'],$tpl);
$tpl = preg_replace("~{jQueryTPL:desklets}~Uis",$libTPL->out['desklets'],$tpl);
$tpl = preg_replace("~{debug}~Uis",$debug,$tpl);

if(is_array($config['env'])){
 foreach($config['env'] as $key=>$val){
  $key = eregi_replace("_dir","",$key);
  $tpl = preg_replace("~{".$key."}~Uis",$val,$tpl);
 }
}

echo $tpl;

?>