
if (typeof Number.isSafeInteger !== 'function') {

	Number.isSafeInteger = function(value) {

		if (typeof value === 'number') {

			if (Math.floor(value) === value) {

				if (value === -Infinity || value === +Infinity) {
					return false;
				} else if (Math.abs(value) <= Number.MAX_SAFE_INTEGER) {
					return true;
				}
			}

		}


		return false;

	};

}

