
if (typeof Object.assign !== 'function') {

	Object.assign = function(object /*, ... sources */) {

		if (object !== Object(object)) {
			throw new TypeError('Object.assign called on a non-object');
		}


		for (let a = 1, al = arguments.length; a < al; a++) {

			let source = arguments[a];
			if (source !== undefined && source !== null) {

				for (let key in source) {

					if (Object.prototype.hasOwnProperty.call(source, key) === true) {
						object[key] = source[key];
					}

				}

			}

		}


		return object;

	};

}

