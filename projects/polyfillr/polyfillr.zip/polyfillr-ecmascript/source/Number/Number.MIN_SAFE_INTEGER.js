
if (typeof Number.MIN_SAFE_INTEGER !== 'number') {

	Number.MIN_SAFE_INTEGER = -9007199254740991;

}

