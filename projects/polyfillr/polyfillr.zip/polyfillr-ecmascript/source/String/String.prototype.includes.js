
if (typeof String.prototype.includes !== 'function') {

	String.prototype.includes = function(search/*, from */) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.includes called on null or undefined');
		}


		let value  = String(this);
		let from   = arguments.length >= 2 ? (arguments[1] | 0) : 0;
		let tmp    = String(search);
		let length = tmp.length >>> 0;

		if (from + length > value.length) {
			return false;
		}


		return value.indexOf(search, from) !== -1;

	};

}

