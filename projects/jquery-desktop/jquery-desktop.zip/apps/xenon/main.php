<?php
$prefix="../../"; # only subdirectories allowed, set it false to ignore
define('_SELF_',"apps/xenon/main.php");
define('_PIXMAPS_',"system/pixmaps");
$query=explode(":",$_SERVER['QUERY_STRING']);

if(basename($_SERVER['PHP_SELF'])!="main.php"){
 $prefix="./";
 unset($query);
}else{
 require_once("../../system/lib/libfunctions.php");
}

function mkXenonLink($string){
 return eregi_replace("/",":",$string);
}

$cur=$prefix;
# cur -> with prefix
# cur2 -> without prefix

for($i=0;$i<count($query);$i++){
 $cur .="/".$query[$i];
 $cur2.="/".$query[$i];
}
$cur2=substr($cur2,1);

$list=array();
if(is_dir($cur)){
 $dh=opendir($cur);
 while(($file=readdir($dh))!==false){
  if($file!="."){ # && $file!=".."
   if(is_file($cur."/".$file)){
    $list['files'][]=$cur2."/".$file;
   }elseif(is_dir($cur."/".$file)){
    $list['dirs'][]=$file;
   }
  }
 }
}
@natsort($list['dirs']);
@natsort($list['files']);

$cache.='     <table class="data">
      <tr>
       <th class="shrink"></th>
       <th>Name</th>
       <th>Date Modified</th>
       <th>Date Created</th>
       <th>Size</th>
       <th>Kind</th>
      </tr>';

if(is_array($list['dirs'])){
 foreach($list['dirs'] as $id => $dir){
  if($cur!=$prefix && $cur!=$prefix."/"){
   $href=mkXenonLink($cur2."/".$dir);
  }else{
   $href=mkXenonLink($dir);
  }

  if(basename($dir)==".."){
   #echo $href."<br/>\n".$dir;
   if(!isset($query[1])){
    $href="";
   }elseif(isset($query[count($query)-1])){
    $href=eregi_replace(":".$query[count($query)-1].":\.\.","",$href);
   }
  }
  if($dir==".."){
   $name = "&lt;&lt;";
   $title = "Go to parent folder";
   $img = "folder-uploads.png";
  }else{
   $name = $title = $dir;
   $img = "folder.png";
  }

  $cache.="
      <tr>
       <td><a class=\"launch\" href=\"#tasks_xenon\" rev=\""._SELF_."?".$href."\" onclick=\"jQueryDesktop.clear_active('#app_xenon');\"><img src=\""._PIXMAPS_."/".$img."\"/></a></td>
       <td><a class=\"launch\" href=\"#tasks_xenon\" rev=\""._SELF_."?".$href."\" title=\"".$title."\" onclick=\"jQueryDesktop.clear_active('#app_xenon');\">".basename($name)."</a></td>
       <td>".(filemtime($cur."/".$dir)?date('d/m/Y',filemtime($cur."/".$dir)):"&ndash;")."</td>
       <td>".(filectime($cur."/".$dir)?date('d/m/Y',filemtime($cur."/".$dir)):"&ndash;")."</td>
       <td>".(filesize($cur."/".$dir)?readable_size(filesize($cur."/".$dir)):"&ndash;")."</td>
       <td>Directory</td>
      </tr>";
 }
}else{
 $cache.='
      <tr>
       <td colspan="6">No directories found in here.</td>
      </tr>';
}
$cache.='
      <tr>
       <td colspan="6" class="divider"></td>
      </tr>';

if(is_array($list['files'])){
 foreach($list['files'] as $id => $file){
  if($cur!=$prefix && $cur!=$prefix."/"){
   $href=$file;
  }else{
   $href=basename($file);
  }

  $query=false;
  switch($ext=substr($file,strpos($file,'.') +1)){
   case "txt":
    $icon="file-txt.png";
   break;
   case "css": case "htc":
    $icon="file-css.png";
   break;
   case "bin": case "exe": case "sh":
    $icon="file-exe.png";
   break;
   case "php": case "php4": case "php5":
    $icon="file-php.png";
   break; 
   case "htm": case "html": case "phtml": case "xhtml": case "xml":
    $icon="file-web.png";
   break;
   case "gif": case "jpg": case "jpeg": case "png":
    $query = "#tasks_media";
    $app   = "apps/media/main.php?";
   case "xcf": case "psd":
    $icon="file-img.png";
   break;
   case "vcf": case "csv": case "xls":
    $icon="file-vcf.png";
   break;
   case "gz": case "lha": case "rar": case "tar": case "zip":
    $icon="file-zip.png";
   break;
   default:
    $icon="file-src.png";
   break;
  }
  if($query){
   $link_pre = "<a class=\"launch\" href=\"".$query."\" rev=\"".$app.$href."\">";
  }else{
   $link_pre = "<a target=\"_blank\" href=\"".$href."\">";
  }

  $cache.="
      <tr>
       <td>".$link_pre."<img src=\""._PIXMAPS_."/".$icon."\"/></a></td>
       <td>".$link_pre.basename($file)."</a></td>
       <td>".(filemtime($prefix."/".$file)?date('d/m/Y',filemtime($prefix."/".$file)):"&ndash;")."</td>
       <td>".(filectime($prefix."/".$file)?date('d/m/Y',filemtime($prefix."/".$file)):"&ndash;")."</td>
       <td>".(filesize($prefix."/".$file)?readable_size(filesize($prefix."/".$file)):"&ndash;")."</td>
       <td>File</td>
      </tr>";
 }
}else{
 $cache.='
      <tr>
       <td colspan="6">No files found in here.</td>
      </tr>';
}
$cache.='
     </table>';

echo $cache;
?>