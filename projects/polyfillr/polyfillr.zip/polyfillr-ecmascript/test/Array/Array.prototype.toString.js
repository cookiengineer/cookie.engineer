
describe('Array.prototype.toString', (assert, expect) => {

	// XXX: This test only works in CET because of Date API
	let cmp1 = "1337,1337.89,Mon Nov 12 2012 12:13:14 GMT+0100 (CET)";
	let arr1 = [1337, 1337.89, new Date('Nov 12 2012 12:13:14')];

	assert(arr1.toString());

	expect(arr1.toString(), cmp1);

	assert(arr1);

	assert(arr1.length);

});

