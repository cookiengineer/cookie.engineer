
if (typeof String.prototype.padEnd !== 'function') {

	String.prototype.padEnd = function(length/*, chunk */) {

		if (this === null || this === undefined) {
			throw new TypeError('String.prototype.padEnd called on null or undefined');
		}


		length = length >> 0;


		let chunk = arguments.length >= 2 ? String(arguments[1] || '') : '';
		let value = (this).toString();

		if (this.length > length) {
			return value;
		}


		let tmp = length - this.length;
		if (tmp > chunk.length) {
			chunk += chunk.repeat(tmp / chunk.length);
		}

		return value + chunk.slice(0, tmp);

	};

}

