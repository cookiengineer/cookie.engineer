
if (typeof Number.EPSILON !== 'number') {

	Number.EPSILON = 2.220446049250313e-16;

}

