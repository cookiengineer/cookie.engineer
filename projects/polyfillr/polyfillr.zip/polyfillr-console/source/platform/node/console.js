
if (typeof Polyfillr === 'undefined') {
	Polyfillr = {};
}

Console = Polyfillr.Console = (function(global) {

	const _console = global.console;
	const _TAB_STR = ' ' + new Array(128).join(' ');
	const _DIV_STR = '=' + new Array(128).join('=');



	/*
	 * HELPERS
	 */

	const _Table = function(labels, values) {

		this.labels = labels;
		this.values = values;

	};

	const _render = function(args) {

		let mode = 0;
		if (!(args instanceof Array)) {
			args = [ args ];
			mode = 1;
		}


		let chars = [];

		for (let a = 0, al = args.length; a < al; a++) {

			let data = args[a];
			if (typeof data === 'boolean') {
				chars.push('\u001b[94m' + data);
			} else if (typeof data === 'number') {
				chars.push('\u001b[95m' + data);
			} else if (typeof data === 'string') {
				if (mode === 1) {
					chars.push('\u001b[92m"' + _render_string(data) + '"');
				} else {
					chars.push('\u001b[39m' + _render_string(data) + '');
				}
			} else if (typeof data === 'null' || data === null) {
				chars.push('\u001b[95mnull');
			} else if (typeof data === 'undefined' || data === undefined) {
				chars.push('\u001b[95mundefined');
			} else if (data instanceof Error) {
				chars.push('\u001b[33m' + _render_error(data));
			} else if (typeof data === 'object') {

				if (data instanceof _Table) {
					chars.push(_render_table(data));
				} else if (data instanceof Array) {
					chars.push(_render_array(data));
				} else if (data instanceof Object) {
					chars.push(_render_object(data));
				}

			} else if (typeof data === 'function') {

				chars.push(_render_function(data));

			}

		}


		return chars.join('');

	};

	const _render_array = function(array, t) {

		let tab   = typeof t === 'number' ? t : 0;
		let lines = [];

		lines.push(_TAB_STR.substr(0, tab) + '[');

		tab += 4;

		for (let a = 0, al = array.length; a < al; a++) {

			let data = array[a];
			let str  = '';

			if (typeof data === 'boolean') {
				str += '\u001b[94m' + data;
			} else if (typeof data === 'number') {
				str += '\u001b[95m' + data;
			} else if (typeof data === 'string') {
				str += '\u001b[92m"' + _render_string(data) + '"';
			} else if (typeof data === 'null' || data === null) {
				str += '\u001b[95mnull';
			} else if (typeof data === 'undefined' || data === undefined) {
				str += '\u001b[95mundefined';
			} else if (typeof data === 'object') {

				if (data instanceof Array) {
					str += _render_array(data,  tab).trim();
				} else if (data instanceof Object) {
					str += _render_object(data, tab).trim();
				}

			} else if (typeof data === 'function') {

				let tmp = (data).toString();
				let i1  = tmp.indexOf('(');
				let i2  = tmp.indexOf(')');
				if (i1 !== -1 && i2 !== -1) {
					str += '\u001b[95mfunction(\u001b[93m' + tmp.substr(i1 + 1, i2 - i1 - 1) + '\u001b[39m)';
				} else {
					str += '\u001b[95mfunction()';
				}

			}

			lines.push(_TAB_STR.substr(0, tab) + str + '\u001b[39m,');

		}

		if (lines.length > 1) {

			let last = lines[lines.length - 1];
			if (last.length > 0) {
				lines[lines.length - 1] = last.substr(0, last.length - 1);
			}

		}

		tab -= 4;

		lines.push(_TAB_STR.substr(0, tab) + ']');

		return lines.join('\n');

	};

	const _render_error = function(err) {

		let lines = [];

		if (typeof err.stack === 'string') {

			let data = err.stack.split('\n');
			let type = data[0].split(':')[0];
			let msg  = data[0].split(':').slice(1).join(':');

			lines.push('\u001b[93m' + type + '\u001b[39m: "' + msg.trim() + '"');


			let stack = data.slice(1);
			if (stack.length > 0) {

				for (let s = 0, sl = stack.length; s < sl; s++) {

					let tmp = stack[s].trim().split(' ');
					if (tmp[0] === 'at') {

						let href = tmp[1].split(':');
						let name = tmp[1].split('/').pop().split(':');
						let line = null;

						if (/[0-9]+/g.test(href[href.length - 1])) href.pop();
						if (/[0-9]+/g.test(href[href.length - 1])) href.pop();
						if (/[0-9]+/g.test(name[name.length - 1])) line = name.pop();
						if (/[0-9]+/g.test(name[name.length - 1])) line = name.pop();


						if (line !== null) {
							name = name.join(':') + '#L' + line;
						} else {
							name = name.join(':');
						}

						if (tmp[1].indexOf('://') !== -1) {
							lines.push('        at ' + name);
						} else {
							lines.push('        at ' + tmp[1]);
						}

					} else {
						lines.push('        ' + tmp.join(' '));
					}

				}

			}

		} else {

			// TODO: Simple Error

		}


		return lines.join('\n');

	};

	const _render_function = function(data) {

		return data;

	};

	const _render_object = function(object, t) {

		let tab   = typeof t === 'number' ? t : 0;
		let lines = [];

		lines.push(_TAB_STR.substr(0, tab) + '{');

		tab += 4;

		for (let prop in object) {

			if (object.hasOwnProperty(prop)) {

				let data = object[prop];
				let str  = '';

				if (typeof data === 'boolean') {
					str += '\u001b[94m' + data;
				} else if (typeof data === 'number') {
					str += '\u001b[95m' + data;
				} else if (typeof data === 'string') {
					str += '\u001b[92m"' + _render_string(data) + '"';
				} else if (typeof data === 'null' || data === null) {
					str += '\u001b[95mnull';
				} else if (typeof data === 'undefined' || data === undefined) {
					str += '\u001b[95mundefined';
				} else if (typeof data === 'object') {

					if (data instanceof Array) {
						str += _render_array(data,  tab).trim();
					} else if (data instanceof Object) {
						str += _render_object(data, tab).trim();
					}

				} else if (typeof data === 'function') {

					let tmp = (data).toString();
					let i1  = tmp.indexOf('(');
					let i2  = tmp.indexOf(')');
					if (i1 !== -1 && i2 !== -1) {
						str += '\u001b[95mfunction(\u001b[93m' + tmp.substr(i1 + 1, i2 - i1 - 1) + '\u001b[39m)';
					} else {
						str += '\u001b[95mfunction()';
					}

				}


				lines.push(_TAB_STR.substr(0, tab) + '\u001b[39m' + prop + ': ' + str + '\u001b[39m,');

			}

		}

		if (lines.length > 1) {

			let last = lines[lines.length - 1];
			if (last.length > 0) {
				lines[lines.length - 1] = last.substr(0, last.length - 1);
			}

		}

		tab -= 4;

		lines.push(_TAB_STR.substr(0, tab) + '}');

		return lines.join('\n');

	};

	const _render_string = function(str) {

		str = str.split('\t').join('\\t');
		str = str.split('\n').join('\\n');

		return str;

	};


	const _render_table = function(table) {

		let cell_w = 8;
		let lines  = [];
		let sizes  = [];
		let labels = table.labels;
		let values = table.values;


		if (values instanceof Array) {

			values.forEach(function(value, v) {

				labels.forEach(function(label) {

					let tmp1 = ' ' + _render(value[label]) + '\u001b[39m ';
					let tmp2 = tmp1.split('\u001b').map(function(val) {
						return val.substr(0, 1) === '[' ? val.substr(4) : val;
					}).join('');

					cell_w = Math.max(tmp2.length, label.length, cell_w);

				});

			});


			let header = ' (index) | ' + labels.map(function(label) {
				return label + _TAB_STR.substr(0, cell_w - label.length - 2);
			}).join(' | ');

			lines.push(header);
			lines.push(_DIV_STR.substr(0, header.length));


			let chunks = values.map(function(value, v) {

				return '\u001b[39m' + labels.map(function(label) {

					let tmp1 = ' ' + _render(value[label]) + '\u001b[39m ';
					let tmp2 = tmp1.split('\u001b').map(function(val) {
						return val.substr(0, 1) === '[' ? val.substr(4) : val;
					}).join('');

					let space = _TAB_STR.substr(0, cell_w - tmp2.length);

					return tmp1 + space;

				}).join('|');

			});

			values.forEach(function(value, v) {

				let i     = ' ' + v;
				let space = _TAB_STR.substr(0, 9 - i.length);

				lines.push(i + space + '|' + chunks[v]);

			});

		} else if (values instanceof Object) {

			for (let v in values) {

				if (values.hasOwnProperty(v)) {

					let value = values[v];

					labels.forEach(function(label) {

						let tmp1 = ' ' + _render(value[label]) + '\u001b[39m ';
						let tmp2 = tmp1.split('\u001b').map(function(val) {
							return val.substr(0, 1) === '[' ? val.substr(4) : val;
						}).join('');

						cell_w = Math.max(tmp2.length, label.length, cell_w);

					});

				}

			}


			let header = ' (index) | ' + labels.map(function(label) {
				return label + _TAB_STR.substr(0, cell_w - label.length - 2);
			}).join(' | ');

			lines.push(header);
			lines.push(_DIV_STR.substr(0, header.length));


			for (let v in values) {

				if (values.hasOwnProperty(v)) {

					let value = values[v];
					let chunk = '\u001b[39m' + labels.map(function(label) {

						let tmp1 = ' ' + _render(value[label]) + '\u001b[39m ';
						let tmp2 = tmp1.split('\u001b').map(function(val) {
							return val.substr(0, 1) === '[' ? val.substr(4) : val;
						}).join('');

						let space = _TAB_STR.substr(0, cell_w - tmp2.length);

						return tmp1 + space;

					}).join('|');


					let i     = ' ' + v;
					let space = _TAB_STR.substr(0, 9 - i.length);

					lines.push(i + space + '|' + chunk);

				}

			}

		}

		return '\n' + lines.join('\n') + '\n';

	};

	const _write_stdout = function(args) {

		let str = _render(args);
		if (str.length > 0) {
			process.stdout.write(str + '\n\u001b[0m');
		}

	};

	const _write_stderr = function(args) {

		let str = _render(args);
		if (str.length > 0) {
			process.stderr.write(str + '\n');
		}

	};



	/*
	 * IMPLEMENTATION
	 */

	let Console = function(id) {

		id = typeof id === 'string' ? id : 'default';


		this.__id     = id;
		this.__timers = {};

	};


	Console.prototype = {

		assert: function(condition) {

			if (!condition) {

				let al   = arguments.length;
				let args = [];

				for (let a = 1; a < al; a++) {
					args.push(arguments[a]);
				}

				this.log.apply(this, args);

			}

		},

		clear: function() {

			process.stdout.write('\x1B[2J\x1B[0f');

		},

		error: function() {

			let al   = arguments.length;
			let args = [ ' (E) ' ];
			for (let a = 0; a < al; a++) {
				args.push(arguments[a]);
			}

			args.reverse();
			args.push('\u001b[41m');
			args.reverse();
			args.push('\u001b[49m');

			_write_stderr(args);

		},

		info: function() {

			let al   = arguments.length;
			let args = [ ' (I) ' ];
			for (let a = 0; a < al; a++) {
				args.push(arguments[a]);
			}

			args.reverse();
			args.push('\u001b[42m');
			args.reverse();
			args.push('\u001b[49m');

			_write_stdout(args);

		},

		log: function() {

			let al   = arguments.length;
			let args = [ ' (L) ' ];
			for (let a = 0; a < al; a++) {
				args.push(arguments[a]);
			}

			_write_stdout(args);

		},

		table: function(data, labels) {

			data   = typeof data === 'object' ? data   : null;
			labels = labels instanceof Array  ? labels : null;


			if (data !== null) {

				if (labels === null) {

					let check = {};
					for (var prop in data) {

						if (data.hasOwnProperty(prop)) {
							check = data[prop];
							break;
						}

					}

					labels = Object.keys(check).sort(function(a, b) {

						let a1 = a.toLowerCase();
						let b1 = b.toLowerCase();

						if (a1 < b1) return -1;
						if (a1 > b1) return  1;

						return 0;

					});

				}


				_write_stdout([ new _Table(labels, data) ]);

			}

		},

		time: function(label) {

			label = typeof label === 'string' ? label : 'default';


			this.__timers[label] = Date.now();

		},

		timeEnd: function(label) {

			label = typeof label === 'string' ? label : 'default';


			let timer = this.__timers[label] || null;
			if (timer !== null) {

				let diff = (Date.now() - timer).toPrecision(3);
				let args = [ ' (T) ', label + ': ' + diff + 'ms' ];

				args.reverse();
				args.push('\u001b[44m');
				args.reverse();
				args.push('\u001b[49m');

				_write_stdout(args);

			}

		},

		warn: function() {

			let al   = arguments.length;
			let args = [ ' (W) ' ];
			for (let a = 0; a < al; a++) {
				args.push(arguments[a]);
			}

			args.reverse();
			args.push('\u001b[43m');
			args.reverse();
			args.push('\u001b[49m');

			_write_stdout(args);

		}

	};


	// global.console = new Console('default');


	return Console;

})(typeof global !== 'undefined' ? global : this);

