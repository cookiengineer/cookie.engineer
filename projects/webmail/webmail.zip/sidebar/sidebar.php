<?php
$cfg['tpl']['cnt']['logout_btn'] = "";
$cfg['tpl']['var']['localhost']  = $_SERVER['HTTP_HOST'];
$cfg['tpl']['cnt']['jscripts']   = "";

switch($query[0]){
 case "login":
  if(is_array($input) && strlen($input['username'])>=3){
   if(isset($input['advcfg'])){
    setcookie("advcfg",$input['advcfg'],time()+3600,"/");
    if($input['advcfg']=="manual"){
     foreach($input as $name=>$value){
      if($name=="flags"){
       foreach($value as $do=>$what){
        if($do=="crypt"){
         $flags.="/".$what;
        }elseif($do=="service"){
         $flags.="/service=".$what;
        }
       }
       setcookie("imap_flags",$flags,time()+3600,"/");
      }
      elseif($name!="profile"){
       setcookie($name,$value,time()+3600,"/");
      }
     }
    }elseif($input['advcfg']=="profile"){
      setcookie("advcfg","profile".$input['profile'],time()+3600,"/");
    }elseif($input['advcfg']=="uwp"){
      setcookie("advcfg","uwp",time()+3600,"/");
      setcookie("url",$input['url'],time()+3600,"/");
    }
   }
   setcookie("username",$input['username'],time()+3600,"/");
   setcookie("password",$input['password'],time()+3600,"/");
   setcookie("login",time()+3600,time()+3600,"/");
  }
  header("Location: ./?check");
 break;
 case "logout":
  foreach($_COOKIE as $name=>$value){
   setcookie($name,"",time()-3600,"/");
  }
  header("Location: ./");
 break;
}

# - - - default content - - - #
$cfg['tpl']['cnt']['body']="
<form id=\"login\" action=\"./?login\" method=\"post\">
 <fieldset>
  <legend>Account Details</legend>
  <b>
   <input type=\"radio\" name=\"input[advcfg]\" value=\"simple\" checked=\"checked\"/>
   <abbr title=\"Login to this server ({VAR:localhost})\">Use simple login?</abbr>
  </b>
  <input id=\"username\" type=\"text\" name=\"input[username]\" value=\"{CFG:username}\"/>
  <input type=\"password\" name=\"input[password]\" />
 </fieldset>
 <fieldset>
  <legend>Server Profiles</legend>
  <b>
   <input type=\"radio\" name=\"input[advcfg]\" value=\"profile\"/>
   Use predefined profile?
  </b>
  <select id=\"pfs\" name=\"input[profile]\" onchange=\"unhide('hint');\">{CNT:PROFILES}
  </select>
  <div id=\"hint\"><abbr title=\"Please allow JavaScript to replace the hints by dragging the select menu above.\">No hint</abbr></div>
 </fieldset>
<div class=\"infobar\">
 <input type=\"submit\" value=\"Login\"/>
 <input type=\"button\" value=\"Logout\" onclick=\"document.location.href='?logout';\"/>
</div>
</form>
";

if(is_object($obj['imap']) && $obj['imap']->check_login(&$_COOKIE['error'])){
 $_COOKIE['error']="Settings seem to work fine.";
 $cfg['tpl']['cnt']['toolbar']="
<ul id=\"toolbar\">
 <li><a href=\"../?mailbox\" target=\"_blank\">Go to Webmail Frontend</a></li>
</ul>";

$obj['imap']->connect();
$count  = $obj['imap']->retrieve_num_messages();
$msgs   = $obj['imap']->retrieve_message_list(false,10);
$boxes  = $obj['imap']->retrieve_mailboxes_short();
$obj['imap']->disconnect();

 $cfg['tpl']['cnt']['body']="
<ul id=\"sidebar\">
";
 for($i=0;$i<count($msgs);$i++){
  if($msgs[$i]['deleted']){
   $bgclass = "deleted";
   $show_undelete=true;
  }elseif($cfg['is_pop3']){
   $bgclass = "read";
  }elseif($msgs[$i]['unread']){
   $bgclass = "unread";
  }else{
   $bgclass = "read";
  }
  $msg_date = date("Y/m/d", $msgs[$i]['udate']);
  if($msg_date==date("Y/m/d")){
   $msg_date=date("g:ia", $msgs[$i]['udate']);
  }

 $cfg['tpl']['cnt']['body'].="
 <li class=\"".$bgclass."\" title=\"achieved ".$msg_date."\">
  <a href=\"../?message:".urlencode($folder).":".$msgs[$i]['msgno']."\" target=\"_blank\">
   ".($msgs[$i]['count_disposition']['attachment']?'<img src="'.$cfg['tpl']['css']['url'].'/msg/file.png" alt="*" title="contains files"/>':'')
    .($msgs[$i]['replied']?'<img src="'.$cfg['tpl']['css']['url'].'/msg/replied.png" alt="*" title="is already replied"/>':'')
    ."&nbsp;".htmlentities($msgs[$i]['subject'])."</a><br/>
   <span>
    sent by <a href=\"../?compose:reply:".urlencode($folder).":".$msgs[$i][msgno]."\" target=\"_blank\">
    ".htmlentities(stristr($folder,$cfg['imap_sentbox'])?$msgs[$i]['to']:$msgs[$i]['from'])."</a>
   </span>
 </li>";
 }
}elseif(is_object($obj['imap'])){
 $_COOKIE['error']=imap_last_error();
}

if(is_array($pfs) && !$cfg['mode']['mini']){
 $cfg['tpl']['cnt']['jscripts']="hints = new Array();
 examples = new Array();
 function example(id){
  document.getElementById('username').value=examples[id];
 }
 function hint(id){
  document.getElementById('hint').innerHTML=hints[id] + '\<br \/>\<br \/>\<a href=\"javascript:example('+id+');\">Click to show example above\<\/a>';
  if(document.getElementById('username').value.length==0){
   example(id);
  }
 }
";
 foreach($pfs as $ID=>$array){
 $cfg['tpl']['cnt']['profiles'].="
    <option value=\"".$ID."\" onclick=\"javascript:hint('".$ID."');\">".$array['provider']."</option>";
 $cfg['tpl']['cnt']['jscripts'].="  hints[".$ID."]=\"".$array['hint']."\";
  examples[".$ID."]=\"".($array['example']?$array['example']:$array['hint'])."\";
";
 }
}

$cfg['tpl']['cnt']['jscripts'].="
 function hide(id){
  if(id=='pfs'){ document.getElementById('hint').style.display='none'; }
  document.getElementById(id).style.display='none';
 }
 function unhide(id){
  document.getElementById(id).style.display='block';
 }";
?>