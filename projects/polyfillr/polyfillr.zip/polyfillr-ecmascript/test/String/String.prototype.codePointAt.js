
describe('String.prototype.codePointAt', (assert, expect) => {

	let cmp1 = 66;
	let cmp2 = 65536;
	let str1 = "ABC";
	let str2 = "\uD800\uDC00";

	assert(str1.codePointAt(1));
	assert(str2.codePointAt(0));

	assert(str1);
	assert(str2);

	expect(str1.codePointAt(1), cmp1);
	expect(str2.codePointAt(0), cmp2);

});

